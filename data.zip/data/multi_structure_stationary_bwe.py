# -*- coding: utf-8 -*-
"""
Multi-structure stationary wavelet waveform-preserving bandwidth-extension dataset generator.

用法：
1) 把本脚本放到和以下构造生成脚本同一个文件夹：
   dongyingbatch.py
   helanjinhaiyanpendi.py
   huazhuang.py
   malinbatch_noise_dat.py
   malinbatchnewfold&noise&q.py
   tixingyanqiubatch_noise_dat.py

2) 运行：
   python multi_structure_stationary_bwe.py

输出：
  dataset_waveform_bwe_multistruct_stationary_v1/
    lq/*.dat       窄带输入，同尺寸，无噪声
    gt/*.dat       宽带标签，同尺寸，无噪声
    meta/*.json    子波类型、相位、构造来源等元信息
    wavelets/*.npy 输入/标签子波
    qc/*.png       质控图

核心逻辑：
- 只替换“子波卷积与保存”逻辑，不改变各脚本内部反射结构生成函数。
- 三类 stationary 子波：ricker / ormsby / klauder。
- LQ/GT 使用同源窄带-宽带配对。
- 保留相位：LQ 和 GT 使用同一个 phase_deg。
- Ricker 使用 v3 的 power broadening 单峰包络拓频，避免简单提高主频。
- 第一阶段不加噪声、不下采样。
"""

import csv
import json
import math
import shutil
import importlib.util
from pathlib import Path
from collections import Counter, defaultdict

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert, chirp


# =========================================================
# 0. 配置区：主要改这里
# =========================================================
SCRIPT_DIR = Path(__file__).resolve().parent

SOURCE_SCRIPTS = [
    {"name": "dongying",        "file": "dongyingbatch.py"},
    {"name": "helan_basin",     "file": "helanjinhaiyanpendi.py"},
    {"name": "huazhuang",       "file": "huazhuang.py"},
    {"name": "malin",           "file": "malinbatch_noise_dat.py"},
    {"name": "malin_newfold",   "file": "malinbatchnewfold&noise&q.py"},
    {"name": "tixing_salt",     "file": "tixingyanqiubatch_noise_dat.py"},
]

# 每种反射结构生成多少个样本。先小规模 QC，满意后再改大。
NUM_PER_STRUCTURE = 100

# 输出尺寸：所有脚本都按同尺寸 512 x 512 生成。
N1 = 512
N2 = 512

DT = 0.004
WAVELET_LENGTH = 0.256

# 输出目录
OUT_DIR = SCRIPT_DIR / "dataset_waveform_bwe_multistruct_stationary_v1"
LQ_DIR = OUT_DIR / "lq"
GT_DIR = OUT_DIR / "gt"
META_DIR = OUT_DIR / "meta"
WAVELET_DIR = OUT_DIR / "wavelets"
QC_DIR = OUT_DIR / "qc"

# 文件编号起点。若要接着旧数据编号，可改为 0501、1001 等。
START_INDEX = 1

# 子波比例。建议第一阶段固定比例，避免某类子波过少。
FAMILY_RATIO = {"ricker": 0.40, "ormsby": 0.40, "klauder": 0.20}

# 相位设置：phase_prob 表示非零相位样本概率。
PHASE_PROB = 0.50
PHASE_RANGE = (-30.0, 30.0)

# QC 保存：前几个样本 + 每隔 qc_every + 每种 structure/family 首次出现。
QC_FIRST_N = 5
QC_EVERY = 50
RANDOM_SEED = 2026

# 是否复制源脚本到输出目录，方便复现实验。
COPY_SOURCE_SCRIPTS = True


# =========================================================
# 1. 基础工具函数
# =========================================================
def ensure_dirs():
    for d in [LQ_DIR, GT_DIR, META_DIR, WAVELET_DIR, QC_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def sanitize_float(x):
    return float(np.asarray(x).item())


def time_axis(dt=0.004, length=0.256):
    # 0.256 / 0.004 = 64，包含端点后为 65 点，中心点恰为 0。
    return np.arange(-length / 2.0, length / 2.0 + 0.5 * dt, dt, dtype=np.float32)


def normalize_wavelet(w):
    w = np.asarray(w, dtype=np.float64)
    w = w - np.mean(w)
    m = np.max(np.abs(w))
    if m > 1e-12:
        w = w / m
    return w.astype(np.float32)


def phase_rotate(w, phase_deg=0.0):
    """常相位旋转：LQ 和 GT 必须使用同一个 phase_deg。"""
    w = np.asarray(w, dtype=np.float64)
    if abs(float(phase_deg)) < 1e-12:
        return normalize_wavelet(w)
    wh = np.imag(hilbert(w))
    phi = np.deg2rad(float(phase_deg))
    # 与之前代码保持一致：cos*w - sin*Hilbert(w)
    wp = np.cos(phi) * w - np.sin(phi) * wh
    return normalize_wavelet(wp)


def centered_wavelet_from_amp(amp, n_wavelet, nfft):
    """
    根据零相位振幅谱构造中心化时间域子波。
    amp: rfft 频率点上的非负振幅谱。
    """
    amp = np.asarray(amp, dtype=np.float64)
    amp = np.maximum(amp, 0.0)
    amp[0] = 0.0  # 避免 DC 分量破坏零均值子波

    w_causal = np.fft.irfft(amp.astype(np.complex128), n=nfft)

    half = n_wavelet // 2
    if n_wavelet % 2 == 1:
        w = np.concatenate([w_causal[-half:], w_causal[:half + 1]])
    else:
        w = np.concatenate([w_causal[-half:], w_causal[:half]])
    return normalize_wavelet(w)


def high_frequency_taper(freqs, f_start=90.0, f_end=120.0):
    """高频余弦衰减，避免由谱幂变换造成最高频端硬截断。"""
    taper = np.ones_like(freqs, dtype=np.float64)
    taper[freqs >= f_end] = 0.0
    m = (freqs > f_start) & (freqs < f_end)
    if np.any(m):
        x = (freqs[m] - f_start) / (f_end - f_start + 1e-12)
        taper[m] = 0.5 + 0.5 * np.cos(np.pi * x)
    return taper


def smooth_max(a, b, p=6.0):
    """平滑包络，避免硬 max 造成尖锐拼接。"""
    a = np.maximum(np.asarray(a, dtype=np.float64), 0.0)
    b = np.maximum(np.asarray(b, dtype=np.float64), 0.0)
    return (a ** p + b ** p) ** (1.0 / p)


# =========================================================
# 2. stationary 子波工厂
# =========================================================
def ricker_wavelet_zero(f0=25.0, dt=0.004, length=0.256):
    t = time_axis(dt, length)
    a = (np.pi * float(f0)) ** 2
    w = (1.0 - 2.0 * a * t ** 2) * np.exp(-a * t ** 2)
    return normalize_wavelet(w)


def ricker_power_broaden_pair(rng, dt=0.004, length=0.256, phase_deg=0.0):
    """
    v3 逻辑：
    LQ = 单峰 Ricker；
    GT = A_lq ** gamma 形成单峰宽频谱，同时低频和高频两端拓展。
    这不是严格单参数 Ricker，而是 Ricker-derived / Ricker-like broadband wavelet。
    """
    f0_lq = float(rng.uniform(16.0, 28.0))
    gamma = float(rng.uniform(0.55, 0.75))

    w_lq0 = ricker_wavelet_zero(f0_lq, dt=dt, length=length)
    n = len(w_lq0)
    nfft = 4096

    W_lq = np.fft.rfft(np.fft.ifftshift(w_lq0), n=nfft)
    A_lq = np.abs(W_lq)
    A_lq = A_lq / (np.max(A_lq) + 1e-12)

    freqs = np.fft.rfftfreq(nfft, d=dt)
    A_gt = A_lq ** gamma
    A_gt[0] = 0.0
    A_gt *= high_frequency_taper(freqs, f_start=90.0, f_end=120.0)
    A_gt = A_gt / (np.max(A_gt) + 1e-12)

    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)

    w_lq = phase_rotate(w_lq0, phase_deg)
    w_gt = phase_rotate(w_gt0, phase_deg)

    meta = {
        "family": "ricker",
        "phase_deg": sanitize_float(phase_deg),
        "stationary": True,
        "noise": False,
        "same_size": True,
        "f0_lq": sanitize_float(f0_lq),
        "ricker_gt_mode": "power_broaden_single_ricker_spectrum",
        "ricker_broadening_rule": "A_gt = A_lq ** gamma, 0<gamma<1; preserve DC=0 and apply high-frequency taper.",
        "gamma": sanitize_float(gamma),
        "note": "GT is Ricker-derived / Ricker-like broadband, not a strict single-parameter Ricker.",
    }
    return w_lq, w_gt, meta


def trapezoid_amp(freqs, f1, f2, f3, f4):
    """Ormsby / 梯形带通振幅谱。"""
    freqs = np.asarray(freqs, dtype=np.float64)
    amp = np.zeros_like(freqs, dtype=np.float64)

    # rise
    m = (freqs >= f1) & (freqs < f2)
    if np.any(m):
        amp[m] = (freqs[m] - f1) / (f2 - f1 + 1e-12)

    # plateau
    amp[(freqs >= f2) & (freqs <= f3)] = 1.0

    # fall
    m = (freqs > f3) & (freqs <= f4)
    if np.any(m):
        amp[m] = 1.0 - (freqs[m] - f3) / (f4 - f3 + 1e-12)

    return np.clip(amp, 0.0, 1.0)


def ormsby_wavelet_from_band(band, dt=0.004, length=0.256, nfft=4096):
    n = len(time_axis(dt, length))
    freqs = np.fft.rfftfreq(nfft, d=dt)
    amp = trapezoid_amp(freqs, *band)
    return centered_wavelet_from_amp(amp, n, nfft)


def ormsby_pair(rng, dt=0.004, length=0.256, phase_deg=0.0):
    # LQ 窄带梯形窗
    f1 = float(rng.uniform(5.0, 8.0))
    f2 = float(rng.uniform(10.0, 15.0))
    f3 = float(rng.uniform(38.0, 48.0))
    f4 = float(rng.uniform(55.0, 65.0))

    # GT 低频下探 + 高频上拓，并保持梯形窗家族特征
    f1g = max(1.5, f1 - float(rng.uniform(2.0, 4.0)))
    f2g = max(f1g + 2.0, f2 - float(rng.uniform(3.0, 5.0)))
    f3g = f3 + float(rng.uniform(10.0, 18.0))
    f4g = f4 + float(rng.uniform(18.0, 28.0))
    f4g = min(f4g, 95.0)
    f3g = min(f3g, f4g - 8.0)

    band_lq = [f1, f2, f3, f4]
    band_gt = [f1g, f2g, f3g, f4g]

    w_lq0 = ormsby_wavelet_from_band(band_lq, dt=dt, length=length)
    w_gt0 = ormsby_wavelet_from_band(band_gt, dt=dt, length=length)

    w_lq = phase_rotate(w_lq0, phase_deg)
    w_gt = phase_rotate(w_gt0, phase_deg)

    meta = {
        "family": "ormsby",
        "phase_deg": sanitize_float(phase_deg),
        "stationary": True,
        "noise": False,
        "same_size": True,
        "band_lq": [sanitize_float(x) for x in band_lq],
        "band_gt": [sanitize_float(x) for x in band_gt],
        "ormsby_gt_mode": "wider_trapezoid_band_envelope",
    }
    return w_lq, w_gt, meta


def klauder_zero(f1, f2, dt=0.004, length=0.256, sweep_length=1.0):
    """由线性扫频信号自相关得到 Klauder-like 子波。"""
    # 用较长 sweep 提高自相关稳定性，再截取中心 wavelet_length。
    t_sweep = np.arange(0.0, sweep_length, dt, dtype=np.float64)
    sig = chirp(t_sweep, f0=float(f1), f1=float(f2), t1=sweep_length, method="linear")
    sig *= np.hanning(len(sig))
    ac = np.correlate(sig, sig, mode="full")
    mid = len(ac) // 2
    n = len(time_axis(dt, length))
    half = n // 2
    if n % 2 == 1:
        w = ac[mid - half: mid + half + 1]
    else:
        w = ac[mid - half: mid + half]
    return normalize_wavelet(w)


def klauder_envelope_pair(rng, dt=0.004, length=0.256, phase_deg=0.0):
    # LQ sweep band
    f1 = float(rng.uniform(8.0, 14.0))
    f2 = float(rng.uniform(42.0, 55.0))

    # GT sweep band：低频下探 + 高频上拓
    f1g = max(2.0, f1 - float(rng.uniform(3.0, 6.0)))
    f2g = min(95.0, f2 + float(rng.uniform(18.0, 30.0)))

    w_lq0 = klauder_zero(f1, f2, dt=dt, length=length)
    w_wide0 = klauder_zero(f1g, f2g, dt=dt, length=length)

    # 为了满足“包络形态”，在振幅谱上强制 GT 对 LQ 形成平滑包络。
    n = len(w_lq0)
    nfft = 4096
    W_lq = np.fft.rfft(np.fft.ifftshift(w_lq0), n=nfft)
    W_wide = np.fft.rfft(np.fft.ifftshift(w_wide0), n=nfft)
    A_lq = np.abs(W_lq)
    A_wide = np.abs(W_wide)
    A_lq = A_lq / (np.max(A_lq) + 1e-12)
    A_wide = A_wide / (np.max(A_wide) + 1e-12)

    A_gt = smooth_max(A_lq, A_wide, p=6.0)
    A_gt[0] = 0.0
    freqs = np.fft.rfftfreq(nfft, d=dt)
    A_gt *= high_frequency_taper(freqs, f_start=95.0, f_end=120.0)
    A_gt = A_gt / (np.max(A_gt) + 1e-12)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)

    w_lq = phase_rotate(w_lq0, phase_deg)
    w_gt = phase_rotate(w_gt0, phase_deg)

    meta = {
        "family": "klauder",
        "phase_deg": sanitize_float(phase_deg),
        "stationary": True,
        "noise": False,
        "same_size": True,
        "sweep_lq": [sanitize_float(f1), sanitize_float(f2)],
        "sweep_gt": [sanitize_float(f1g), sanitize_float(f2g)],
        "klauder_gt_mode": "smooth_spectral_envelope_from_lq_and_wider_sweep",
    }
    return w_lq, w_gt, meta


def make_phase(rng):
    if rng.random() < PHASE_PROB:
        ph = float(rng.uniform(PHASE_RANGE[0], PHASE_RANGE[1]))
        # 避免抽到过小相位，造成分类不清楚。
        if abs(ph) < 3.0:
            ph = 3.0 if ph >= 0 else -3.0
        return ph
    return 0.0


def make_stationary_wavelet_pair(rng, forced_family=None, dt=0.004, length=0.256):
    if forced_family is None:
        families = list(FAMILY_RATIO.keys())
        probs = np.array([FAMILY_RATIO[k] for k in families], dtype=np.float64)
        probs = probs / probs.sum()
        family = str(rng.choice(families, p=probs))
    else:
        family = str(forced_family)

    phase_deg = make_phase(rng)

    if family == "ricker":
        return ricker_power_broaden_pair(rng, dt=dt, length=length, phase_deg=phase_deg)
    if family == "ormsby":
        return ormsby_pair(rng, dt=dt, length=length, phase_deg=phase_deg)
    if family == "klauder":
        return klauder_envelope_pair(rng, dt=dt, length=length, phase_deg=phase_deg)

    raise ValueError(f"Unknown family: {family}")


def make_family_plan(n, rng):
    n_r = int(round(n * FAMILY_RATIO.get("ricker", 0.4)))
    n_o = int(round(n * FAMILY_RATIO.get("ormsby", 0.4)))
    n_k = n - n_r - n_o
    plan = ["ricker"] * n_r + ["ormsby"] * n_o + ["klauder"] * n_k
    rng.shuffle(plan)
    return plan


# =========================================================
# 3. 卷积、归一化、QC
# =========================================================
def convolve_along_depth(img, wavelet):
    """
    沿深度/时间轴卷积。
    约定各脚本输出 image shape = (n2, n1)，深度/时间轴为 axis=1。
    """
    img = np.asarray(img, dtype=np.float32)
    wavelet = np.asarray(wavelet, dtype=np.float32)
    n2, n1 = img.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))

    IMG = np.fft.rfft(img, n=nfft, axis=1)
    W = np.fft.rfft(wavelet, n=nfft)
    Y = IMG * W[None, :]
    y = np.fft.irfft(Y, n=nfft, axis=1)

    start = (nw - 1) // 2
    return y[:, start:start + n1].astype(np.float32)


def normalize_pair_shared(lq, gt, percentile=99.5, scale_floor=1e-6):
    """共享尺度归一化，避免破坏 LQ/GT 相对振幅关系。"""
    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)
    vals = np.concatenate([np.abs(lq).reshape(-1), np.abs(gt).reshape(-1)])
    scale = float(np.percentile(vals, percentile))
    scale = max(scale, float(scale_floor))
    lq_n = np.clip(lq / scale, -1.0, 1.0).astype(np.float32)
    gt_n = np.clip(gt / scale, -1.0, 1.0).astype(np.float32)
    return lq_n, gt_n, scale


def amplitude_spectrum(w, dt=0.004, nfft=4096):
    w = np.asarray(w, dtype=np.float32)
    W = np.fft.rfft(np.fft.ifftshift(w), n=nfft)
    amp = np.abs(W)
    amp = amp / (np.max(amp) + 1e-12)
    f = np.fft.rfftfreq(nfft, d=dt)
    return f, amp


def save_qc_figure(lq, gt, w_lq, w_gt, meta, out_png, dt=0.004):
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)

    clip = np.percentile(np.abs(np.concatenate([lq.reshape(-1), gt.reshape(-1)])), 99.0)
    clip = max(float(clip), 1e-6)

    x_trace = lq.shape[0] // 2
    t = time_axis(dt, WAVELET_LENGTH)
    f_lq, a_lq = amplitude_spectrum(w_lq, dt=dt)
    f_gt, a_gt = amplitude_spectrum(w_gt, dt=dt)

    fig = plt.figure(figsize=(19, 9), dpi=150)

    ax1 = plt.subplot(2, 3, 1)
    ax1.imshow(lq.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax1.set_title("LQ narrow-band")

    ax2 = plt.subplot(2, 3, 2)
    ax2.imshow(gt.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax2.set_title("GT broadband")

    ax3 = plt.subplot(2, 3, 3)
    ax3.plot(lq[x_trace, :], label="lq")
    ax3.plot(gt[x_trace, :], label="gt")
    ax3.set_title(f"Trace comparison x={x_trace}")
    ax3.legend(fontsize=8)

    ax4 = plt.subplot(2, 3, 4)
    ax4.plot(t[:len(w_lq)], w_lq, label="w_lq")
    ax4.plot(t[:len(w_gt)], w_gt, label="w_gt")
    ax4.set_title("Wavelet time domain")
    ax4.legend(fontsize=8)

    ax5 = plt.subplot(2, 3, 5)
    ax5.plot(f_lq, a_lq, label="lq")
    ax5.plot(f_gt, a_gt, label="gt")
    ax5.set_xlim(0, 120)
    ax5.set_ylim(0, 1.08)
    ax5.set_title("Wavelet amplitude spectrum")
    ax5.legend(fontsize=8)

    ax6 = plt.subplot(2, 3, 6)
    ax6.axis("off")
    meta_show = dict(meta)
    txt = json.dumps(meta_show, ensure_ascii=False, indent=2)
    ax6.text(0, 1, txt, va="top", ha="left", fontsize=8, family="monospace")

    plt.tight_layout()
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)


# =========================================================
# 4. 动态加载各反射结构脚本
# =========================================================
def load_generator_class(script_path, module_name):
    script_path = Path(script_path)
    if not script_path.exists():
        raise FileNotFoundError(f"Source script not found: {script_path}")

    spec = importlib.util.spec_from_file_location(module_name, str(script_path))
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)

    if not hasattr(mod, "GeologicalSeismicData"):
        raise AttributeError(f"{script_path.name} does not contain class GeologicalSeismicData")
    return mod.GeologicalSeismicData


def generate_reflectivity(GeneratorClass, seed, n1=512, n2=512):
    gen = GeneratorClass(seed=seed)

    # 大多数脚本支持 seismic_and_slopes_2d(n1,n2,noise=0)。
    # 若含 params 可选参数，默认 None 时内部会随机生成。
    try:
        model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0)
    except TypeError:
        # 兜底：部分脚本可能需要显式 params。
        if hasattr(gen, "generate_plausible_parameters"):
            params = gen.generate_plausible_parameters(n1=n1, n2=n2)
            model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0, params=params)
        else:
            raise

    model = np.asarray(model, dtype=np.float32)
    if model.shape != (n2, n1):
        raise ValueError(f"Unexpected model shape {model.shape}, expected {(n2, n1)}")
    return model


# =========================================================
# 5. 可选：划分 train/val 的索引脚本逻辑
# =========================================================
def phase_group(phase_deg, eps=1e-6):
    return "zero_phase" if abs(float(phase_deg)) <= eps else "with_phase"


def write_summary_csv(rows):
    out_csv = OUT_DIR / "sample_index.csv"
    fields = [
        "id", "structure", "family", "phase_deg", "phase_group",
        "lq_path", "gt_path", "meta_path", "w_lq_path", "w_gt_path",
    ]
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})
    print(f"[SAVE] sample_index.csv: {out_csv}")

    counts = {
        "total": len(rows),
        "by_structure": dict(Counter(r["structure"] for r in rows)),
        "by_family": dict(Counter(r["family"] for r in rows)),
        "by_phase_group": dict(Counter(r["phase_group"] for r in rows)),
        "by_structure_family": dict(Counter(f"{r['structure']}_{r['family']}" for r in rows)),
    }
    out_json = OUT_DIR / "sample_count.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(counts, f, ensure_ascii=False, indent=2)
    print(f"[SAVE] sample_count.json: {out_json}")
    print(json.dumps(counts, ensure_ascii=False, indent=2))


def copy_sources_for_reproducibility():
    if not COPY_SOURCE_SCRIPTS:
        return
    src_dir = OUT_DIR / "source_scripts"
    src_dir.mkdir(parents=True, exist_ok=True)
    # 复制本脚本
    shutil.copy2(Path(__file__), src_dir / Path(__file__).name)
    # 复制构造脚本
    for item in SOURCE_SCRIPTS:
        p = SCRIPT_DIR / item["file"]
        if p.exists():
            shutil.copy2(p, src_dir / p.name)


# =========================================================
# 6. 主程序
# =========================================================
def main():
    ensure_dirs()
    copy_sources_for_reproducibility()

    rng_global = np.random.default_rng(RANDOM_SEED)
    idx = START_INDEX
    rows = []

    qc_seen_structure_family = set()

    print(
        f"Start generating multi-structure stationary BWE dataset: "
        f"{len(SOURCE_SCRIPTS)} structures × {NUM_PER_STRUCTURE} samples, "
        f"same-size {N2}x{N1}, no noise."
    )

    for s_i, item in enumerate(SOURCE_SCRIPTS):
        structure = item["name"]
        script_path = SCRIPT_DIR / item["file"]
        GeneratorClass = load_generator_class(script_path, module_name=f"gen_{structure}")

        family_plan = make_family_plan(NUM_PER_STRUCTURE, rng_global)
        print(f"\n[STRUCTURE] {structure} from {item['file']} | plan={dict(Counter(family_plan))}")

        for j in range(NUM_PER_STRUCTURE):
            sample_seed = int(RANDOM_SEED * 100000 + s_i * 10000 + j)
            wavelet_rng = np.random.default_rng(sample_seed + 777)

            # 1) 生成反射系数结构
            model = generate_reflectivity(GeneratorClass, seed=sample_seed, n1=N1, n2=N2)

            # 2) 生成同源 stationary 窄带/宽带子波
            forced_family = family_plan[j]
            w_lq, w_gt, meta_w = make_stationary_wavelet_pair(
                wavelet_rng,
                forced_family=forced_family,
                dt=DT,
                length=WAVELET_LENGTH,
            )

            # 3) 同一反射系数模型分别卷积
            lq = convolve_along_depth(model, w_lq)
            gt = convolve_along_depth(model, w_gt)

            # 4) 共享归一化，保留相对振幅关系
            lq, gt, shared_scale = normalize_pair_shared(lq, gt, percentile=99.5, scale_floor=1e-6)

            stem = f"{idx:04d}"
            fname = f"{stem}.dat"

            lq.astype(np.float32).tofile(LQ_DIR / fname)
            gt.astype(np.float32).tofile(GT_DIR / fname)
            np.save(WAVELET_DIR / f"{stem}_w_lq.npy", w_lq.astype(np.float32))
            np.save(WAVELET_DIR / f"{stem}_w_gt.npy", w_gt.astype(np.float32))

            meta = dict(meta_w)
            meta.update({
                "id": stem,
                "structure": structure,
                "source_script": item["file"],
                "seed": sample_seed,
                "n1": N1,
                "n2": N2,
                "dt": DT,
                "wavelet_length": WAVELET_LENGTH,
                "shared_scale": sanitize_float(shared_scale),
            })

            meta_path = META_DIR / f"{stem}.json"
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)

            need_qc = (
                (idx - START_INDEX) < QC_FIRST_N
                or ((idx - START_INDEX + 1) % QC_EVERY == 0)
                or ((structure, meta["family"]) not in qc_seen_structure_family)
            )
            if need_qc:
                save_qc_figure(lq, gt, w_lq, w_gt, meta, QC_DIR / f"{stem}_qc.png", dt=DT)
                qc_seen_structure_family.add((structure, meta["family"]))

            row = {
                "id": stem,
                "structure": structure,
                "family": meta["family"],
                "phase_deg": meta["phase_deg"],
                "phase_group": phase_group(meta["phase_deg"]),
                "lq_path": str(LQ_DIR / fname),
                "gt_path": str(GT_DIR / fname),
                "meta_path": str(meta_path),
                "w_lq_path": str(WAVELET_DIR / f"{stem}_w_lq.npy"),
                "w_gt_path": str(WAVELET_DIR / f"{stem}_w_gt.npy"),
            }
            rows.append(row)

            if (j + 1) % 20 == 0 or (j + 1) == NUM_PER_STRUCTURE:
                print(
                    f"  [{j + 1:04d}/{NUM_PER_STRUCTURE}] latest id={stem}, "
                    f"family={meta['family']}, phase={meta['phase_deg']:.2f}"
                )

            idx += 1

    write_summary_csv(rows)
    print(f"\nAll done. Dataset saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
