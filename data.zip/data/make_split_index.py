# -*- coding: utf-8 -*-
import csv
import json
import random
import shutil
from pathlib import Path
from collections import Counter, defaultdict


# =========================
# 你只需要改这里
# =========================
BASE_DIR = Path(
    r"C:\Users\uiuili\Desktop\dateset0309\dataset_waveform_bwe_multistruct_stationary_v2_stronger_ok"
)

VAL_RATIO = 0.10          # 10% 作为验证集
SEED = 2026               # 固定随机种子，保证可复现
PHASE_EPS = 1e-6          # 判断是否为零相位
COPY_FILES = True         # True：同时复制 train/val 文件夹；False：只生成 split_index.csv


# =========================
# 自动路径
# =========================
LQ_DIR = BASE_DIR / "lq"
GT_DIR = BASE_DIR / "gt"
META_DIR = BASE_DIR / "meta"
WAVELET_DIR = BASE_DIR / "wavelets"

OUT_CSV = BASE_DIR / "split_index.csv"
OUT_COUNT_JSON = BASE_DIR / "split_count.json"

SPLIT_DIR = BASE_DIR.parent / (BASE_DIR.name + "_split")
TRAIN_LQ_DIR = SPLIT_DIR / "train" / "lq"
TRAIN_GT_DIR = SPLIT_DIR / "train" / "gt"
TRAIN_META_DIR = SPLIT_DIR / "train" / "meta"
TRAIN_WAVELET_DIR = SPLIT_DIR / "train" / "wavelets"

VAL_LQ_DIR = SPLIT_DIR / "val" / "lq"
VAL_GT_DIR = SPLIT_DIR / "val" / "gt"
VAL_META_DIR = SPLIT_DIR / "val" / "meta"
VAL_WAVELET_DIR = SPLIT_DIR / "val" / "wavelets"


def get_phase_group(phase_deg: float) -> str:
    if abs(float(phase_deg)) <= PHASE_EPS:
        return "zero_phase"
    return "with_phase"


def load_all_samples():
    rows = []

    meta_files = sorted(META_DIR.glob("*.json"))
    if len(meta_files) == 0:
        raise RuntimeError(f"没有找到 meta 文件：{META_DIR}")

    for meta_path in meta_files:
        sample_id = meta_path.stem

        with open(meta_path, "r", encoding="utf-8") as f:
            meta = json.load(f)

        family = str(meta.get("family", "unknown"))
        phase_deg = float(meta.get("phase_deg", 0.0))
        phase_group = get_phase_group(phase_deg)

        lq_path = LQ_DIR / f"{sample_id}.dat"
        gt_path = GT_DIR / f"{sample_id}.dat"

        w_lq_path = WAVELET_DIR / f"{sample_id}_w_lq.npy"
        w_gt_path = WAVELET_DIR / f"{sample_id}_w_gt.npy"

        if not lq_path.exists():
            raise FileNotFoundError(f"缺少 LQ 文件：{lq_path}")
        if not gt_path.exists():
            raise FileNotFoundError(f"缺少 GT 文件：{gt_path}")

        row = {
            "id": sample_id,
            "family": family,
            "phase_deg": phase_deg,
            "phase_group": phase_group,
            "strata": f"{family}_{phase_group}",
            "split": "",

            "lq_path": str(lq_path),
            "gt_path": str(gt_path),
            "meta_path": str(meta_path),
            "w_lq_path": str(w_lq_path) if w_lq_path.exists() else "",
            "w_gt_path": str(w_gt_path) if w_gt_path.exists() else "",
        }

        rows.append(row)

    return rows


def stratified_split(rows):
    """
    按 family + phase_group 分层划分。
    例如：
    ricker_zero_phase
    ricker_with_phase
    ormsby_zero_phase
    ormsby_with_phase
    klauder_zero_phase
    klauder_with_phase
    """
    rng = random.Random(SEED)

    groups = defaultdict(list)
    for row in rows:
        groups[row["strata"]].append(row)

    train_rows = []
    val_rows = []

    for strata, items in groups.items():
        items = items[:]
        rng.shuffle(items)

        n = len(items)
        if n == 1:
            n_val = 0
        else:
            n_val = max(1, int(round(n * VAL_RATIO)))

        val_part = items[:n_val]
        train_part = items[n_val:]

        for r in train_part:
            r["split"] = "train"

        for r in val_part:
            r["split"] = "val"

        train_rows.extend(train_part)
        val_rows.extend(val_part)

    all_rows = train_rows + val_rows
    all_rows = sorted(all_rows, key=lambda x: int(x["id"]))

    return all_rows


def write_split_csv(rows):
    fieldnames = [
        "id",
        "family",
        "phase_deg",
        "phase_group",
        "strata",
        "split",
        "lq_path",
        "gt_path",
        "meta_path",
        "w_lq_path",
        "w_gt_path",
    ]

    with open(OUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

    print(f"[SAVE] split_index.csv saved to: {OUT_CSV}")


def write_count_json(rows):
    count = {
        "total": len(rows),
        "by_split": Counter(),
        "by_family": Counter(),
        "by_phase_group": Counter(),
        "by_strata": Counter(),
        "by_split_family": Counter(),
        "by_split_phase": Counter(),
        "by_split_strata": Counter(),
    }

    for r in rows:
        split = r["split"]
        family = r["family"]
        phase_group = r["phase_group"]
        strata = r["strata"]

        count["by_split"][split] += 1
        count["by_family"][family] += 1
        count["by_phase_group"][phase_group] += 1
        count["by_strata"][strata] += 1

        count["by_split_family"][f"{split}_{family}"] += 1
        count["by_split_phase"][f"{split}_{phase_group}"] += 1
        count["by_split_strata"][f"{split}_{strata}"] += 1

    # Counter 转普通 dict，方便保存 json
    count = {
        k: dict(v) if isinstance(v, Counter) else v
        for k, v in count.items()
    }

    with open(OUT_COUNT_JSON, "w", encoding="utf-8") as f:
        json.dump(count, f, ensure_ascii=False, indent=2)

    print(f"[SAVE] split_count.json saved to: {OUT_COUNT_JSON}")

    print("\n========== Split Summary ==========")
    print("Total:", count["total"])
    print("By split:", count["by_split"])
    print("By family:", count["by_family"])
    print("By phase:", count["by_phase_group"])
    print("By strata:", count["by_strata"])
    print("By split-family:", count["by_split_family"])
    print("By split-strata:", count["by_split_strata"])


def copy_one(src, dst):
    src = Path(src)
    dst = Path(dst)

    if str(src) == "" or not src.exists():
        return

    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def copy_split_files(rows):
    for d in [
        TRAIN_LQ_DIR, TRAIN_GT_DIR, TRAIN_META_DIR, TRAIN_WAVELET_DIR,
        VAL_LQ_DIR, VAL_GT_DIR, VAL_META_DIR, VAL_WAVELET_DIR,
    ]:
        d.mkdir(parents=True, exist_ok=True)

    for r in rows:
        sample_id = r["id"]
        split = r["split"]

        if split == "train":
            out_lq_dir = TRAIN_LQ_DIR
            out_gt_dir = TRAIN_GT_DIR
            out_meta_dir = TRAIN_META_DIR
            out_wavelet_dir = TRAIN_WAVELET_DIR
        elif split == "val":
            out_lq_dir = VAL_LQ_DIR
            out_gt_dir = VAL_GT_DIR
            out_meta_dir = VAL_META_DIR
            out_wavelet_dir = VAL_WAVELET_DIR
        else:
            raise ValueError(f"未知 split: {split}")

        copy_one(r["lq_path"], out_lq_dir / f"{sample_id}.dat")
        copy_one(r["gt_path"], out_gt_dir / f"{sample_id}.dat")
        copy_one(r["meta_path"], out_meta_dir / f"{sample_id}.json")

        copy_one(r["w_lq_path"], out_wavelet_dir / f"{sample_id}_w_lq.npy")
        copy_one(r["w_gt_path"], out_wavelet_dir / f"{sample_id}_w_gt.npy")

    print(f"\n[COPY] split dataset saved to: {SPLIT_DIR}")


def main():
    rows = load_all_samples()
    rows = stratified_split(rows)

    write_split_csv(rows)
    write_count_json(rows)

    if COPY_FILES:
        copy_split_files(rows)

    print("\n[DONE]")


if __name__ == "__main__":
    main()