# -*- coding: utf-8 -*-
r"""
Multi-structure time-space-varying waveform-preserving bandwidth-extension dataset generator.

目标：
- 多结构 + 三类子波：Ricker / Ormsby / Klauder
- time-space-varying wavelet: 子波参数同时随深度/时间 t 和横向位置 x 变化
- 无噪声、同尺寸 LQ/GT（512x512 -> 512x512）
- LQ/GT 同源：每个局部 (x,t) 位置的 GT 宽频子波包络 LQ 窄带子波

使用方式：
1. 把本脚本放到 multi_structure_timespace_ormsby_bwe_v1.py 同一目录；
2. 同目录中保留你的结构生成脚本：
   dongyingbatch.py / helanjinhaiyanpendi.py / huazhuang.py / ...
3. 运行：
   python multi_structure_timespace_threewavelet_bwe_v1.py

说明：
- 本脚本复用你已经验证合格的 Ormsby 时空变脚本中的结构生成、非平稳卷积、归一化等基础函数；
- 新增 Ricker 和 Klauder 的时空变参数场；
- 通过 FAMILY_POOL 控制是否只生成某一类或三类混合。
"""

import csv
import json
import shutil
from pathlib import Path
from collections import Counter

import numpy as np
import matplotlib.pyplot as plt

import multi_structure_timespace_ormsby_bwe_v1 as base


# =========================================================
# 0. 配置区：主要改这里
# =========================================================
SCRIPT_DIR = Path(__file__).resolve().parent

SOURCE_SCRIPTS = base.SOURCE_SCRIPTS

# 先小规模 QC。满意后再改成 50、300 或 500。
NUM_PER_STRUCTURE = 5

# 生成哪些子波：
# 只测 Ricker:  ["ricker"]
# 只测 Klauder: ["klauder"]
# 三类混合:     ["ricker", "ormsby", "klauder"]
FAMILY_POOL = ["ricker", "ormsby", "klauder"]

N1 = 512  # sample/depth/time axis
N2 = 512  # trace/x axis
DT = 0.004
WAVELET_LENGTH = 0.256

# 时空变非平稳卷积参数
TIME_WIN = 128
TIME_STEP = 32
X_GROUP = 8

OUT_DIR = SCRIPT_DIR / "dataset_waveform_bwe_multistruct_timespace_threewavelet_v1"
LQ_DIR = OUT_DIR / "lq"
GT_DIR = OUT_DIR / "gt"
META_DIR = OUT_DIR / "meta"
WAVELET_DIR = OUT_DIR / "wavelets"
QC_DIR = OUT_DIR / "qc"

START_INDEX = 1
RANDOM_SEED = 2026
COPY_SOURCE_SCRIPTS = True

REP_XS = [0.15, 0.50, 0.85]
REP_DEPTHS = [0.15, 0.50, 0.85]
REP_X_NAMES = ["left", "middle", "right"]
REP_D_NAMES = ["top", "middle", "bottom"]

PHASE_PROB = base.PHASE_PROB
PHASE_RANGE = base.PHASE_RANGE
PHASE_DEPTH_DRIFT_RANGE = base.PHASE_DEPTH_DRIFT_RANGE
PHASE_X_DRIFT_RANGE = base.PHASE_X_DRIFT_RANGE

QC_FIRST_N = 12
QC_EVERY = 50

# 共享归一化百分位。若 trace 中频繁顶到 ±1，可改为 99.9 或 99.95。
NORMALIZE_PERCENTILE = 99.5


def ensure_dirs():
    for d in [LQ_DIR, GT_DIR, META_DIR, WAVELET_DIR, QC_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def sanitize_float(x):
    return base.sanitize_float(x)


# =========================================================
# 1. 共用插值与频谱工具
# =========================================================
def interp_grid_2d(x_norm, depth_norm, grid, x_anchors, depth_anchors):
    """Bilinear interpolation over [depth_anchor, x_anchor]."""
    x_norm = float(np.clip(x_norm, 0.0, 1.0))
    depth_norm = float(np.clip(depth_norm, 0.0, 1.0))
    grid = np.asarray(grid, dtype=np.float64)

    vals_d = np.zeros((len(depth_anchors),) + grid.shape[2:], dtype=np.float64)
    for d in range(len(depth_anchors)):
        if grid.ndim == 3:
            for k in range(grid.shape[2]):
                vals_d[d, k] = np.interp(x_norm, x_anchors, grid[d, :, k])
        else:
            vals_d[d] = np.interp(x_norm, x_anchors, grid[d, :])

    if grid.ndim == 3:
        out = np.zeros((grid.shape[2],), dtype=np.float64)
        for k in range(grid.shape[2]):
            out[k] = np.interp(depth_norm, depth_anchors, vals_d[:, k])
        return out
    return float(np.interp(depth_norm, depth_anchors, vals_d))


def ricker_amp_spectrum(freqs, f0):
    freqs = np.asarray(freqs, dtype=np.float64)
    x = np.maximum(freqs / (float(f0) + 1e-12), 0.0)
    amp = (x ** 2) * np.exp(1.0 - x ** 2)
    amp[0] = 0.0
    return amp / (np.max(amp) + 1e-12)


def generalized_ricker_amp_spectrum(freqs, f0, alpha=1.15, power=1.30):
    freqs = np.asarray(freqs, dtype=np.float64)
    x = np.maximum(freqs / (float(f0) + 1e-12), 0.0)
    alpha = float(alpha)
    power = float(power)
    amp = (x ** alpha) * np.exp((alpha / (power + 1e-12)) * (1.0 - x ** power))
    amp[0] = 0.0
    return amp / (np.max(amp) + 1e-12)


def ricker_pair_from_params(f0_lq, alpha_gt, power_gt, gamma_gt, phase_deg, dt=0.004, length=0.256):
    n = len(base.time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)

    A_lq = ricker_amp_spectrum(freqs, f0_lq)
    A_wide = generalized_ricker_amp_spectrum(freqs, f0=f0_lq, alpha=alpha_gt, power=power_gt)
    A_wide = A_wide ** float(gamma_gt)
    A_gt = base.smooth_max(A_wide, A_lq, p=8.0)
    A_gt *= base.high_frequency_taper(freqs, f_start=108.0, f_end=124.0)
    A_gt[0] = 0.0
    A_gt = A_gt / (np.max(A_gt) + 1e-12)

    w_lq0 = base.centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = base.centered_wavelet_from_amp(A_gt, n, nfft)
    return base.phase_rotate(w_lq0, phase_deg), base.phase_rotate(w_gt0, phase_deg), A_lq, A_gt, freqs


def spectral_centroid(freqs, amp):
    amp = np.maximum(np.asarray(amp, dtype=np.float64), 0.0)
    return float(np.sum(freqs * amp) / (np.sum(amp) + 1e-12))


def cosine_sweep_band_amp(freqs, f_start, f_end, taper=4.0):
    """Klauder-like zero-phase equivalent: tapered sweep-band amplitude spectrum."""
    freqs = np.asarray(freqs, dtype=np.float64)
    f_start = float(f_start)
    f_end = float(f_end)
    taper = float(max(taper, 1.0))
    amp = np.zeros_like(freqs, dtype=np.float64)

    rise0 = max(0.1, f_start - taper)
    rise1 = f_start
    fall0 = f_end
    fall1 = f_end + taper

    m = (freqs >= rise0) & (freqs < rise1)
    if np.any(m):
        u = (freqs[m] - rise0) / (rise1 - rise0 + 1e-12)
        amp[m] = 0.5 - 0.5 * np.cos(np.pi * u)

    amp[(freqs >= f_start) & (freqs <= f_end)] = 1.0

    m = (freqs > fall0) & (freqs <= fall1)
    if np.any(m):
        u = (freqs[m] - fall0) / (fall1 - fall0 + 1e-12)
        amp[m] = 0.5 + 0.5 * np.cos(np.pi * u)

    return np.clip(amp, 0.0, 1.0)


def klauder_pair_from_sweeps(sweep_lq, sweep_gt, taper_lq, taper_gt, phase_deg, dt=0.004, length=0.256):
    n = len(base.time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)

    A_lq = cosine_sweep_band_amp(freqs, sweep_lq[0], sweep_lq[1], taper=taper_lq)
    A_gt_raw = cosine_sweep_band_amp(freqs, sweep_gt[0], sweep_gt[1], taper=taper_gt)
    A_gt = base.smooth_max(A_gt_raw, A_lq, p=10.0)
    A_gt *= base.high_frequency_taper(freqs, f_start=108.0, f_end=124.0)
    A_gt[0] = 0.0
    A_gt = A_gt / (np.max(A_gt) + 1e-12)

    w_lq0 = base.centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = base.centered_wavelet_from_amp(A_gt, n, nfft)
    return base.phase_rotate(w_lq0, phase_deg), base.phase_rotate(w_gt0, phase_deg)


def make_phase_grid_local(rng, depth_anchors, x_anchors):
    # 使用本脚本配置，避免只修改当前文件时不生效。
    if rng.random() >= PHASE_PROB:
        phase_grid = np.zeros((len(depth_anchors), len(x_anchors)), dtype=np.float64)
        return phase_grid, 0.0

    base_phase = float(rng.uniform(PHASE_RANGE[0], PHASE_RANGE[1]))
    if abs(base_phase) < 3.0:
        base_phase = 3.0 if base_phase >= 0 else -3.0

    d_drift = float(rng.uniform(PHASE_DEPTH_DRIFT_RANGE[0], PHASE_DEPTH_DRIFT_RANGE[1]))
    x_drift = float(rng.uniform(PHASE_X_DRIFT_RANGE[0], PHASE_X_DRIFT_RANGE[1]))
    d_term = np.linspace(-0.5, 0.5, len(depth_anchors))[:, None] * d_drift
    x_term = np.linspace(-0.5, 0.5, len(x_anchors))[None, :] * x_drift
    phase_grid = base_phase + d_term + x_term
    return phase_grid.astype(np.float64), base_phase


# =========================================================
# 2. Ricker 时空变模型
# =========================================================
def make_ricker_timespace_wavelet_model(rng, dt=0.004, length=0.256):
    depth_anchors = np.array([0.0, 0.33, 0.66, 1.0], dtype=np.float64)
    x_anchors = np.array([0.0, 0.25, 0.50, 0.75, 1.0], dtype=np.float64)

    profile, profile_mode, profile_amp = base.make_space_profile(rng, x_anchors)

    # f0 随深度降低；横向按 profile 平滑调制。
    f0_top = float(rng.uniform(21.0, 30.0))
    f0_bottom = float(rng.uniform(13.0, 20.0))
    base_f0_depth = np.linspace(f0_top, f0_bottom, len(depth_anchors))

    f0_lq_grid = np.zeros((len(depth_anchors), len(x_anchors)), dtype=np.float64)
    alpha_gt_grid = np.zeros_like(f0_lq_grid)
    power_gt_grid = np.zeros_like(f0_lq_grid)
    gamma_grid = np.zeros_like(f0_lq_grid)

    for idp in range(len(depth_anchors)):
        for ix in range(len(x_anchors)):
            p = profile[ix]
            # 横向变化主要作用在 f0；深层略保守。
            f0 = base_f0_depth[idp] * (1.0 + 0.85 * (p - 1.0))
            f0 += rng.normal(0.0, 0.25)
            f0_lq_grid[idp, ix] = float(np.clip(f0, 10.0, 34.0))

            # GT 宽频包络参数。gamma 越小，宽频越强。
            d = depth_anchors[idp]
            alpha = rng.uniform(1.05, 1.35) + 0.05 * (p - 1.0)
            power = rng.uniform(1.05, 1.35) + 0.08 * (1.0 - d)
            gamma = rng.uniform(0.55, 0.78) + 0.06 * d - 0.04 * (p - 1.0)
            alpha_gt_grid[idp, ix] = float(np.clip(alpha, 0.95, 1.55))
            power_gt_grid[idp, ix] = float(np.clip(power, 1.00, 1.55))
            gamma_grid[idp, ix] = float(np.clip(gamma, 0.48, 0.86))

    phase_grid, phase_base = make_phase_grid_local(rng, depth_anchors, x_anchors)

    # 用于 QC 的 GT 谱质心锚点图。
    centroid_gt_grid = np.zeros_like(f0_lq_grid)
    for idp in range(len(depth_anchors)):
        for ix in range(len(x_anchors)):
            _, _, A_lq, A_gt, freqs = ricker_pair_from_params(
                f0_lq_grid[idp, ix],
                alpha_gt_grid[idp, ix],
                power_gt_grid[idp, ix],
                gamma_grid[idp, ix],
                phase_grid[idp, ix],
                dt=dt,
                length=length,
            )
            centroid_gt_grid[idp, ix] = spectral_centroid(freqs, A_gt)

    def wavelet_func(x_norm, depth_norm):
        f0 = interp_grid_2d(x_norm, depth_norm, f0_lq_grid, x_anchors, depth_anchors)
        alpha = interp_grid_2d(x_norm, depth_norm, alpha_gt_grid, x_anchors, depth_anchors)
        power = interp_grid_2d(x_norm, depth_norm, power_gt_grid, x_anchors, depth_anchors)
        gamma = interp_grid_2d(x_norm, depth_norm, gamma_grid, x_anchors, depth_anchors)
        phase = interp_grid_2d(x_norm, depth_norm, phase_grid, x_anchors, depth_anchors)
        centroid_gt = interp_grid_2d(x_norm, depth_norm, centroid_gt_grid, x_anchors, depth_anchors)
        w_lq, w_gt, _, _, _ = ricker_pair_from_params(f0, alpha, power, gamma, phase, dt=dt, length=length)
        return w_lq, w_gt, {
            "x_norm": sanitize_float(x_norm),
            "depth_norm": sanitize_float(depth_norm),
            "f0_lq": sanitize_float(f0),
            "alpha_gt": sanitize_float(alpha),
            "power_gt": sanitize_float(power),
            "gamma": sanitize_float(gamma),
            "phase_deg": sanitize_float(phase),
            "gt_centroid": sanitize_float(centroid_gt),
            "qc_lq": sanitize_float(f0),
            "qc_gt": sanitize_float(centroid_gt),
            "qc_lq_name": "LQ f0",
            "qc_gt_name": "GT spectral centroid",
        }

    meta = {
        "family": "ricker",
        "variation": "time_space",
        "stationary": False,
        "time_varying": True,
        "space_varying": True,
        "noise": False,
        "same_size": True,
        "phase_deg": sanitize_float(phase_base),
        "depth_anchors": [sanitize_float(x) for x in depth_anchors],
        "x_anchors": [sanitize_float(x) for x in x_anchors],
        "space_profile_mode": profile_mode,
        "space_profile_amp": sanitize_float(profile_amp),
        "space_profile": [sanitize_float(x) for x in profile],
        "f0_lq_grid": [[sanitize_float(v) for v in row] for row in f0_lq_grid],
        "alpha_gt_grid": [[sanitize_float(v) for v in row] for row in alpha_gt_grid],
        "power_gt_grid": [[sanitize_float(v) for v in row] for row in power_gt_grid],
        "gamma_grid": [[sanitize_float(v) for v in row] for row in gamma_grid],
        "gt_centroid_grid": [[sanitize_float(v) for v in row] for row in centroid_gt_grid],
        "phase_grid": [[sanitize_float(v) for v in row] for row in phase_grid],
        "qc_lq_grid_key": "f0_lq_grid",
        "qc_gt_grid_key": "gt_centroid_grid",
        "qc_lq_title": "LQ Ricker f0 map (Hz)",
        "qc_gt_title": "GT Ricker spectral centroid map (Hz)",
        "ts_rule": "Time-space-varying Ricker-derived wavelet: f0 decreases with depth and changes smoothly along x; GT uses a smooth broadband envelope while preserving the Ricker-like single-peak morphology.",
    }
    return wavelet_func, meta


# =========================================================
# 3. Klauder 时空变模型
# =========================================================
def fix_lq_sweep(start, end):
    start = float(np.clip(start, 5.0, 18.0))
    end = float(np.clip(end, start + 12.0, 58.0))
    return np.array([start, end], dtype=np.float64)


def fix_gt_sweep(start, end, lq_sweep):
    lq_sweep = np.asarray(lq_sweep, dtype=np.float64)
    start = float(np.clip(start, 2.0, lq_sweep[0] - 2.0))
    end = max(float(end), lq_sweep[1] + 20.0)
    end = float(np.clip(end, start + 25.0, 112.0))
    return np.array([start, end], dtype=np.float64)


def make_klauder_timespace_wavelet_model(rng, dt=0.004, length=0.256):
    depth_anchors = np.array([0.0, 0.33, 0.66, 1.0], dtype=np.float64)
    x_anchors = np.array([0.0, 0.25, 0.50, 0.75, 1.0], dtype=np.float64)

    profile, profile_mode, profile_amp = base.make_space_profile(rng, x_anchors)

    lq_start_top = float(rng.uniform(8.5, 13.0))
    lq_start_bottom = float(rng.uniform(6.5, 10.5))
    lq_end_top = float(rng.uniform(34.0, 45.0))
    lq_end_bottom = float(rng.uniform(25.0, 36.0))

    gt_start_top = float(rng.uniform(3.0, 6.0))
    gt_start_bottom = float(rng.uniform(2.5, 5.5))
    gt_end_top = float(rng.uniform(82.0, 108.0))
    gt_end_bottom = float(rng.uniform(62.0, 90.0))

    base_lq_start = np.linspace(lq_start_top, lq_start_bottom, len(depth_anchors))
    base_lq_end = np.linspace(lq_end_top, lq_end_bottom, len(depth_anchors))
    base_gt_start = np.linspace(gt_start_top, gt_start_bottom, len(depth_anchors))
    base_gt_end = np.linspace(gt_end_top, gt_end_bottom, len(depth_anchors))

    sweep_lq_start_grid = np.zeros((len(depth_anchors), len(x_anchors)), dtype=np.float64)
    sweep_lq_end_grid = np.zeros_like(sweep_lq_start_grid)
    sweep_gt_start_grid = np.zeros_like(sweep_lq_start_grid)
    sweep_gt_end_grid = np.zeros_like(sweep_lq_start_grid)
    taper_lq_grid = np.zeros_like(sweep_lq_start_grid)
    taper_gt_grid = np.zeros_like(sweep_lq_start_grid)

    for idp, d in enumerate(depth_anchors):
        for ix, p in enumerate(profile):
            lq_start = base_lq_start[idp] + (p - 1.0) * 3.0 + rng.normal(0.0, 0.15)
            lq_end = base_lq_end[idp] * (1.0 + 0.90 * (p - 1.0)) + rng.normal(0.0, 0.55)
            lq_sweep = fix_lq_sweep(lq_start, lq_end)

            gt_start = base_gt_start[idp] + (p - 1.0) * 1.6 + rng.normal(0.0, 0.12)
            gt_end = base_gt_end[idp] * (1.0 + 0.75 * (p - 1.0)) + rng.normal(0.0, 0.85)
            gt_sweep = fix_gt_sweep(gt_start, gt_end, lq_sweep)

            sweep_lq_start_grid[idp, ix] = lq_sweep[0]
            sweep_lq_end_grid[idp, ix] = lq_sweep[1]
            sweep_gt_start_grid[idp, ix] = gt_sweep[0]
            sweep_gt_end_grid[idp, ix] = gt_sweep[1]
            taper_lq_grid[idp, ix] = float(np.clip(rng.uniform(2.2, 4.2), 1.5, 6.0))
            taper_gt_grid[idp, ix] = float(np.clip(rng.uniform(3.0, 5.2), 2.0, 7.0))

    phase_grid, phase_base = make_phase_grid_local(rng, depth_anchors, x_anchors)

    def wavelet_func(x_norm, depth_norm):
        lq_start = interp_grid_2d(x_norm, depth_norm, sweep_lq_start_grid, x_anchors, depth_anchors)
        lq_end = interp_grid_2d(x_norm, depth_norm, sweep_lq_end_grid, x_anchors, depth_anchors)
        lq_sweep = fix_lq_sweep(lq_start, lq_end)

        gt_start = interp_grid_2d(x_norm, depth_norm, sweep_gt_start_grid, x_anchors, depth_anchors)
        gt_end = interp_grid_2d(x_norm, depth_norm, sweep_gt_end_grid, x_anchors, depth_anchors)
        gt_sweep = fix_gt_sweep(gt_start, gt_end, lq_sweep)

        taper_lq = interp_grid_2d(x_norm, depth_norm, taper_lq_grid, x_anchors, depth_anchors)
        taper_gt = interp_grid_2d(x_norm, depth_norm, taper_gt_grid, x_anchors, depth_anchors)
        phase = interp_grid_2d(x_norm, depth_norm, phase_grid, x_anchors, depth_anchors)

        w_lq, w_gt = klauder_pair_from_sweeps(lq_sweep, gt_sweep, taper_lq, taper_gt, phase, dt=dt, length=length)
        return w_lq, w_gt, {
            "x_norm": sanitize_float(x_norm),
            "depth_norm": sanitize_float(depth_norm),
            "sweep_lq": [sanitize_float(v) for v in lq_sweep],
            "sweep_gt": [sanitize_float(v) for v in gt_sweep],
            "taper_lq": sanitize_float(taper_lq),
            "taper_gt": sanitize_float(taper_gt),
            "phase_deg": sanitize_float(phase),
            "qc_lq": sanitize_float(lq_sweep[1]),
            "qc_gt": sanitize_float(gt_sweep[1]),
            "qc_lq_name": "LQ sweep end",
            "qc_gt_name": "GT sweep end",
        }

    meta = {
        "family": "klauder",
        "variation": "time_space",
        "stationary": False,
        "time_varying": True,
        "space_varying": True,
        "noise": False,
        "same_size": True,
        "phase_deg": sanitize_float(phase_base),
        "depth_anchors": [sanitize_float(x) for x in depth_anchors],
        "x_anchors": [sanitize_float(x) for x in x_anchors],
        "space_profile_mode": profile_mode,
        "space_profile_amp": sanitize_float(profile_amp),
        "space_profile": [sanitize_float(x) for x in profile],
        "sweep_lq_start_grid": [[sanitize_float(v) for v in row] for row in sweep_lq_start_grid],
        "sweep_lq_end_grid": [[sanitize_float(v) for v in row] for row in sweep_lq_end_grid],
        "sweep_gt_start_grid": [[sanitize_float(v) for v in row] for row in sweep_gt_start_grid],
        "sweep_gt_end_grid": [[sanitize_float(v) for v in row] for row in sweep_gt_end_grid],
        "taper_lq_grid": [[sanitize_float(v) for v in row] for row in taper_lq_grid],
        "taper_gt_grid": [[sanitize_float(v) for v in row] for row in taper_gt_grid],
        "phase_grid": [[sanitize_float(v) for v in row] for row in phase_grid],
        "qc_lq_grid_key": "sweep_lq_end_grid",
        "qc_gt_grid_key": "sweep_gt_end_grid",
        "qc_lq_title": "LQ Klauder sweep-end map (Hz)",
        "qc_gt_title": "GT Klauder sweep-end map (Hz)",
        "ts_rule": "Time-space-varying Klauder-like wavelet represented by a tapered sweep-band spectrum; sweep-end decreases with depth and changes smoothly along x; GT sweep range envelopes LQ.",
    }
    return wavelet_func, meta


def make_wavelet_model_by_family(family, rng, dt=0.004, length=0.256):
    family = str(family).lower()

    if family == "ormsby":
        # base 版 Ormsby 局部 meta 只保存 band_lq / band_gt，
        # 而三子波通用 QC 需要 qc_lq / qc_gt 字段。
        # 这里做一个轻量包装，不改变子波生成和卷积逻辑，只补充 QC 所需字段。
        raw_wavelet_func, meta = base.make_ormsby_timespace_wavelet_model(
            rng,
            dt=dt,
            length=length,
        )

        def wavelet_func(x_norm, depth_norm):
            w_lq, w_gt, local_meta = raw_wavelet_func(x_norm, depth_norm)

            if "qc_lq" not in local_meta:
                local_meta["qc_lq"] = sanitize_float(local_meta["band_lq"][3])
            if "qc_gt" not in local_meta:
                local_meta["qc_gt"] = sanitize_float(local_meta["band_gt"][3])

            local_meta.setdefault("qc_lq_name", "LQ f4")
            local_meta.setdefault("qc_gt_name", "GT f4")

            return w_lq, w_gt, local_meta

        meta.setdefault("qc_lq_title", "LQ Ormsby f4 map (Hz)")
        meta.setdefault("qc_gt_title", "GT Ormsby f4 map (Hz)")

        return wavelet_func, meta

    if family == "ricker":
        return make_ricker_timespace_wavelet_model(rng, dt=dt, length=length)

    if family == "klauder":
        return make_klauder_timespace_wavelet_model(rng, dt=dt, length=length)

    raise ValueError(f"Unknown family: {family}")


# =========================================================
# 4. 通用 QC 图
# =========================================================
def interp_qc_map(meta, key):
    x_vals = np.linspace(0, 1, N2)
    d_vals = np.linspace(0, 1, N1)
    depth_anchors = np.asarray(meta["depth_anchors"], dtype=np.float64)
    x_anchors = np.asarray(meta["x_anchors"], dtype=np.float64)
    grid = np.asarray(meta[key], dtype=np.float64)

    temp = np.zeros((len(depth_anchors), N2), dtype=np.float32)
    for idp in range(len(depth_anchors)):
        temp[idp, :] = np.interp(x_vals, x_anchors, grid[idp, :])
    out = np.zeros((N1, N2), dtype=np.float32)
    for ix in range(N2):
        out[:, ix] = np.interp(d_vals, depth_anchors, temp[:, ix])
    return out


def get_qc_maps(meta):
    family = meta["family"]
    if family == "ormsby":
        # Ormsby 用 f4 图；保持和已验证版本一致。
        band_lq_grid = np.asarray(meta["band_lq_grid"], dtype=np.float64)
        band_gt_grid = np.asarray(meta["band_gt_grid"], dtype=np.float64)
        meta_lq = dict(meta)
        meta_gt = dict(meta)
        meta_lq["_tmp_lq_f4_grid"] = band_lq_grid[:, :, 3].tolist()
        meta_gt["_tmp_gt_f4_grid"] = band_gt_grid[:, :, 3].tolist()
        return (
            interp_qc_map(meta_lq, "_tmp_lq_f4_grid"),
            interp_qc_map(meta_gt, "_tmp_gt_f4_grid"),
            "LQ Ormsby f4 map (Hz)",
            "GT Ormsby f4 map (Hz)",
        )
    return (
        interp_qc_map(meta, meta["qc_lq_grid_key"]),
        interp_qc_map(meta, meta["qc_gt_grid_key"]),
        meta.get("qc_lq_title", "LQ parameter map"),
        meta.get("qc_gt_title", "GT parameter map"),
    )


def save_qc_figure_timespace_generic(lq, gt, rep_w_lq, rep_w_gt, rep_metas, meta, out_png, dt=0.004):
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)

    clip = np.percentile(np.abs(np.concatenate([lq.reshape(-1), gt.reshape(-1)])), 99.0)
    clip = max(float(clip), 1e-6)
    x_trace = lq.shape[0] // 2

    fig = plt.figure(figsize=(22, 15), dpi=140)

    ax1 = plt.subplot(4, 3, 1)
    ax1.imshow(lq.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax1.set_title(f"LQ narrow-band, {meta['family']} time-space-varying")

    ax2 = plt.subplot(4, 3, 2)
    ax2.imshow(gt.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax2.set_title(f"GT broadband, {meta['family']} time-space-varying")

    ax3 = plt.subplot(4, 3, 3)
    ax3.plot(lq[x_trace, :], label="lq")
    ax3.plot(gt[x_trace, :], label="gt")
    ax3.set_title(f"Trace comparison x={x_trace}")
    ax3.legend(fontsize=8)
    ax3.grid(True, alpha=0.2)

    lq_map, gt_map, lq_title, gt_title = get_qc_maps(meta)
    ax4 = plt.subplot(4, 3, 4)
    im4 = ax4.imshow(lq_map, cmap="turbo", aspect="auto", origin="upper")
    ax4.set_title(lq_title)
    fig.colorbar(im4, ax=ax4, shrink=0.75)

    ax5 = plt.subplot(4, 3, 5)
    im5 = ax5.imshow(gt_map, cmap="turbo", aspect="auto", origin="upper")
    ax5.set_title(gt_title)
    fig.colorbar(im5, ax=ax5, shrink=0.75)

    ax6 = plt.subplot(4, 3, 6)
    mid_x = 1
    mid_d = 1
    qlq_name = rep_metas[mid_d][mid_x].get("qc_lq_name", "LQ param")
    qgt_name = rep_metas[mid_d][mid_x].get("qc_gt_name", "GT param")
    ax6.plot(REP_DEPTHS, [rep_metas[i][mid_x]["qc_lq"] for i in range(3)], marker="o", label=f"{qlq_name} @ middle x")
    ax6.plot(REP_DEPTHS, [rep_metas[i][mid_x]["qc_gt"] for i in range(3)], marker="o", label=f"{qgt_name} @ middle x")
    ax6.plot(REP_XS, [rep_metas[mid_d][j]["qc_lq"] for j in range(3)], marker="s", label=f"{qlq_name} @ middle depth")
    ax6.plot(REP_XS, [rep_metas[mid_d][j]["qc_gt"] for j in range(3)], marker="s", label=f"{qgt_name} @ middle depth")
    ax6.set_title("Representative parameter trends")
    ax6.set_xlabel("normalized coordinate")
    ax6.set_ylabel("Hz")
    ax6.legend(fontsize=7)
    ax6.grid(True, alpha=0.25)

    for idp, dname in enumerate(REP_D_NAMES):
        ax = plt.subplot(4, 3, 7 + idp)
        for ix, xname in enumerate(REP_X_NAMES):
            f_lq, a_lq = base.amplitude_spectrum(rep_w_lq[idp, ix], dt=dt)
            f_gt, a_gt = base.amplitude_spectrum(rep_w_gt[idp, ix], dt=dt)
            ax.plot(f_lq, a_lq, linestyle="--", linewidth=1.0, label=f"{xname} lq")
            ax.plot(f_gt, a_gt, linestyle="-", linewidth=1.0, label=f"{xname} gt")
        ax.set_xlim(0, 120)
        ax.set_ylim(0, 1.08)
        ax.set_title(f"Representative spectra: {dname}")
        ax.legend(fontsize=6, ncol=2)
        ax.grid(True, alpha=0.20)

    ax10 = plt.subplot(4, 3, 10)
    ax10.axis("off")
    local_show = []
    for idp, dname in enumerate(REP_D_NAMES):
        for ix, xname in enumerate(REP_X_NAMES):
            m = rep_metas[idp][ix]
            item = {"pos": f"{xname}-{dname}", "qc_lq": round(m["qc_lq"], 2), "qc_gt": round(m["qc_gt"], 2)}
            if "band_lq" in m:
                item["lq_band"] = [round(v, 2) for v in m["band_lq"]]
                item["gt_band"] = [round(v, 2) for v in m["band_gt"]]
            if "f0_lq" in m:
                item.update({"f0_lq": round(m["f0_lq"], 2), "gt_centroid": round(m["gt_centroid"], 2)})
            if "sweep_lq" in m:
                item.update({"sweep_lq": [round(v, 2) for v in m["sweep_lq"]], "sweep_gt": [round(v, 2) for v in m["sweep_gt"]]})
            local_show.append(item)
    ax10.text(0, 1, json.dumps(local_show, ensure_ascii=False, indent=2), va="top", ha="left", fontsize=6.5, family="monospace")
    ax10.set_title("3x3 local meta")

    ax11 = plt.subplot(4, 3, 11)
    ax11.axis("off")
    meta_show = dict(meta)
    for k in list(meta_show.keys()):
        if k.endswith("_grid") or k in ["band_lq_grid", "band_gt_grid", "phase_grid"]:
            meta_show[k] = "see json/npz"
    txt = json.dumps(meta_show, ensure_ascii=False, indent=2)
    ax11.text(0, 1, txt, va="top", ha="left", fontsize=6.5, family="monospace")
    ax11.set_title("global meta")

    ax12 = plt.subplot(4, 3, 12)
    ax12.axis("off")
    ax12.text(
        0, 1,
        "QC checklist:\n"
        "1) GT spectra envelope LQ at 3x3 positions.\n"
        "2) Parameter map changes along both depth and x.\n"
        "3) LQ/GT sections show no obvious vertical stripes.\n"
        "4) LQ/GT sections show no obvious time-window seams.\n"
        "5) Phase/peak positions remain consistent between LQ and GT.",
        va="top", ha="left", fontsize=9,
    )

    plt.tight_layout()
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)


# =========================================================
# 5. 索引、复现信息
# =========================================================
def write_summary_csv(rows):
    out_csv = OUT_DIR / "sample_index.csv"
    fields = [
        "id", "structure", "family", "variation", "phase_deg", "phase_group",
        "space_profile_mode", "lq_path", "gt_path", "meta_path", "wavelet_field_path", "w_lq_path", "w_gt_path",
    ]
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})
    print(f"[SAVE] sample_index.csv: {out_csv}")

    counts = {
        "total": len(rows),
        "by_structure": dict(Counter(r["structure"] for r in rows)),
        "by_family": dict(Counter(r["family"] for r in rows)),
        "by_phase_group": dict(Counter(r["phase_group"] for r in rows)),
        "by_space_profile_mode": dict(Counter(r["space_profile_mode"] for r in rows)),
    }
    out_json = OUT_DIR / "sample_count.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(counts, f, ensure_ascii=False, indent=2)
    print(f"[SAVE] sample_count.json: {out_json}")
    print(json.dumps(counts, ensure_ascii=False, indent=2))


def copy_sources_for_reproducibility():
    if not COPY_SOURCE_SCRIPTS:
        return
    src_dir = OUT_DIR / "source_scripts"
    src_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(__file__), src_dir / Path(__file__).name)
    old = SCRIPT_DIR / "multi_structure_timespace_ormsby_bwe_v1.py"
    if old.exists():
        shutil.copy2(old, src_dir / old.name)
    for item in SOURCE_SCRIPTS:
        p = SCRIPT_DIR / item["file"]
        if p.exists():
            shutil.copy2(p, src_dir / p.name)


def make_npz_for_meta(meta, rep_w_lq, rep_w_gt):
    payload = {
        "rep_xs": np.asarray(REP_XS, dtype=np.float32),
        "rep_depths": np.asarray(REP_DEPTHS, dtype=np.float32),
        "rep_w_lq": rep_w_lq.astype(np.float32),
        "rep_w_gt": rep_w_gt.astype(np.float32),
        "x_anchors": np.asarray(meta["x_anchors"], dtype=np.float32),
        "depth_anchors": np.asarray(meta["depth_anchors"], dtype=np.float32),
    }
    for k, v in meta.items():
        if k.endswith("_grid") or k in ["band_lq_grid", "band_gt_grid", "phase_grid"]:
            try:
                payload[k] = np.asarray(v, dtype=np.float32)
            except Exception:
                pass
    return payload


# =========================================================
# 6. 主程序
# =========================================================
def main():
    ensure_dirs()
    copy_sources_for_reproducibility()

    idx = START_INDEX
    rows = []

    print(
        f"Start generating THREE-WAVELET TIME-SPACE-VARYING BWE dataset: "
        f"families={FAMILY_POOL}, {len(SOURCE_SCRIPTS)} structures × {NUM_PER_STRUCTURE} samples, "
        f"same-size {N2}x{N1}, no noise, x_group={X_GROUP}, time_win={TIME_WIN}, time_step={TIME_STEP}."
    )

    for s_i, item in enumerate(SOURCE_SCRIPTS):
        structure = item["name"]
        script_path = SCRIPT_DIR / item["file"]
        GeneratorClass = base.load_generator_class(script_path, module_name=f"gen_{structure}")
        print(f"\n[STRUCTURE] {structure} from {item['file']}")

        for j in range(NUM_PER_STRUCTURE):
            family = FAMILY_POOL[(s_i * NUM_PER_STRUCTURE + j) % len(FAMILY_POOL)]
            sample_seed = int(RANDOM_SEED * 100000 + s_i * 10000 + j)
            wavelet_rng = np.random.default_rng(sample_seed + 999)

            model = base.generate_reflectivity(GeneratorClass, seed=sample_seed, n1=N1, n2=N2)

            wavelet_func, meta_w = make_wavelet_model_by_family(family, wavelet_rng, dt=DT, length=WAVELET_LENGTH)

            lq, gt, local_records = base.convolve_time_space_varying(
                model,
                wavelet_func,
                time_win=TIME_WIN,
                time_step=TIME_STEP,
                x_group=X_GROUP,
            )

            lq, gt, shared_scale = base.normalize_pair_shared(
                lq,
                gt,
                percentile=NORMALIZE_PERCENTILE,
                scale_floor=1e-6,
            )

            rep_w_lq, rep_w_gt, rep_metas = base.collect_representative_wavelets(wavelet_func)

            stem = f"{idx:04d}"
            fname = f"{stem}.dat"
            lq.astype(np.float32).tofile(LQ_DIR / fname)
            gt.astype(np.float32).tofile(GT_DIR / fname)

            center_d = len(REP_DEPTHS) // 2
            center_x = len(REP_XS) // 2
            w_lq_path = WAVELET_DIR / f"{stem}_w_lq.npy"
            w_gt_path = WAVELET_DIR / f"{stem}_w_gt.npy"
            np.save(w_lq_path, rep_w_lq[center_d, center_x].astype(np.float32))
            np.save(w_gt_path, rep_w_gt[center_d, center_x].astype(np.float32))

            meta = dict(meta_w)
            meta.update({
                "id": stem,
                "structure": structure,
                "source_script": item["file"],
                "seed": int(sample_seed),
                "n1": int(N1),
                "n2": int(N2),
                "dt": float(DT),
                "wavelet_length": float(WAVELET_LENGTH),
                "time_win": int(TIME_WIN),
                "time_step": int(TIME_STEP),
                "x_group": int(X_GROUP),
                "representative_xs": [sanitize_float(x) for x in REP_XS],
                "representative_depths": [sanitize_float(d) for d in REP_DEPTHS],
                "shared_scale": sanitize_float(shared_scale),
                "num_local_records": int(len(local_records)),
                "local_records_preview": local_records[:12],
            })

            wavelet_field_path = WAVELET_DIR / f"{stem}_wavelet_field.npz"
            np.savez_compressed(wavelet_field_path, **make_npz_for_meta(meta, rep_w_lq, rep_w_gt))

            meta_path = META_DIR / f"{stem}.json"
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)

            should_qc = idx < START_INDEX + QC_FIRST_N or (idx - START_INDEX + 1) % QC_EVERY == 0
            if should_qc:
                qc_path = QC_DIR / f"{stem}_qc.png"
                save_qc_figure_timespace_generic(lq, gt, rep_w_lq, rep_w_gt, rep_metas, meta, qc_path, dt=DT)

            rows.append({
                "id": stem,
                "structure": structure,
                "family": family,
                "variation": "time_space",
                "phase_deg": sanitize_float(meta.get("phase_deg", 0.0)),
                "phase_group": base.phase_group(meta.get("phase_deg", 0.0)),
                "space_profile_mode": meta.get("space_profile_mode", ""),
                "lq_path": str(LQ_DIR / fname),
                "gt_path": str(GT_DIR / fname),
                "meta_path": str(meta_path),
                "wavelet_field_path": str(wavelet_field_path),
                "w_lq_path": str(w_lq_path),
                "w_gt_path": str(w_gt_path),
            })

            if (idx - START_INDEX + 1) % 10 == 0:
                print(f"[{idx - START_INDEX + 1}] done. latest structure={structure}, family={family}, idx={stem}, profile={meta.get('space_profile_mode')}")

            idx += 1

    write_summary_csv(rows)
    print(f"\nAll done. Dataset saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
