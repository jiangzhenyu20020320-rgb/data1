import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter, map_coordinates


class GeologicalSeismicData:

    def __init__(self, seed=31):
        self.rng = np.random.RandomState(seed)

    def seismic_and_slopes_2d(self, n1=256, n2=512, noise=0):  # 恢复 n2=512 以获得更宽的图像

        # 1. 创建基础反射系数
        reflectivity = self._make_reflectivity_2d(n1, n2)

        # 应用分层褶皱
        lower_params = {'a1': 0, 'b1': 0.03, 'a2': 5e-5, 'b2': 5e-5}  # 低频、高幅
        upper_params = {'a1': 0, 'b1': 0.01, 'a2': 8e-4, 'b2': 8e-4}  # 高频、低幅

        reflectivity = self._apply_sinusoidal_fold_2d_layered(
            reflectivity, n1, n2,
            boundary_i1=n1 // 6,
            upper_params=upper_params,
            lower_params=lower_params
        )


        zone_params = {
            'zone_width': 8,  # 断层带宽度 (像素)
            'blur_sigma': 0.3,  # 模糊强度
            'attenuation_factor': 0.3  # 振幅衰减 (0.5 = 减弱50%)
        }
        # 4. 应用弯曲的铲状断层 (普通断层，不生长)
        fault1_params = {'x2_ref': 50, 'dip_top': 90, 'dip_bottom': 70, 'throw': 15, 'i1_start': 10,
                         'i1_end': n1, 'growth_factor': 1.2}  # 1.0 表示无生长
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault1_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault1_params, **zone_params)


        # 6. 归一化和添加噪声
        image = reflectivity
        image = image / np.std(image)  # 归一化

        if noise > 0:
            noise_array = self.rng.randn(*image.shape)
            noise_array = gaussian_filter(noise_array, sigma=2.0, order=1)
            noise_array = noise_array * noise * np.std(image) / np.std(noise_array)
            image = image + noise_array

        return image

    def _make_reflectivity_2d(self, n1, n2):
        r = 2.0 * self.rng.rand(n1) - 1.0
        # 对反射系数应用更强的对比度
        r = np.sign(r) * np.abs(r) ** 5

        # 1. 创建基础反射系数矩阵 (n2 x n1)
        reflectivity = np.tile(r[:, np.newaxis], (1, n2)).T

        # 2. 创建横向拉伸/压缩场
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        i2_norm = i2 / n2

        max_stretch_factor = 0.6  # 最大 30% 拉伸 (在左侧顶部)
        stretch_field = max_stretch_factor * (1.0 - i2_norm) * i1

        # 源坐标 i1 减去 stretch_field 相当于将地层向下拉伸 (左侧发散)
        src_i1 = np.clip(i1 - stretch_field, 0, n1 - 1)

        coords = np.array([i2.astype(float), src_i1])

        # 应用坐标变换
        return map_coordinates(reflectivity, coords, order=1, mode='nearest')

    def _apply_geometric_flexure_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, i1_start, i1_end,
                                    flexure_width, max_flexure_depth_shift, **kwargs):

        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 1. 计算断层轨迹 (与位移函数相同)
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        # 2. 确定下降盘 (Downthrown Block)
        if dip_top > 0:
            # 断层向右倾斜，下降盘在右侧 (i2 > fault_x2_trace)。
            is_downthrown = (i2 > fault_x2_trace[np.newaxis, :])
            dist_to_fault = i2 - fault_x2_trace[np.newaxis, :]
            # 挠曲方向：地层需要向下凹陷，靠近断层面。这需要 **向上** 施加垂直位移。
            shift_direction = -1  # 使目标点数据来自更浅的源点 (i1 - shift)
        else:
            # 断层向左倾斜，下降盘在左侧 (i2 < fault_x2_trace)。
            is_downthrown = (i2 < fault_x2_trace[np.newaxis, :])
            dist_to_fault = fault_x2_trace[np.newaxis, :] - i2
            # 挠曲方向：地层需要向下凹陷，靠近断层面。这需要 **向上** 施加垂直位移。
            shift_direction = -1  # 使目标点数据来自更浅的源点 (i1 - shift)

        # 3. 横向权重 (高斯衰减)
        # 高斯衰减，确保平滑过渡。sigma 约为 flexure_width/4
        sigma = flexure_width / 4.0


        # 裁剪距离，只在 flexure_width 范围内计算
        dist_clamped = np.clip(dist_to_fault, 0, flexure_width)

        # 线性衰减权重 (距离越远越小)
        horizontal_weight = (flexure_width - dist_clamped) / flexure_width

        # 4. 纵向权重 (深度相关)
        # 挠曲从 i1_start 开始，向下加剧
        i1_norm = np.clip((i1 - i1_start) / (i1_end - i1_start + 1e-6), 0, 1)

        # 我们希望挠曲在 i1_start 处为 0，向下加剧 (使用 i1_norm)
        depth_weight = i1_norm

        # 5. 计算最终垂直位移场 (Shift Field)
        # 位移最大值在断层处 (dist_to_fault=0) 和最大深度处 (i1=i1_end)
        flexure_shift = (
                max_flexure_depth_shift * horizontal_weight * depth_weight * shift_direction
        )

        # 6. 最终位移遮罩
        flexure_mask = is_downthrown & (dist_to_fault > 0) & (dist_to_fault < flexure_width) & (i1 >= i1_start) & (
                    i1 < i1_end)

        # 7. 应用位移
        src_i1 = i1.astype(float)
        src_i2 = i2.astype(float)


        src_i1[flexure_mask] = np.clip(src_i1[flexure_mask] + flexure_shift[flexure_mask], 0, n1 - 1)

        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_stratigraphic_wedge_2d(self, data, n1, n2, i1_start, i1_end, x2_start, x2_end, direction='left'):


        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 1. 定义深度遮罩
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)

        # 2. 定义尖灭区间和横向距离
        x2_min = min(x2_start, x2_end)
        x2_max = max(x2_start, x2_end)
        x2_width = x2_max - x2_min

        if x2_width <= 0:
            return data

        # 3. 计算横向衰减因子 (Attenuation Factor)

        # 限制 x2 范围在尖灭区 [x2_min, x2_max]
        x2_active = np.clip(i2, x2_min, x2_max)

        if direction == 'left':
            # 衰减因子在 x2_max 处为 1，在 x2_min 处为 0 (从右向左尖灭)
            attenuation_factor = (x2_active - x2_min) / x2_width

        elif direction == 'right':
            # 衰减因子在 x2_min 处为 1，在 x2_max 处为 0 (从左向右尖灭)
            attenuation_factor = 1.0 - (x2_active - x2_min) / x2_width
        else:
            return data

        # 4. 组合遮罩和应用衰减
        wedge_mask = depth_mask & (i2 >= x2_min) & (i2 < x2_max)  # 确保只在目标横向区域内操作

        # 仅在遮罩区域应用衰减
        data[wedge_mask] *= attenuation_factor[wedge_mask]

        return data

    def _apply_sinusoidal_fold_2d_layered(self, data, n1, n2, boundary_i1, upper_params, lower_params):

        i1_range, i2_range = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        shift = np.zeros_like(i1_range, dtype=float)

        # 上层遮罩
        mask_upper = (i1_range < boundary_i1)
        up = upper_params
        shift[mask_upper] = (up['a1'] + up['b1'] * i1_range[mask_upper]) * \
                            np.sin((up['a2'] + up['b2'] * i2_range[mask_upper]) * i2_range[mask_upper])

        # 下层遮罩
        mask_lower = (i1_range >= boundary_i1)
        low = lower_params
        shift[mask_lower] = (low['a1'] + low['b1'] * i1_range[mask_lower]) * \
                            np.sin((low['a2'] + low['b2'] * i2_range[mask_lower]) * i2_range[mask_lower])

        # 应用位移
        x1_new = i1_range - shift

        coords = np.zeros((2, n2, n1))
        coords[0, :, :] = i2_range
        coords[1, :, :] = np.clip(x1_new, 0, n1 - 1)

        return map_coordinates(data, coords.reshape(2, n2, n1), order=3, mode='nearest')



    def _apply_curved_normal_fault_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, throw, i1_start, i1_end,
                                      growth_factor=1.0):
        """
        模拟弯曲的正断层 (铲状断层)，新增对下降盘的生长效应。
        :param growth_factor: 下降盘的垂直拉伸因子 (1.0 = 无生长, 1.1 = 10% 额外拉伸)。
        """
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([i2.astype(float), i1.astype(float)])

        # 1. 计算断层轨迹 (保持不变)
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        # 2. 侧向遮罩 (Side Mask) - 确定下降盘
        if dip_top > 0:
            # 倾角为正 (>0) 意味着断层向右倾斜，右侧是下降盘
            downthrown_mask = (i2 > fault_x2_trace[np.newaxis, :])
            # 上升盘在左侧
        else:
            # 倾角为负 (<0) 意味着断层向左倾斜，左侧是下降盘
            downthrown_mask = (i2 < fault_x2_trace[np.newaxis, :])
            # 上升盘在右侧

        # 3. 深度遮罩 (Depth Mask) - 确定活动/生长地层范围
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)

        # 4. 最终位移遮罩
        fault_mask = downthrown_mask & depth_mask

        # 5. 应用位移和生长效应

        # 使用基于 i1_start 的拉伸位移
        i1_offset_from_start = coords[1][fault_mask] - i1_start

        # 生长引起的额外位移 (拉伸)
        growth_displacement = i1_offset_from_start * (growth_factor - 1.0)

        # 总位移：(断层落差) + (生长拉伸)
        total_displacement = throw + growth_displacement

        src_i1 = coords[1][fault_mask] - total_displacement

        coords[1][fault_mask] = np.clip(src_i1, 0, n1 - 1)

        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_fault_zone_attenuation_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom,
                                         zone_width, blur_sigma, attenuation_factor, i1_start, i1_end, **kwargs):
        """
        在断层路径周围应用模糊和振幅衰减
        """
        # 1. 重新计算断层路径 (与 _apply_curved_normal_fault_2d 中的几何计算完全相同)
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 1. 计算断层轨迹 (与位移函数相同)
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        # 2. 距离遮罩 (Proximity Mask)
        fault_x2_trace_grid = fault_x2_trace[np.newaxis, :]
        dist_to_fault = np.abs(i2 - fault_x2_trace_grid)
        zone_mask_proximity = (dist_to_fault <= zone_width / 2.0)

        # 3. 深度遮罩 (Depth Mask)
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)

        # 4. 最终衰减遮罩
        zone_mask = zone_mask_proximity & depth_mask

        if np.any(zone_mask):
            # 应用模糊和衰减
            blurred_data = gaussian_filter(data, sigma=blur_sigma)
            data[zone_mask] = blurred_data[zone_mask]
            data[zone_mask] *= attenuation_factor
        return data

from scipy.ndimage import gaussian_filter, zoom

def downsample_x2(img):
    img_lp = gaussian_filter(img, sigma=0.5)  # 轻微低通
    return zoom(img_lp, zoom=(0.5, 0.5), order=1).astype(np.float32)


def ricker_wavelet(f0=60.0, dt=0.004, length=0.128):
    """零相位 Ricker 子波"""
    t = np.arange(-length/2, length/2 + dt, dt, dtype=np.float32)
    a = (np.pi * f0) ** 2
    w = (1.0 - 2.0 * a * t**2) * np.exp(-a * t**2)
    return w.astype(np.float32)

def convolve_along_depth(img, wavelet):
    """
    img: (n2, n1)；沿深度 n1 方向（axis=1）卷积
    wavelet: (nw,)
    """
    n2, n1 = img.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))

    IMG = np.fft.rfft(img, n=nfft, axis=1)
    W = np.fft.rfft(wavelet, n=nfft)
    Y = IMG * W[None, :]

    y = np.fft.irfft(Y, n=nfft, axis=1)

    # same-length（居中裁剪）
    start = (nw - 1) // 2
    out = y[:, start:start + n1]
    return out.astype(np.float32)
def add_offset_noise(
    img,
    rng,
    snr_db=12.0,
    offset_exp=1.8,
    min_scale=0.35,
    max_scale=1.00,
    bandlimit=True,
    fmin=0.02,
    fmax=0.18,
):
    """
    img: (n2, n1)  # X2在第0维，深度在第1维
    """
    n2, n1 = img.shape
    x = img.astype(np.float32)

    sig_rms = np.sqrt(np.mean(x**2) + 1e-12)
    noise_rms = sig_rms / (10.0 ** (snr_db / 20.0))

    i2 = np.arange(n2, dtype=np.float32)
    center = (n2 - 1) / 2.0
    off = np.abs(i2 - center) / (center + 1e-12)

    w = min_scale + (max_scale - min_scale) * (off ** offset_exp)

    noise = rng.standard_normal((n2, n1)).astype(np.float32)
    noise *= (noise_rms * w)[:, None]

    if bandlimit:
        F = np.fft.rfft(noise, axis=1)
        freqs = np.fft.rfftfreq(n1, d=1.0)  # 归一化 0~0.5
        win = np.zeros_like(freqs, dtype=np.float32)

        tw = 0.02
        f1, f2 = max(fmin - tw, 0.0), fmin
        f3, f4 = fmax, min(fmax + tw, 0.5)

        m = (freqs >= f1) & (freqs < f2)
        if np.any(m):
            t = (freqs[m] - f1) / (f2 - f1 + 1e-12)
            win[m] = 0.5 - 0.5 * np.cos(np.pi * t)

        win[(freqs >= f2) & (freqs <= f3)] = 1.0

        m = (freqs > f3) & (freqs <= f4)
        if np.any(m):
            t = (freqs[m] - f3) / (f4 - f3 + 1e-12)
            win[m] = 0.5 + 0.5 * np.cos(np.pi * t)

        F *= win[None, :]
        noise = np.fft.irfft(F, n=n1, axis=1).astype(np.float32)

    return x + noise

# --- 绘图函数 (保持不变) ---
def plot_2d_result(image):
    """(原代码) 绘图函数"""
    fig, axes = plt.subplots(1, 1, figsize=(9, 7))
    # 图像现在可以更宽 (n2=512)
    axes.imshow(image.T, cmap='gray', aspect='auto', origin='upper')
    axes.set_title('Seismic Image (Geological Model - No Convolution)')
    axes.set_xlabel('X2')
    axes.set_ylabel('X1 (Depth)')
    plt.tight_layout()
    plt.show()


# Example usage
# --- 批量生成部分（替换原来的 main 函数） ---
if __name__ == "__main__":
    import os

    # ===== 配置 =====
    num_images = 500          # 生成多少个 512x512“大图”
    n1 = 512                  # 深度
    n2 = 512                  # 横向
    dt = 0.004
    wlen = 0.128

    CLEAN_DIR = "dataset2001-30hz/clean"
    NOISY_DIR = "dataset2001-20hz/noisy"
    os.makedirs(CLEAN_DIR, exist_ok=True)
    os.makedirs(NOISY_DIR, exist_ok=True)

    # clean/noisy 子波（零相位）
    w30 = ricker_wavelet(f0=30.0, dt=dt, length=wlen)  # 高频无噪
    w20 = ricker_wavelet(f0=20.0, dt=dt, length=wlen)  # 低频带噪基准

    # 噪声参数（你可按导师口味调）
    snr_db = 8.0
    offset_exp = 1.8
    min_scale = 0.35
    max_scale = 1.00
    bandlimit = True

    idx = 2001  # 文件编号：0001.dat, 0002.dat...

    print(f"Start generating {num_images} models (512x512 clean (30Hz) and 256x256 noisy (20Hz+noise+downsample))...")

    for i in range(num_images):
        seed = 100 + i
        generator = GeologicalSeismicData(seed=seed)

        # 1) 生成 512x512 反射系数模型（无噪）
        model = generator.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0)

        # === clean：30Hz 卷积，无噪 ===
        clean = convolve_along_depth(model, w30)
        clean = clean - np.mean(clean)
        clean = clean / (np.std(clean) + 1e-12)

        # === noisy：20Hz 卷积 + 噪声 ===
        base = convolve_along_depth(model, w20)
        base = base - np.mean(base)
        base = base / (np.std(base) + 1e-12)

        noisy512 = add_offset_noise(
            base,
            rng=np.random.default_rng(seed * 100000 + idx),
            snr_db=snr_db,
            offset_exp=offset_exp,
            min_scale=min_scale,
            max_scale=max_scale,
            bandlimit=bandlimit
        ).astype(np.float32)

        noisy256 = downsample_x2(noisy512)

        # 3) 保存 dat（一一对应）
        fname = f"{idx:04d}.dat"
        clean.astype(np.float32).tofile(
            os.path.join(CLEAN_DIR, fname)
        )

        noisy256.astype(np.float32).tofile(
            os.path.join(NOISY_DIR, fname)
        )

        idx += 1

        if (i + 1) % 10 == 0:
            print(f"[{i+1}/{num_images}] done. total pairs so far: {idx-1}")

    print("All done.")
