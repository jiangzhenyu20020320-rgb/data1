import os
from scipy.signal import hilbert
import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter, map_coordinates, zoom
def ricker_wavelet_with_phase(frequency=25, phase_deg=0, dt=0.004, length=0.256, return_t=True):
    """
    生成带相位(常相位旋转)的 Ricker 子波
    w_phase = cos(phi)*w - sin(phi)*Hilbert(w)
    """
    t = np.arange(-length / 2, length / 2, dt)

    # 1) 零相位 Ricker
    w0 = (1 - 2 * (np.pi ** 2) * (frequency ** 2) * (t ** 2)) * \
         np.exp(-(np.pi ** 2) * (frequency ** 2) * (t ** 2))

    # 2) Hilbert 变换得到 90° 分量
    w_h = np.imag(hilbert(w0))

    # 3) 常相位旋转
    phi = np.deg2rad(phase_deg)
    w_phase = np.cos(phi) * w0 - np.sin(phi) * w_h
    print("dt used:", dt, "nt:", len(t))

    if return_t:
        return t, w_phase
    return w_phase

def add_offset_noise(img, rng, snr_db=15.0,
                     offset_exp=1.8, min_scale=0.4, max_scale=1.0,
                     bandlimit=True, fmin=0.02, fmax=0.25):
    """
    偏移剖面噪声（offset-dependent noise）
    img: (n2, n1)  # 你的图像：X2在第0维，深度在第1维
    snr_db: 控制噪声强弱（典型 8~25dB；越小噪声越强）
    offset_exp/min_scale/max_scale: 控制“远偏移更吵”的程度
    bandlimit: True 时把噪声带限成更像地震噪声的形态
    """
    n2, n1 = img.shape
    x = img.astype(np.float32)

    # 用全图 RMS 定一个总噪声水平（由 snr_db 控制）
    sig_rms = np.sqrt(np.mean(x**2) + 1e-12)
    noise_rms = sig_rms / (10.0 ** (snr_db / 20.0))

    # 以中心道为近偏移，向两侧偏移增大（0~1）
    i2 = np.arange(n2, dtype=np.float32)
    center = (n2 - 1) / 2.0
    off = np.abs(i2 - center) / (center + 1e-12)

    # 每条道噪声标准差权重：近偏移小，远偏移大
    w = min_scale + (max_scale - min_scale) * (off ** offset_exp)

    # 生成噪声并按道加权
    noise = rng.standard_normal((n2, n1)).astype(np.float32)
    noise *= (noise_rms * w)[:, None]

    # 可选：沿深度方向带限（让噪声更像地震噪声，不那么“像素白噪声”）
    if bandlimit:
        F = np.fft.rfft(noise, axis=1)
        freqs = np.fft.rfftfreq(n1, d=1.0)  # 归一化频率 0~0.5
        win = np.zeros_like(freqs, dtype=np.float32)

        tw = 0.02  # 过渡带宽
        f1, f2 = max(fmin - tw, 0.0), fmin
        f3, f4 = fmax, min(fmax + tw, 0.5)

        m = (freqs >= f1) & (freqs < f2)
        if np.any(m):
            t = (freqs[m] - f1) / (f2 - f1 + 1e-12)
            win[m] = 0.5 - 0.5 * np.cos(np.pi * t)
        win[(freqs >= f2) & (freqs <= f3)] = 1.0
        m = (freqs > f3) & (freqs <= f4)
        if np.any(m):
            t = (freqs[m] - f3) / (f4 - f3 + 1e-12)
            win[m] = 0.5 + 0.5 * np.cos(np.pi * t)

        F *= win[None, :]
        noise = np.fft.irfft(F, n=n1, axis=1).astype(np.float32)

    return x + noise





class GeologicalSeismicData:

    def __init__(self, seed=31):
        self.rng = np.random.RandomState(seed)

    def generate_plausible_parameters(self, n1, n2):
        """
        (新) 批量生成符合地质逻辑的参数。

        基本逻辑：
        1. 定义一个主要的盐丘构造。
        2. 定义一个主要的生长断层（可能与盐丘有关，也可能独立）。
        3. 定义一个主要的裂谷大断层（带拖曳效应）。
        4. 定义次要的尖灭和剪切。
        """
        params = {}

        # --- 1. 分层褶皱 ---
        params['folding'] = {
            'boundary_i1': n1 // self.rng.uniform(2.5, 4.5),  # 褶皱边界深度
            'lower_amp': self.rng.uniform(0.02, 0.04),  # 深层褶皱幅度
            'lower_freq_b': self.rng.uniform(4e-5, 6e-5),  # 深层褶皱频率
            'upper_amp': self.rng.uniform(0.005, 0.015),  # 浅层褶皱幅度
            'upper_freq_b': self.rng.uniform(7e-4, 9e-4)  # 浅层褶皱频率
        }

        # --- 2. 地层尖灭 ---
        # (保持在右侧，模拟盆地边缘)
        wedge_width = self.rng.uniform(50, 100)
        params['wedge'] = {
            'i1_start': self.rng.uniform(n1 * 0.7, n1 * 0.8),  # 尖灭深度
            'i1_end': self.rng.uniform(n1 * 0.85, n1 * 0.95),
            'x2_start': n2,  # 从右边缘开始
            'x2_end': n2 - wedge_width,  # 尖灭宽度
            'direction': 'right'
        }

        # --- 3. 盐丘 ---
        params['salt_dome'] = {
            'dome_center_x2': self.rng.uniform(n2 * 0.15, n2 * 0.3),  # 盐丘中心 (在左侧)
            'dome_height': self.rng.uniform(30, 50),
            'dome_width': self.rng.uniform(40, 60),
            'i1_start_lift': self.rng.uniform(40, 60),  # 隆起起始深度
            'i1_end_lift': self.rng.uniform(180, 220)  # 隆起结束深度
        }

        # --- 4. 断层 ---
        fault_start_depth = self.rng.uniform(10, 30)
        fault_end_depth = self.rng.uniform(180, 220)

        # 4a. 断层 1 (普通断层，在模型中间)
        params['fault1'] = {
            'x2_ref': self.rng.uniform(n2 * 0.45, n2 * 0.55),
            'dip_top': self.rng.uniform(-60, -40),
            'dip_bottom': self.rng.uniform(20, 40),
            'throw': self.rng.uniform(10, 20),
            'i1_start': fault_start_depth,
            'i1_end': fault_end_depth,
            'growth_factor': 1.0  # 无生长
        }

        # 4b. 断层 2 (生长断层, 靠近盐丘，模拟盐丘相关的塌陷)
        # 逻辑：位置在盐丘的右侧
        salt_right_edge = params['salt_dome']['dome_center_x2'] + params['salt_dome']['dome_width']
        params['fault2'] = {
            'x2_ref': salt_right_edge + self.rng.uniform(40, 80),
            'dip_top': self.rng.uniform(-60, -40),  # 倾向盐丘
            'dip_bottom': self.rng.uniform(10, 20),
            'throw': self.rng.uniform(10, 15),
            'i1_start': fault_start_depth,
            'i1_end': fault_end_depth,
            'growth_factor': self.rng.uniform(1.15, 1.30)  # 有生长
        }

        # 4c. 断层 3 (大型裂谷断层，带拖曳效应，在模型右侧)
        params['fault3'] = {
            'x2_ref': self.rng.uniform(n2 * 0.8, n2 * 0.9),
            'dip_top': self.rng.uniform(80, 90),  # 陡峭
            'dip_bottom': self.rng.uniform(30, 50),  # 变缓
            'throw': self.rng.uniform(25, 40),
            'i1_start': fault_start_depth,
            'i1_end': n1,  # 延伸到底部
            'growth_factor': 1.0  # 无生长
        }

        # 4d. 断层 3 的拖曳效应
        params['flexure3'] = {
            'flexure_width': self.rng.uniform(30, 50),
            'max_flexure_depth_shift': self.rng.uniform(20, 35)
        }

        # --- 5. 衰减带参数 (所有断层共用) ---
        params['zone'] = {
            'zone_width': self.rng.uniform(6, 10),
            'blur_sigma': self.rng.uniform(0.3, 0.7),
            'attenuation_factor': self.rng.uniform(0.3, 0.6)
        }

        # --- 6. 垂向剪切 ---
        params['shear'] = {
            'scale': self.rng.uniform(0.03, 0.08)
        }

        return params

    def seismic_and_slopes_2d(self, n1=256, n2=512, noise=0, params=None):

        # 1. 创建基础反射系数
        reflectivity = self._make_reflectivity_2d(n1, n2)

        # (修改) 如果没有提供参数，则使用一组固定的默认值（用于调试）
        if params is None:
            # (使用您上一版代码中的硬编码值作为默认值)
            params = self.generate_plausible_parameters(n1, n2)
            # (为了简化，我们直接调用生成器。在实际应用中，这里可以放一组固定的默认值)

        # 应用分层褶皱
        p_fold = params['folding']
        lower_params = {'a1': 0, 'b1': p_fold['lower_amp'], 'a2': 5e-5, 'b2': p_fold['lower_freq_b']}
        upper_params = {'a1': 0, 'b1': p_fold['upper_amp'], 'a2': 8e-4, 'b2': p_fold['upper_freq_b']}

        reflectivity = self._apply_sinusoidal_fold_2d_layered(
            reflectivity, n1, n2,
            boundary_i1=p_fold['boundary_i1'],
            upper_params=upper_params,
            lower_params=lower_params
        )

        # --- 2.5. 模拟地层尖灭 ---
        reflectivity = self._apply_stratigraphic_wedge_2d(
            reflectivity, n1, n2, **params['wedge']
        )

        #  模拟盐丘上拱
        reflectivity = self._apply_salt_dome_2d(
            reflectivity, n1, n2, **params['salt_dome']
        )

        zone_params = params['zone']

        # 4. 应用弯曲的铲状断层

        # --- 断层 1 ---
        fault1_params = params['fault1']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault1_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault1_params, **zone_params)

        # --- 断层 2 (生长断层) ---
        fault2_params = params['fault2']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault2_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault2_params, **zone_params)

        # --- 断层 3 (大断层) ---
        fault3_params = params['fault3']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault3_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault3_params, **zone_params)

        # --- 5.5. 应用断层拖曳 (断层3) ---
        # 组合 fault3 和 flexure3 的参数
        flexure_params = {**fault3_params, **params['flexure3']}
        reflectivity = self._apply_geometric_flexure_2d(
            reflectivity, n1, n2, **flexure_params
        )

        reflectivity = self._apply_vertical_shear_2d(
            reflectivity, n1, n2, **params['shear']
        )

        # 6. 归一化和添加噪声
        image = reflectivity
        image = image / np.std(image)  # 归一化

        if noise > 0:
            noise_array = self.rng.randn(*image.shape)
            noise_array = gaussian_filter(noise_array, sigma=2.0, order=1)
            noise_array = noise_array * noise * np.std(image) / np.std(noise_array)
            image = image + noise_array

        return image

    def _make_reflectivity_2d(self, n1, n2):
        r = 2.0 * self.rng.rand(n1) - 1.0
        r = np.sign(r) * np.abs(r) ** 5
        reflectivity = np.tile(r[:, np.newaxis], (1, n2)).T
        return reflectivity

    def _apply_vertical_shear_2d(self, data, n1, n2, scale=0.05):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([
            i2.astype(float),  # 横向坐标不变
            np.clip(i1 - scale * i2, 0, n1 - 1)  # 深度坐标剪切并裁剪
        ])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_stratigraphic_wedge_2d(self, data, n1, n2, i1_start, i1_end, x2_start, x2_end, direction='left'):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        x2_min = min(x2_start, x2_end)
        x2_max = max(x2_start, x2_end)
        x2_width = x2_max - x2_min
        if x2_width <= 0:
            return data
        x2_active = np.clip(i2, x2_min, x2_max)
        if direction == 'left':
            attenuation_factor = (x2_active - x2_min) / x2_width
        elif direction == 'right':
            attenuation_factor = 1.0 - (x2_active - x2_min) / x2_width
        else:
            return data
        wedge_mask = depth_mask & (i2 >= x2_min) & (i2 < x2_max)
        data[wedge_mask] *= attenuation_factor[wedge_mask]
        return data

    def _apply_sinusoidal_fold_2d_layered(self, data, n1, n2, boundary_i1, upper_params, lower_params):
        i1_range, i2_range = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        shift = np.zeros_like(i1_range, dtype=float)
        mask_upper = (i1_range < boundary_i1)
        up = upper_params
        shift[mask_upper] = (up['a1'] + up['b1'] * i1_range[mask_upper]) * \
                            np.sin((up['a2'] + up['b2'] * i2_range[mask_upper]) * i2_range[mask_upper])
        mask_lower = (i1_range >= boundary_i1)
        low = lower_params
        shift[mask_lower] = (low['a1'] + low['b1'] * i1_range[mask_lower]) * \
                            np.sin((low['a2'] + low['b2'] * i2_range[mask_lower]) * i2_range[mask_lower])
        x1_new = i1_range - shift
        coords = np.zeros((2, n2, n1))
        coords[0, :, :] = i2_range
        coords[1, :, :] = np.clip(x1_new, 0, n1 - 1)
        return map_coordinates(data, coords.reshape(2, n2, n1), order=3, mode='nearest')

    def _apply_salt_dome_2d(self, data, n1, n2, dome_center_x2, dome_height, dome_width, i1_start_lift=0,
                            i1_end_lift=None):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        if i1_end_lift is None:
            i1_end_lift = n1
        n1_effective = i1_end_lift - i1_start_lift
        if n1_effective <= 0:
            return data
        i1_offset = np.maximum(0, i1 - i1_start_lift)
        i1_norm_raw = i1_offset / n1_effective
        i1_norm_clamped = np.clip(i1_norm_raw, 0, 1)
        uplift_scale = 4 * i1_norm_clamped * (1 - i1_norm_clamped)
        shift = dome_height * np.exp(-((i2 - dome_center_x2) ** 2) / (2 * dome_width ** 2)) * uplift_scale
        src_i1 = np.clip(i1 + shift, 0, n1 - 1)
        src_i2 = i2.astype(float)
        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_curved_normal_fault_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, throw, i1_start, i1_end,
                                      growth_factor=1.0):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([i2.astype(float), i1.astype(float)])
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        if dip_top > 0:
            downthrown_mask = (i2 > fault_x2_trace[np.newaxis, :])
        else:
            downthrown_mask = (i2 < fault_x2_trace[np.newaxis, :])
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        fault_mask = downthrown_mask & depth_mask
        i1_offset_from_start = coords[1][fault_mask] - i1_start
        growth_displacement = i1_offset_from_start * (growth_factor - 1.0)
        total_displacement = throw + growth_displacement
        src_i1 = coords[1][fault_mask] - total_displacement
        coords[1][fault_mask] = np.clip(src_i1, 0, n1 - 1)
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_fault_zone_attenuation_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom,
                                         zone_width, blur_sigma, attenuation_factor, i1_start, i1_end, **kwargs):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        fault_x2_trace_grid = fault_x2_trace[np.newaxis, :]
        dist_to_fault = np.abs(i2 - fault_x2_trace_grid)
        zone_mask_proximity = (dist_to_fault <= zone_width / 2.0)
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        zone_mask = zone_mask_proximity & depth_mask
        if np.any(zone_mask):
            blurred_data = gaussian_filter(data, sigma=blur_sigma)
            data[zone_mask] = blurred_data[zone_mask]
            data[zone_mask] *= attenuation_factor
        return data

    def _apply_geometric_flexure_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, i1_start, i1_end,
                                    flexure_width, max_flexure_depth_shift, **kwargs):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        if dip_top > 0:
            is_downthrown = (i2 > fault_x2_trace[np.newaxis, :])
            dist_to_fault = i2 - fault_x2_trace[np.newaxis, :]
            shift_direction = -1
        else:
            is_downthrown = (i2 < fault_x2_trace[np.newaxis, :])
            dist_to_fault = fault_x2_trace[np.newaxis, :] - i2
            shift_direction = -1
        dist_clamped = np.clip(dist_to_fault, 0, flexure_width)
        horizontal_weight = (flexure_width - dist_clamped) / flexure_width
        i1_norm = np.clip((i1 - i1_start) / (i1_end - i1_start + 1e-6), 0, 1)
        depth_weight = i1_norm
        flexure_shift = (
                max_flexure_depth_shift * horizontal_weight * depth_weight * shift_direction
        )
        flexure_mask = is_downthrown & (dist_to_fault > 0) & (dist_to_fault < flexure_width) & (i1 >= i1_start) & (
                i1 < i1_end)
        src_i1 = i1.astype(float)
        src_i2 = i2.astype(float)
        src_i1[flexure_mask] = np.clip(src_i1[flexure_mask] + flexure_shift[flexure_mask], 0, n1 - 1)
        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')


    def convolve_with_wavelet(self, image, wavelet):
        """
        对每条道进行 1D 卷积（沿 X1，即 axis=1）
        image: shape (n2, n1)
        wavelet: 1D Ricker wavelet
        """
        n2, n1 = image.shape
        output = np.zeros_like(image)

        # 对每一条道进行卷积
        for i2 in range(n2):
            output[i2, :] = np.convolve(image[i2, :], wavelet, mode='same')

        return output


# --- 绘图函数 (修改：接受标题) ---
def plot_2d_result(image, title='Seismic Image (Geological Model - No Convolution)'):
    """(修改) 绘图函数，接受自定义标题"""
    fig, axes = plt.subplots(1, 1, figsize=(12, 7))
    axes.imshow(image.T, cmap='gray', aspect='auto', origin='upper')
    axes.set_title(title)
    axes.set_xlabel('X2')
    axes.set_ylabel('X1 (Depth)')
    plt.tight_layout()
    plt.show()

def plot_wavelets_by_phase(frequency, phases_deg, dt=0.004, length=0.256, title=None):
    fig, ax = plt.subplots(1, 1, figsize=(10, 4))
    for ph in phases_deg:
        t, w = ricker_wavelet_with_phase(frequency=frequency, phase_deg=ph, dt=dt, length=length, return_t=True)
        ax.plot(t, w, label=f"{ph}°")
    ax.axhline(0, linewidth=1)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Amplitude")
    ax.set_title(title or f"Ricker wavelets with phase rotation (f0={frequency} Hz)")
    ax.legend(ncol=4, fontsize=9)
    plt.tight_layout()
    plt.show()

def downsample_x2(img):
    # (512,512) -> (256,256)
    return zoom(img, zoom=(0.5, 0.5), order=1).astype(np.float32)  # order=1 双线性


# =====================================================================
# LQ Gaussian and offset-profile noise SVG generation pipeline
# =====================================================================
import argparse
from pathlib import Path


def ricker_wavelet_zero_phase(frequency=30.0, dt=0.004, length=0.256):
    """Zero-phase Ricker wavelet without console printing."""
    t = np.arange(-length / 2.0, length / 2.0 + dt, dt, dtype=np.float32)
    a = (np.pi * float(frequency) * t) ** 2
    w = (1.0 - 2.0 * a) * np.exp(-a)
    w = w / (np.max(np.abs(w)) + 1.0e-12)
    return w.astype(np.float32)


def normalize_zero_mean_unit_std(x):
    """Zero-mean, unit-standard-deviation normalization."""
    x = x.astype(np.float32)
    return ((x - np.mean(x)) / (np.std(x) + 1.0e-12)).astype(np.float32)


def add_gaussian_white_noise(section, rng, snr_db=15.0):
    """
    Add spatially uniform Gaussian white noise.

    section: (n2, n1), where n2 is the lateral axis and n1 is time/depth.
    snr_db: larger value means weaker noise.
    """
    x = section.astype(np.float32)
    sig_rms = np.sqrt(np.mean(x ** 2) + 1.0e-12)
    noise_rms = sig_rms / (10.0 ** (float(snr_db) / 20.0))
    noise = rng.standard_normal(x.shape).astype(np.float32) * noise_rms
    return (x + noise).astype(np.float32), noise.astype(np.float32)


def _bandlimit_noise_along_depth(noise, fmin=0.02, fmax=0.25, transition=0.02):
    """
    Optional band-limiting along the vertical axis using normalized frequency.
    This is useful when the offset-profile noise should look more seismic-like.
    """
    noise = noise.astype(np.float32)
    n2, n1 = noise.shape
    F = np.fft.rfft(noise, axis=1)
    freqs = np.fft.rfftfreq(n1, d=1.0).astype(np.float32)
    win = np.zeros_like(freqs, dtype=np.float32)

    tw = float(transition)
    f1, f2 = max(float(fmin) - tw, 0.0), float(fmin)
    f3, f4 = float(fmax), min(float(fmax) + tw, 0.5)

    m = (freqs >= f1) & (freqs < f2)
    if np.any(m):
        u = (freqs[m] - f1) / (f2 - f1 + 1.0e-12)
        win[m] = 0.5 - 0.5 * np.cos(np.pi * u)
    win[(freqs >= f2) & (freqs <= f3)] = 1.0
    m = (freqs > f3) & (freqs <= f4)
    if np.any(m):
        u = (freqs[m] - f3) / (f4 - f3 + 1.0e-12)
        win[m] = 0.5 + 0.5 * np.cos(np.pi * u)

    F *= win[None, :]
    return np.fft.irfft(F, n=n1, axis=1).astype(np.float32)


def add_offset_profile_noise(
    section,
    rng,
    snr_db=12.0,
    offset_exp=1.8,
    min_scale=0.25,
    max_scale=1.35,
    lateral_smooth_sigma=0.0,
    bandlimit=False,
    fmin=0.02,
    fmax=0.25,
):
    """
    Add offset-profile noise: weak near the section center and strong at both sides.

    The lateral weight is
        w(x) = min_scale + (max_scale - min_scale) * |x - x_c|^offset_exp,
    where the normalized offset |x - x_c| ranges from 0 at the center to 1 at both sides.
    """
    x = section.astype(np.float32)
    n2, n1 = x.shape

    sig_rms = np.sqrt(np.mean(x ** 2) + 1.0e-12)
    base_noise_rms = sig_rms / (10.0 ** (float(snr_db) / 20.0))

    i2 = np.arange(n2, dtype=np.float32)
    center = (n2 - 1.0) / 2.0
    offset = np.abs(i2 - center) / (center + 1.0e-12)
    weight = float(min_scale) + (float(max_scale) - float(min_scale)) * (offset ** float(offset_exp))

    noise = rng.standard_normal((n2, n1)).astype(np.float32)
    if lateral_smooth_sigma and lateral_smooth_sigma > 0:
        noise = gaussian_filter(noise, sigma=(float(lateral_smooth_sigma), 0.0)).astype(np.float32)
        noise = noise / (np.std(noise) + 1.0e-12)

    if bandlimit:
        noise = _bandlimit_noise_along_depth(noise, fmin=fmin, fmax=fmax)
        noise = noise / (np.std(noise) + 1.0e-12)

    noise = noise * (base_noise_rms * weight)[:, None]
    return (x + noise).astype(np.float32), noise.astype(np.float32), weight.astype(np.float32)


def save_gray_svg(section, out_path, clip_value=None, clip_percentile=98.0, gain=1.8, figsize=(2.56, 2.56), dpi=100):
    """
    Save a seismic section as grayscale SVG.

    The seismic section itself is raster data embedded in an SVG container; this
    is the normal behavior for imshow-based seismic panels. Percentile clipping
    and tanh contrast enhancement are used only for display.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    x = section.astype(np.float32)
    if clip_value is None:
        clip_value = float(np.percentile(np.abs(x), clip_percentile))
    clip_value = max(float(clip_value), 1.0e-8)

    disp = np.clip(x, -clip_value, clip_value) / clip_value
    disp = np.tanh(float(gain) * disp) / np.tanh(float(gain))

    fig, ax = plt.subplots(figsize=figsize)
    ax.imshow(disp.T, cmap="gray", vmin=-1.0, vmax=1.0, aspect="auto", origin="upper")
    ax.set_axis_off()
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    fig.savefig(out_path, format="svg", dpi=dpi, bbox_inches="tight", pad_inches=0)
    plt.close(fig)


def save_noise_weight_svg(weight, out_path, figsize=(2.56, 0.55), dpi=100):
    """Save the lateral offset-noise weight curve as an SVG."""
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(np.arange(len(weight)), weight, linewidth=1.6)
    ax.set_xlim(0, len(weight) - 1)
    ax.set_xlabel("Trace")
    ax.set_ylabel("Noise weight")
    ax.grid(False)
    fig.tight_layout(pad=0.2)
    fig.savefig(out_path, format="svg", dpi=dpi, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate 30-Hz LQ synthetic seismic SVGs with Gaussian white noise and offset-profile noise."
    )
    parser.add_argument("--num_images", type=int, default=5, help="Small-batch sample count.")
    parser.add_argument("--out_dir", type=str, default="lq_noise_svg_outputs", help="Output root directory.")
    parser.add_argument("--n1", type=int, default=256, help="Depth/time samples.")
    parser.add_argument("--n2", type=int, default=256, help="Lateral samples.")
    parser.add_argument("--start_seed", type=int, default=0, help="First random seed.")
    parser.add_argument("--dt", type=float, default=0.004, help="Sampling interval in seconds.")
    parser.add_argument("--lq_freq", type=float, default=30.0, help="LQ Ricker dominant frequency in Hz.")
    parser.add_argument("--wavelet_length", type=float, default=0.256, help="Ricker wavelet length in seconds.")

    parser.add_argument("--gaussian_snr_db", type=float, default=6.0, help="SNR for Gaussian white noise.")
    parser.add_argument("--offset_snr_db", type=float, default=6.0, help="Base SNR for offset-profile noise.")
    parser.add_argument("--offset_exp", type=float, default=1.8, help="Controls how quickly noise grows from center to sides.")
    parser.add_argument("--offset_min_scale", type=float, default=0.1, help="Noise scale at section center.")
    parser.add_argument("--offset_max_scale", type=float, default=1.35, help="Noise scale at both sides.")
    parser.add_argument("--offset_lateral_smooth_sigma", type=float, default=0.0, help="Optional lateral smoothing of offset noise.")
    parser.add_argument("--offset_bandlimit", action="store_true", help="Band-limit offset-profile noise along depth for a more seismic-like appearance.")
    parser.add_argument("--noise_fmin", type=float, default=0.02, help="Normalized lower cutoff for optional offset-noise bandlimit.")
    parser.add_argument("--noise_fmax", type=float, default=0.25, help="Normalized upper cutoff for optional offset-noise bandlimit.")

    parser.add_argument("--clip_percentile", type=float, default=98.0, help="Display clipping percentile.")
    parser.add_argument("--display_gain", type=float, default=1.8, help="Tanh display gain.")
    parser.add_argument("--save_base", action="store_true", help="Also save the clean 30-Hz LQ section before adding noise.")
    parser.add_argument("--save_noise", action="store_true", help="Also save the generated noise fields as SVGs.")
    parser.add_argument("--save_offset_weight", action="store_true", help="Also save the lateral offset-noise weight curve.")
    parser.add_argument("--save_mixed", action="store_true", help="Also save LQ with Gaussian + offset-profile noise combined.")
    return parser.parse_args()


def main():
    args = parse_args()
    out_root = Path(args.out_dir)
    gaussian_dir = out_root / "lq_gaussian_noise_svg"
    offset_dir = out_root / "lq_offset_profile_noise_svg"
    mixed_dir = out_root / "lq_mixed_noise_svg"
    base_dir = out_root / "lq_base_svg"
    noise_dir = out_root / "noise_fields_svg"
    weight_dir = out_root / "offset_weight_svg"

    dirs = [gaussian_dir, offset_dir]
    if args.save_mixed:
        dirs.append(mixed_dir)
    if args.save_base:
        dirs.append(base_dir)
    if args.save_noise:
        dirs.append(noise_dir)
    if args.save_offset_weight:
        dirs.append(weight_dir)
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)

    lq_wavelet = ricker_wavelet_zero_phase(
        frequency=args.lq_freq, dt=args.dt, length=args.wavelet_length
    )

    for i in range(args.num_images):
        seed = args.start_seed + i
        generator = GeologicalSeismicData(seed=seed)
        params = generator.generate_plausible_parameters(n1=args.n1, n2=args.n2)

        # Reflectivity model: no noise, no Q attenuation, no A(t,x) amplitude scaling.
        reflectivity = generator.seismic_and_slopes_2d(
            n1=args.n1, n2=args.n2, noise=0, params=params
        )

        # Base LQ: 30-Hz Ricker convolution only.
        lq_base = generator.convolve_with_wavelet(reflectivity, lq_wavelet).astype(np.float32)
        lq_base = normalize_zero_mean_unit_std(lq_base)

        rng_gauss = np.random.default_rng(seed + 1001)
        lq_gaussian, gaussian_noise = add_gaussian_white_noise(
            lq_base, rng=rng_gauss, snr_db=args.gaussian_snr_db
        )

        rng_offset = np.random.default_rng(seed + 2002)
        lq_offset, offset_noise, offset_weight = add_offset_profile_noise(
            lq_base,
            rng=rng_offset,
            snr_db=args.offset_snr_db,
            offset_exp=args.offset_exp,
            min_scale=args.offset_min_scale,
            max_scale=args.offset_max_scale,
            lateral_smooth_sigma=args.offset_lateral_smooth_sigma,
            bandlimit=args.offset_bandlimit,
            fmin=args.noise_fmin,
            fmax=args.noise_fmax,
        )

        # Use the same display clip for all seismic outputs so noise differences remain visible.
        clip_value = float(np.percentile(np.abs(lq_base), args.clip_percentile))
        fname = f"{i + 1:04d}"

        if args.save_base:
            save_gray_svg(
                lq_base,
                base_dir / f"{fname}_LQ_base_{args.lq_freq:g}Hz.svg",
                clip_value=clip_value,
                clip_percentile=args.clip_percentile,
                gain=args.display_gain,
            )

        save_gray_svg(
            lq_gaussian,
            gaussian_dir / f"{fname}_LQ_gaussian_white_noise.svg",
            clip_value=clip_value,
            clip_percentile=args.clip_percentile,
            gain=args.display_gain,
        )
        save_gray_svg(
            lq_offset,
            offset_dir / f"{fname}_LQ_offset_profile_noise.svg",
            clip_value=clip_value,
            clip_percentile=args.clip_percentile,
            gain=args.display_gain,
        )

        if args.save_mixed:
            lq_mixed = (lq_base + gaussian_noise + offset_noise).astype(np.float32)
            save_gray_svg(
                lq_mixed,
                mixed_dir / f"{fname}_LQ_gaussian_plus_offset_noise.svg",
                clip_value=clip_value,
                clip_percentile=args.clip_percentile,
                gain=args.display_gain,
            )

        if args.save_noise:
            # Noise fields use their own clipping to show the noise pattern clearly.
            save_gray_svg(
                gaussian_noise,
                noise_dir / f"{fname}_gaussian_white_noise_field.svg",
                clip_value=None,
                clip_percentile=args.clip_percentile,
                gain=args.display_gain,
            )
            save_gray_svg(
                offset_noise,
                noise_dir / f"{fname}_offset_profile_noise_field.svg",
                clip_value=None,
                clip_percentile=args.clip_percentile,
                gain=args.display_gain,
            )

        if args.save_offset_weight:
            save_noise_weight_svg(offset_weight, weight_dir / f"{fname}_offset_noise_weight.svg")

        print(
            f"[{i + 1}/{args.num_images}] saved Gaussian-noise and offset-profile-noise LQ SVGs "
            f"(seed={seed}, LQ={args.lq_freq:g} Hz)."
        )

    print(f"Done. Output root: {out_root.resolve()}")


if __name__ == "__main__":
    main()
