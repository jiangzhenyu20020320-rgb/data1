# -*- coding: utf-8 -*-
"""
Split the flat stationary x2 dataset into train/val folders for DeltaDiff.

Input layout:
  dataset_waveform_bwe_multistruct_stationary_x2_lq256_gt512_checked/
    lq/*.dat
    gt/*.dat
    meta/*.json
    wavelets/*
    qc/*
    sample_index.csv

Output layout:
  dataset_waveform_bwe_multistruct_stationary_x2_lq256_gt512_checked_split/
    train/lq, train/gt, train/meta, train/wavelets, train/qc
    val/lq,   val/gt,   val/meta,   val/wavelets,   val/qc
    train_index.csv, val_index.csv, sample_count.json
"""

import argparse
import csv
import json
import os
import random
import shutil
from collections import Counter, defaultdict
from pathlib import Path

DEFAULT_SRC_ROOT = Path(r"D:\dateset0309\dataset_waveform_bwe_multistruct_stationary_x2_lq256_gt512_checked")
DEFAULT_OUT_ROOT = Path(r"D:\dateset0309\dataset_waveform_bwe_multistruct_stationary_x2_lq256_gt512_checked_split")


def link_or_copy(src: Path, dst: Path, use_hardlink: bool = False):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not src.exists():
        return False
    if dst.exists():
        dst.unlink()
    if use_hardlink:
        try:
            os.link(src, dst)
            return True
        except OSError:
            pass
    shutil.copy2(src, dst)
    return True


def read_index(src_root: Path):
    index_path = src_root / "sample_index.csv"
    if index_path.exists():
        with open(index_path, "r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
        return rows

    # Fallback: create minimal rows from lq/gt names.
    lq_files = sorted((src_root / "lq").glob("*.dat"))
    gt_map = {p.stem: p for p in (src_root / "gt").glob("*.dat")}
    rows = []
    for p in lq_files:
        if p.stem not in gt_map:
            continue
        rows.append({
            "id": p.stem,
            "structure": "unknown",
            "family": "unknown",
            "phase_group": "unknown",
        })
    return rows


def group_key(row):
    return (
        row.get("structure", "unknown"),
        row.get("family", "unknown"),
        row.get("phase_group", "unknown"),
    )


def stratified_split(rows, val_ratio=0.10, seed=2026):
    rng = random.Random(seed)
    groups = defaultdict(list)
    for r in rows:
        groups[group_key(r)].append(r)

    train_rows, val_rows = [], []
    for _, rs in sorted(groups.items(), key=lambda kv: str(kv[0])):
        rs = list(rs)
        rng.shuffle(rs)
        n = len(rs)
        n_val = max(1, int(round(n * val_ratio))) if n >= 10 else max(1, n // 10)
        n_val = min(n_val, n - 1) if n > 1 else n
        val_rows.extend(rs[:n_val])
        train_rows.extend(rs[n_val:])

    rng.shuffle(train_rows)
    rng.shuffle(val_rows)
    return train_rows, val_rows


def copy_split(rows, split, src_root: Path, out_root: Path, use_hardlink=False):
    copied = []
    for r in rows:
        stem = str(r.get("id", "")).strip()
        if not stem:
            # Try deriving from path if present.
            p = r.get("lq_path", "")
            stem = Path(p).stem if p else ""
        if not stem:
            continue

        lq_src = src_root / "lq" / f"{stem}.dat"
        gt_src = src_root / "gt" / f"{stem}.dat"
        if not lq_src.exists() or not gt_src.exists():
            print(f"[WARN] skip missing pair: {stem}")
            continue

        link_or_copy(lq_src, out_root / split / "lq" / f"{stem}.dat", use_hardlink)
        link_or_copy(gt_src, out_root / split / "gt" / f"{stem}.dat", use_hardlink)

        # Optional side files.
        link_or_copy(src_root / "meta" / f"{stem}.json", out_root / split / "meta" / f"{stem}.json", use_hardlink)
        for w in (src_root / "wavelets").glob(f"{stem}_*"):
            link_or_copy(w, out_root / split / "wavelets" / w.name, use_hardlink)
        for q in (src_root / "qc").glob(f"{stem}*"):
            link_or_copy(q, out_root / split / "qc" / q.name, use_hardlink)

        rr = dict(r)
        rr["split"] = split
        rr["lq_path"] = str(out_root / split / "lq" / f"{stem}.dat")
        rr["gt_path"] = str(out_root / split / "gt" / f"{stem}.dat")
        rr["meta_path"] = str(out_root / split / "meta" / f"{stem}.json")
        copied.append(rr)
    return copied


def write_csv(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    fields = list(dict.fromkeys(k for r in rows for k in r.keys()))
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--src_root", type=Path, default=DEFAULT_SRC_ROOT)
    parser.add_argument("--out_root", type=Path, default=DEFAULT_OUT_ROOT)
    parser.add_argument("--val_ratio", type=float, default=0.10)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--overwrite", action="store_true", default=True)
    parser.add_argument("--use_hardlink", action="store_true", help="Use hard links when possible to save disk space.")
    args = parser.parse_args()

    src_root = args.src_root
    out_root = args.out_root
    if not (src_root / "lq").exists() or not (src_root / "gt").exists():
        raise FileNotFoundError(f"Expected lq/gt folders under {src_root}")

    if args.overwrite and out_root.exists():
        print(f"[RESET] remove old split directory: {out_root}")
        shutil.rmtree(out_root)

    rows = read_index(src_root)
    print(f"[LOAD] total indexed rows: {len(rows)}")
    train_rows, val_rows = stratified_split(rows, val_ratio=args.val_ratio, seed=args.seed)
    print(f"[SPLIT] train={len(train_rows)}, val={len(val_rows)}, val_ratio={args.val_ratio}")

    train_copied = copy_split(train_rows, "train", src_root, out_root, args.use_hardlink)
    val_copied = copy_split(val_rows, "val", src_root, out_root, args.use_hardlink)

    all_rows = train_copied + val_copied
    write_csv(out_root / "train_index.csv", train_copied)
    write_csv(out_root / "val_index.csv", val_copied)
    write_csv(out_root / "sample_index.csv", all_rows)

    counts = {
        "total": len(all_rows),
        "train": len(train_copied),
        "val": len(val_copied),
        "by_split_family": dict(Counter(f"{r.get('split')}_{r.get('family','unknown')}" for r in all_rows)),
        "by_split_structure": dict(Counter(f"{r.get('split')}_{r.get('structure','unknown')}" for r in all_rows)),
    }
    with open(out_root / "sample_count.json", "w", encoding="utf-8") as f:
        json.dump(counts, f, ensure_ascii=False, indent=2)
    print(json.dumps(counts, ensure_ascii=False, indent=2))
    print(f"[DONE] split dataset saved to: {out_root}")


if __name__ == "__main__":
    main()
