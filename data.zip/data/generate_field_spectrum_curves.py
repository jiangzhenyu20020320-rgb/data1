import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path


def smooth_gaussian(y: np.ndarray, sigma_samples: float = 6.0) -> np.ndarray:
    """Simple Gaussian smoothing without SciPy."""
    radius = int(max(3, round(4 * sigma_samples)))
    x = np.arange(-radius, radius + 1, dtype=np.float64)
    kernel = np.exp(-0.5 * (x / sigma_samples) ** 2)
    kernel /= kernel.sum()
    y_pad = np.pad(y, (radius, radius), mode="reflect")
    return np.convolve(y_pad, kernel, mode="valid")


def logistic(x: np.ndarray, center: float, width: float) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-(x - center) / width))


def build_original_spectrum(f: np.ndarray) -> np.ndarray:
    """
    Construct a realistic-looking field-style seismic amplitude spectrum.

    Design targets:
    - dominant frequency around 35 Hz;
    - effective low end roughly above ~12 Hz;
    - effective high end decays strongly after ~55 Hz.
    """
    # Broad envelope with a main peak around 35 Hz and gentle side shoulders.
    peak_main = np.exp(-0.5 * ((f - 35.0) / 9.5) ** 2)
    shoulder_low = 0.42 * np.exp(-0.5 * ((f - 21.0) / 7.5) ** 2)
    shoulder_high = 0.28 * np.exp(-0.5 * ((f - 48.0) / 8.5) ** 2)

    # Low-frequency ramp and high-frequency roll-off.
    low_gate = logistic(f, center=12.0, width=2.0)
    high_gate = 1.0 / (1.0 + np.exp((f - 56.0) / 3.2))

    # Mild field-style undulation.
    ripple = 1.0 + 0.03 * np.sin(0.23 * f + 0.6) + 0.015 * np.cos(0.47 * f)

    y = (peak_main + shoulder_low + shoulder_high) * low_gate * high_gate * ripple
    y = smooth_gaussian(y, sigma_samples=4.0)
    y = np.clip(y, 0.0, None)
    y /= y.max()
    y *= 0.77
    return y


def build_bwe_spectrum(f: np.ndarray, original: np.ndarray) -> np.ndarray:
    """
    Build a bandwidth-extended curve from the original spectrum.

    Extension assumptions:
    - low-frequency end extends by about 6 Hz (from ~12 Hz to ~6 Hz);
    - high-frequency end extends by about 20 Hz (from ~56 Hz to ~76 Hz);
    - the overall shape stays physically plausible and smoothly decays.
    """
    # Low-frequency enhancement: lift energy mainly in 6-18 Hz.
    low_boost = 0.23 * np.exp(-0.5 * ((f - 10.0) / 5.5) ** 2)
    low_gate_new = logistic(f, center=6.0, width=2.0)

    # High-frequency extension: broaden the upper tail and add a smooth shoulder.
    high_shoulder = 0.22 * np.exp(-0.5 * ((f - 60.0) / 10.5) ** 2)
    high_tail = 0.10 * np.exp(-0.5 * ((f - 72.0) / 7.0) ** 2)
    high_gate_new = 1.0 / (1.0 + np.exp((f - 76.0) / 4.5))

    # Slight strengthening around the main band while keeping similar peak location.
    mid_adjust = 0.04 * np.exp(-0.5 * ((f - 35.0) / 10.0) ** 2)

    y = (0.94 * original + low_boost + high_shoulder + high_tail + mid_adjust)
    y = y * low_gate_new
    y = y * high_gate_new
    y = smooth_gaussian(y, sigma_samples=4.5)
    y = np.clip(y, 0.0, None)
    y /= y.max()
    y *= 0.8
    return y


def plot_and_save(output_dir: str = ".") -> None:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Frequency axis.
    f = np.linspace(0.0, 100.0, 2001)

    # Curves.
    y_orig = build_original_spectrum(f)
    y_bwe = build_bwe_spectrum(f, y_orig)

    # Global figure style.
    plt.rcParams.update({
        "font.family": "Times New Roman",
        "font.size": 12,
        "axes.linewidth": 1.8,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })

    # Figure size suitable for a single-column journal figure.
    fig, ax = plt.subplots(figsize=(4.2, 2.7))

    ax.plot(f, y_orig, color="#3A8B3A", linewidth=1.8, label="LQ")
    ax.plot(f, y_bwe, color="#3B6BB5", linewidth=1.8, label="HQ")

    # Axes configuration.
    ax.set_xlim(0.0, 100.0)
    ax.set_ylim(0.0, 1.0)
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Normalized amplitude")

    ax.set_xticks(np.arange(0, 101, 20))
    ax.set_yticks(np.arange(0.0, 1.01, 0.2))

    # Full rectangular frame with uniform styling.
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(1.8)
        spine.set_color("black")

    ax.tick_params(axis="both", which="major", width=1.8, length=4.5, colors="black", direction="out")

    # Optional legend, clean and paper-friendly.
    leg = ax.legend(
        loc="upper right",
        bbox_to_anchor=(0.98, 0.98),
        frameon=False,
        fontsize=10,
        handlelength=2.4
    )
    for line in leg.get_lines():
        line.set_linewidth(1.8)

    fig.tight_layout(pad=0.5)

    # Save vector outputs for journal use.
    pdf_path = out_dir / "field_spectrum_bwe_curves.pdf"
    svg_path = out_dir / "field_spectrum_bwe_curves.svg"
    eps_path = out_dir / "field_spectrum_bwe_curves.eps"

    fig.savefig(pdf_path, bbox_inches="tight")
    fig.savefig(svg_path, bbox_inches="tight")
    fig.savefig(eps_path, bbox_inches="tight")

    plt.close(fig)
    print(f"Saved: {pdf_path}")
    print(f"Saved: {svg_path}")
    print(f"Saved: {eps_path}")


if __name__ == "__main__":
    # Change this path if you want the outputs elsewhere.
    plot_and_save(output_dir=".")
