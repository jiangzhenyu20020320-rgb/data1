# -*- coding: utf-8 -*-
"""
Merge several generated waveform-preserving BWE datasets into one OS-DeltaDiff-ready dataset.

Expected output layout:
  OUT_ROOT/
    train/lq/*.dat
    train/gt/*.dat
    train/meta/*.json
    train/wavelets/*
    val/lq/*.dat
    val/gt/*.dat
    val/meta/*.json
    val/wavelets/*
    sample_index.csv
    sample_count.json

How to use:
  1) First run each generator script and make sure its dataset root exists.
  2) Edit BASE_DIR and DATASETS below if your paths are different.
  3) Run: python merge_bwe_clean_datasets.py

Notes:
  - Files are renamed to unique global IDs, so 0001.dat from different source datasets will not collide.
  - Train/val split is stratified by source dataset + variation + family + structure + phase_group.
  - By default, this script uses hard links when possible to avoid unnecessary copying, then falls back to copy.
"""

from __future__ import annotations

import csv
import json
import os
import random
import shutil
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

# =========================================================
# 0. User configuration
# =========================================================
BASE_DIR = Path(r"D:\dateset0309")

DATASETS = [
    {
        "name": "stationary",
        "variation": "stationary",
        "root": BASE_DIR / "dataset_waveform_bwe_multistruct_stationary_v2_stronger_ok",
    },
    {
        "name": "timevarying",
        "variation": "time",
        "root": BASE_DIR / "dataset_waveform_bwe_multistruct_timevarying_v2_bottom_lower",
    },
    {
        "name": "spacevarying",
        "variation": "space",
        "root": BASE_DIR / "dataset_waveform_bwe_multistruct_spacevarying_v2_stronger",
    },
    {
        "name": "timespace_ormsby",
        "variation": "time_space",
        "root": BASE_DIR / "dataset_waveform_bwe_multistruct_timespace_ormsby_v5_f3_lq15_40_gt50_70",
    },
]

OUT_ROOT = BASE_DIR / "dataset_waveform_bwe_osdeltadiff_clean_v1"
VAL_RATIO = 0.10
RANDOM_SEED = 2026

# Use hard links if source and destination are on the same disk. This saves space.
# If hard link fails, the script automatically copies the file.
USE_HARDLINK_WHEN_POSSIBLE = True
OVERWRITE_OUT_ROOT = False

# Expected .dat shape info saved to summary only. Your training YAML still controls actual reading shape.
N1 = 512
N2 = 512

# =========================================================
# 1. Helpers
# =========================================================
def mkdirs() -> None:
    if OUT_ROOT.exists() and OVERWRITE_OUT_ROOT:
        shutil.rmtree(OUT_ROOT)
    for split in ["train", "val"]:
        for sub in ["lq", "gt", "meta", "wavelets"]:
            (OUT_ROOT / split / sub).mkdir(parents=True, exist_ok=True)


def phase_group(phase_deg, eps: float = 1e-6) -> str:
    try:
        v = float(phase_deg)
    except Exception:
        v = 0.0
    return "zero_phase" if abs(v) <= eps else "with_phase"


def safe_link_or_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()
    if USE_HARDLINK_WHEN_POSSIBLE:
        try:
            os.link(src, dst)
            return
        except Exception:
            pass
    shutil.copy2(src, dst)


def read_meta(meta_path: Path) -> Dict:
    if meta_path.exists():
        with open(meta_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def load_source_rows(ds: Dict) -> List[Dict]:
    root = Path(ds["root"])
    lq_dir = root / "lq"
    gt_dir = root / "gt"
    meta_dir = root / "meta"
    wavelet_dir = root / "wavelets"

    if not lq_dir.exists() or not gt_dir.exists():
        raise FileNotFoundError(f"Missing lq/gt folder under: {root}")

    rows = []
    lq_files = sorted(lq_dir.glob("*.dat"))
    gt_map = {p.stem: p for p in gt_dir.glob("*.dat")}

    for lq_path in lq_files:
        stem = lq_path.stem
        gt_path = gt_map.get(stem)
        if gt_path is None:
            print(f"[WARN] missing GT for {lq_path}; skipped")
            continue

        meta_path = meta_dir / f"{stem}.json"
        meta = read_meta(meta_path)

        family = meta.get("family", "unknown")
        variation = meta.get("variation", ds.get("variation", "unknown"))
        structure = meta.get("structure", "unknown")
        phase_deg = meta.get("phase_deg", 0.0)
        ph_group = meta.get("phase_group", phase_group(phase_deg))

        rows.append({
            "source_dataset": ds["name"],
            "source_root": str(root),
            "source_id": stem,
            "source_lq_path": lq_path,
            "source_gt_path": gt_path,
            "source_meta_path": meta_path if meta_path.exists() else None,
            "source_wavelet_dir": wavelet_dir if wavelet_dir.exists() else None,
            "variation": variation,
            "family": family,
            "structure": structure,
            "phase_deg": phase_deg,
            "phase_group": ph_group,
            "meta": meta,
        })

    return rows


def stratified_split(rows: List[Dict], val_ratio: float, seed: int) -> Tuple[List[Dict], List[Dict]]:
    rng = random.Random(seed)
    groups = defaultdict(list)
    for r in rows:
        key = (
            r.get("source_dataset", ""),
            r.get("variation", ""),
            r.get("family", ""),
            r.get("structure", ""),
            r.get("phase_group", ""),
        )
        groups[key].append(r)

    train_rows, val_rows = [], []
    for key, items in groups.items():
        items = list(items)
        rng.shuffle(items)
        n = len(items)
        if n <= 1:
            n_val = 0
        elif n < 5:
            n_val = 1
        else:
            n_val = max(1, int(round(n * val_ratio)))
            n_val = min(n_val, n - 1)
        val_rows.extend(items[:n_val])
        train_rows.extend(items[n_val:])

    rng.shuffle(train_rows)
    rng.shuffle(val_rows)
    return train_rows, val_rows


def copy_wavelet_files(src_wavelet_dir: Path | None, source_id: str, dst_wavelet_dir: Path, new_id: str) -> Dict[str, str]:
    out = {}
    if src_wavelet_dir is None or not src_wavelet_dir.exists():
        return out

    for src in sorted(src_wavelet_dir.glob(f"{source_id}*")):
        new_name = src.name.replace(source_id, new_id, 1)
        dst = dst_wavelet_dir / new_name
        safe_link_or_copy(src, dst)
        key = src.suffix.lower().lstrip(".") or "file"
        out[f"wavelet_{key}_path"] = str(dst)
    return out


def write_csv(path: Path, rows: List[Dict], fields: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})


def main() -> None:
    mkdirs()

    all_rows = []
    for ds in DATASETS:
        rows = load_source_rows(ds)
        print(f"[LOAD] {ds['name']}: {len(rows)} pairs from {ds['root']}")
        all_rows.extend(rows)

    if not all_rows:
        raise RuntimeError("No samples found. Check BASE_DIR and DATASETS roots.")

    train_rows, val_rows = stratified_split(all_rows, VAL_RATIO, RANDOM_SEED)
    print(f"[SPLIT] train={len(train_rows)}, val={len(val_rows)}, total={len(all_rows)}")

    final_rows = []
    global_idx = 1
    for split, rows in [("train", train_rows), ("val", val_rows)]:
        for r in rows:
            new_id = f"{global_idx:06d}"
            fname = f"{new_id}.dat"

            dst_lq = OUT_ROOT / split / "lq" / fname
            dst_gt = OUT_ROOT / split / "gt" / fname
            dst_meta = OUT_ROOT / split / "meta" / f"{new_id}.json"
            dst_wavelet_dir = OUT_ROOT / split / "wavelets"

            safe_link_or_copy(Path(r["source_lq_path"]), dst_lq)
            safe_link_or_copy(Path(r["source_gt_path"]), dst_gt)

            meta = dict(r.get("meta", {}))
            meta.update({
                "id": new_id,
                "split": split,
                "merged_dataset": OUT_ROOT.name,
                "source_dataset": r["source_dataset"],
                "source_root": r["source_root"],
                "source_id": r["source_id"],
                "source_lq_path": str(r["source_lq_path"]),
                "source_gt_path": str(r["source_gt_path"]),
                "n1": int(meta.get("n1", N1)),
                "n2": int(meta.get("n2", N2)),
            })
            with open(dst_meta, "w", encoding="utf-8") as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)

            wavelet_paths = copy_wavelet_files(
                r.get("source_wavelet_dir"),
                r["source_id"],
                dst_wavelet_dir,
                new_id,
            )

            final_row = {
                "id": new_id,
                "split": split,
                "source_dataset": r["source_dataset"],
                "source_id": r["source_id"],
                "variation": r.get("variation", ""),
                "family": r.get("family", ""),
                "structure": r.get("structure", ""),
                "phase_deg": r.get("phase_deg", 0.0),
                "phase_group": r.get("phase_group", ""),
                "lq_path": str(dst_lq),
                "gt_path": str(dst_gt),
                "meta_path": str(dst_meta),
            }
            final_row.update(wavelet_paths)
            final_rows.append(final_row)
            global_idx += 1

    fields = [
        "id", "split", "source_dataset", "source_id", "variation", "family", "structure",
        "phase_deg", "phase_group", "lq_path", "gt_path", "meta_path",
        "wavelet_npy_path", "wavelet_npz_path", "wavelet_file_path",
    ]
    write_csv(OUT_ROOT / "sample_index.csv", final_rows, fields)
    write_csv(OUT_ROOT / "train_index.csv", [r for r in final_rows if r["split"] == "train"], fields)
    write_csv(OUT_ROOT / "val_index.csv", [r for r in final_rows if r["split"] == "val"], fields)

    counts = {
        "total": len(final_rows),
        "train": sum(1 for r in final_rows if r["split"] == "train"),
        "val": sum(1 for r in final_rows if r["split"] == "val"),
        "by_split_source_dataset": dict(Counter(f"{r['split']}|{r['source_dataset']}" for r in final_rows)),
        "by_split_variation": dict(Counter(f"{r['split']}|{r['variation']}" for r in final_rows)),
        "by_split_family": dict(Counter(f"{r['split']}|{r['family']}" for r in final_rows)),
        "by_split_structure": dict(Counter(f"{r['split']}|{r['structure']}" for r in final_rows)),
        "by_split_phase": dict(Counter(f"{r['split']}|{r['phase_group']}" for r in final_rows)),
    }
    with open(OUT_ROOT / "sample_count.json", "w", encoding="utf-8") as f:
        json.dump(counts, f, ensure_ascii=False, indent=2)

    print("\n[DONE] merged dataset saved to:")
    print(f"  {OUT_ROOT}")
    print("\nUse these folders in your YAML:")
    print(f"  train lr_dir: {OUT_ROOT / 'train' / 'lq'}")
    print(f"  train hr_dir: {OUT_ROOT / 'train' / 'gt'}")
    print(f"  val   lr_dir: {OUT_ROOT / 'val' / 'lq'}")
    print(f"  val   hr_dir: {OUT_ROOT / 'val' / 'gt'}")
    print("\nCounts:")
    print(json.dumps(counts, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
