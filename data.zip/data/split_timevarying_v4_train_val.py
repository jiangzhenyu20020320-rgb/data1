from pathlib import Path
import json
import random
import shutil
from collections import defaultdict

ROOT = Path(r"D:\dateset0309\dataset_waveform_bwe_multistruct_timevarying_v4_fixed")

LQ_DIR = ROOT / "lq"
GT_DIR = ROOT / "gt"
META_DIR = ROOT / "meta"

TRAIN_LQ = ROOT / "train" / "lq"
TRAIN_GT = ROOT / "train" / "gt"
VAL_LQ = ROOT / "val" / "lq"
VAL_GT = ROOT / "val" / "gt"

TRAIN_META = ROOT / "train" / "meta"
VAL_META = ROOT / "val" / "meta"

VAL_RATIO = 0.20
SEED = 20260611

COPY_META = True


def ensure_dirs():
    for d in [TRAIN_LQ, TRAIN_GT, VAL_LQ, VAL_GT, TRAIN_META, VAL_META]:
        d.mkdir(parents=True, exist_ok=True)


def clear_split_dirs():
    # 只清空 train/val，不动原始 lq/gt/meta
    for d in [TRAIN_LQ, TRAIN_GT, VAL_LQ, VAL_GT, TRAIN_META, VAL_META]:
        if d.exists():
            for p in d.glob("*"):
                if p.is_file():
                    p.unlink()


def read_meta(dat_name):
    meta_path = META_DIR / dat_name.replace(".dat", ".json")
    if not meta_path.exists():
        return {}
    try:
        return json.loads(meta_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def copy_pair(dat_name, split):
    src_lq = LQ_DIR / dat_name
    src_gt = GT_DIR / dat_name

    if not src_lq.exists():
        raise FileNotFoundError(src_lq)
    if not src_gt.exists():
        raise FileNotFoundError(src_gt)

    if split == "train":
        shutil.copy2(src_lq, TRAIN_LQ / dat_name)
        shutil.copy2(src_gt, TRAIN_GT / dat_name)
        if COPY_META:
            src_meta = META_DIR / dat_name.replace(".dat", ".json")
            if src_meta.exists():
                shutil.copy2(src_meta, TRAIN_META / src_meta.name)
    elif split == "val":
        shutil.copy2(src_lq, VAL_LQ / dat_name)
        shutil.copy2(src_gt, VAL_GT / dat_name)
        if COPY_META:
            src_meta = META_DIR / dat_name.replace(".dat", ".json")
            if src_meta.exists():
                shutil.copy2(src_meta, VAL_META / src_meta.name)
    else:
        raise ValueError(split)


def main():
    ensure_dirs()
    clear_split_dirs()

    files = sorted([p.name for p in LQ_DIR.glob("*.dat")])
    if not files:
        raise RuntimeError(f"No .dat files found in {LQ_DIR}")

    # 优先按 structure + family 分层，避免 val 里结构或子波类型缺失
    groups = defaultdict(list)
    for name in files:
        meta = read_meta(name)
        structure = meta.get("structure", meta.get("structure_name", "unknown_structure"))
        family = meta.get("family", meta.get("wavelet_family", "unknown_family"))
        groups[(structure, family)].append(name)

    rng = random.Random(SEED)
    train_files = []
    val_files = []

    for key, names in sorted(groups.items()):
        names = list(names)
        rng.shuffle(names)

        if len(names) <= 1:
            n_val = 0
        else:
            n_val = max(1, round(len(names) * VAL_RATIO))

        val_part = names[:n_val]
        train_part = names[n_val:]

        val_files.extend(val_part)
        train_files.extend(train_part)

        print(f"group={key}, total={len(names)}, train={len(train_part)}, val={len(val_part)}")

    train_files = sorted(train_files)
    val_files = sorted(val_files)

    for name in train_files:
        copy_pair(name, "train")
    for name in val_files:
        copy_pair(name, "val")

    print()
    print("[OK] split completed")
    print(f"root      : {ROOT}")
    print(f"train num : {len(train_files)}")
    print(f"val num   : {len(val_files)}")
    print(f"train lq  : {TRAIN_LQ}")
    print(f"train gt  : {TRAIN_GT}")
    print(f"val lq    : {VAL_LQ}")
    print(f"val gt    : {VAL_GT}")


if __name__ == "__main__":
    main()