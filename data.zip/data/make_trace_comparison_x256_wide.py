
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt


# =========================================================
# 1. 路径与基础参数
# =========================================================

LQ_PATH = Path(
    r"C:\Users\uiuili\Desktop\dateset0309\dataset_waveform_bwe_multistruct_stationary_v2_stronger_ok\lq\0001.dat"
)

GT_PATH = Path(
    r"C:\Users\uiuili\Desktop\dateset0309\dataset_waveform_bwe_multistruct_stationary_v2_stronger_ok\gt\0001.dat"
)

OUT_DIR = Path(
    r"C:\Users\uiuili\Desktop\dateset0309"
)

SHAPE = (512, 512)
TRACE_IDX = 256

# 关键：
# "col" 表示 arr[:, 256]，通常对应 x=256 的纵向地震道；
# "row" 表示 arr[256, :]，用于检查是否数据方向读反。
MAIN_DIRECTION = "col"

# 是否做额外单道联合归一化：
# False：更接近原始 QC，推荐先用 False；
# True：会把该道最大绝对振幅归一化到 1，便于形态比较，但会改变真实幅值关系。
USE_EXTRA_JOINT_NORMALIZATION = False


# =========================================================
# 2. 读取 .dat
# =========================================================

def read_dat(path: Path, shape=(512, 512)) -> np.ndarray:
    arr = np.fromfile(str(path), dtype=np.float32)
    expected = shape[0] * shape[1]

    if arr.size != expected:
        raise ValueError(
            f"{path} size mismatch: got {arr.size}, expected {expected}. "
            f"请确认数据是否为 {shape[0]}x{shape[1]} 的 float32 dat。"
        )

    return arr.reshape(shape).astype(np.float32)


def get_trace(arr: np.ndarray, idx: int, direction: str) -> np.ndarray:
    if direction == "col":
        return arr[:, idx].copy()
    elif direction == "row":
        return arr[idx, :].copy()
    else:
        raise ValueError("direction must be 'col' or 'row'")


def normalize_pair_if_needed(lq_trace: np.ndarray, gt_trace: np.ndarray):
    if not USE_EXTRA_JOINT_NORMALIZATION:
        return lq_trace, gt_trace, "Amplitude"

    scale = max(
        float(np.max(np.abs(lq_trace))),
        float(np.max(np.abs(gt_trace))),
        1e-8,
    )
    return lq_trace / scale, gt_trace / scale, "Normalized amplitude"


# =========================================================
# 3. 单张横向拉长版 trace comparison
# =========================================================

def plot_wide_trace(
    lq: np.ndarray,
    gt: np.ndarray,
    direction: str,
    out_path: Path,
):
    lq_trace = get_trace(lq, TRACE_IDX, direction)
    gt_trace = get_trace(gt, TRACE_IDX, direction)

    lq_trace, gt_trace, ylabel = normalize_pair_if_needed(lq_trace, gt_trace)

    x = np.arange(lq_trace.size)

    plt.figure(figsize=(16, 4), dpi=220)

    # 保持旧 QC 风格：默认 matplotlib 蓝/橙两条线
    plt.plot(x, lq_trace, label="lq", linewidth=1.6)
    plt.plot(x, gt_trace, label="gt", linewidth=1.6)

    if direction == "col":
        title = f"Trace comparison x={TRACE_IDX}"
    else:
        title = f"Direction check: arr[{TRACE_IDX}, :]"

    plt.title(title, fontsize=18)
    plt.xlabel("Sample index", fontsize=14)
    plt.ylabel(ylabel, fontsize=14)
    plt.tick_params(labelsize=12)
    plt.legend(fontsize=12, loc="upper right")

    # 如果你想完全接近旧 QC，可以把下面这一行注释掉
    plt.grid(True, alpha=0.20)

    plt.tight_layout()
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close()

    print(f"[SAVE] {out_path}")


# =========================================================
# 4. 方向检查图：同时画 arr[:,256] 和 arr[256,:]
# =========================================================

def plot_direction_check(lq: np.ndarray, gt: np.ndarray, out_path: Path):
    lq_col = get_trace(lq, TRACE_IDX, "col")
    gt_col = get_trace(gt, TRACE_IDX, "col")

    lq_row = get_trace(lq, TRACE_IDX, "row")
    gt_row = get_trace(gt, TRACE_IDX, "row")

    lq_col, gt_col, ylabel_col = normalize_pair_if_needed(lq_col, gt_col)
    lq_row, gt_row, ylabel_row = normalize_pair_if_needed(lq_row, gt_row)

    x = np.arange(SHAPE[0])

    fig, axes = plt.subplots(2, 1, figsize=(16, 7), dpi=220)

    axes[0].plot(x, lq_col, label="lq", linewidth=1.5)
    axes[0].plot(x, gt_col, label="gt", linewidth=1.5)
    axes[0].set_title(f"Candidate A: arr[:, {TRACE_IDX}]  |  usually x={TRACE_IDX} trace", fontsize=15)
    axes[0].set_xlabel("Sample index", fontsize=12)
    axes[0].set_ylabel(ylabel_col, fontsize=12)
    axes[0].legend(fontsize=11, loc="upper right")
    axes[0].grid(True, alpha=0.20)

    axes[1].plot(x, lq_row, label="lq", linewidth=1.5)
    axes[1].plot(x, gt_row, label="gt", linewidth=1.5)
    axes[1].set_title(f"Candidate B: arr[{TRACE_IDX}, :]  |  use this if dat orientation is reversed", fontsize=15)
    axes[1].set_xlabel("Sample index", fontsize=12)
    axes[1].set_ylabel(ylabel_row, fontsize=12)
    axes[1].legend(fontsize=11, loc="upper right")
    axes[1].grid(True, alpha=0.20)

    plt.tight_layout()
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close()

    print(f"[SAVE] {out_path}")


# =========================================================
# 5. 主程序
# =========================================================

def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    print("[READ] LQ:", LQ_PATH)
    print("[READ] GT:", GT_PATH)

    lq = read_dat(LQ_PATH, SHAPE)
    gt = read_dat(GT_PATH, SHAPE)

    print("[INFO] lq shape:", lq.shape, "min:", float(lq.min()), "max:", float(lq.max()))
    print("[INFO] gt shape:", gt.shape, "min:", float(gt.min()), "max:", float(gt.max()))

    # 主图
    main_out = OUT_DIR / "trace_comparison_x256_wide.png"
    plot_wide_trace(
        lq=lq,
        gt=gt,
        direction=MAIN_DIRECTION,
        out_path=main_out,
    )

    # 方向检查图
    check_out = OUT_DIR / "trace_comparison_x256_direction_check.png"
    plot_direction_check(
        lq=lq,
        gt=gt,
        out_path=check_out,
    )

    # 备用 row 方向图
    row_out = OUT_DIR / "trace_comparison_x256_wide_row_candidate.png"
    plot_wide_trace(
        lq=lq,
        gt=gt,
        direction="row",
        out_path=row_out,
    )

    print("\n[DONE]")
    print("主图:", main_out)
    print("方向检查图:", check_out)
    print("备用 row 图:", row_out)


if __name__ == "__main__":
    main()