# -*- coding: utf-8 -*-
r"""
Multi-structure time-space-varying Ormsby waveform-preserving bandwidth-extension dataset generator.

V2-wavy: keeps shallow-high/deep-low trend, but adds smooth undulating iso-frequency boundaries.

目标：
- 多结构 + Ormsby 子波
- time-space-varying wavelet: 子波参数同时随深度/时间 t 和横向位置 x 变化
- 无噪声、同尺寸 LQ/GT（512x512 -> 512x512）
- LQ/GT 同源：每个局部 (x,t) 位置的 GT Ormsby 频带包络 LQ Ormsby 频带

使用方式：
把本脚本放到和以下构造生成脚本同一个文件夹：
  dongyingbatch.py
  helanjinhaiyanpendi.py
  huazhuang.py
  malinbatch_noise_dat.py
  malinbatchnewfold&noise&q.py
  tixingyanqiubatch_noise_dat.py

运行：
  python multi_structure_timespace_ormsby_bwe_v2_wavy.py

输出：
  dataset_waveform_bwe_multistruct_timespace_ormsby_v2_wavy/
    lq/*.dat
    gt/*.dat
    meta/*.json
    wavelets/*_w_lq.npy
    wavelets/*_w_gt.npy
    wavelets/*_wavelet_field.npz
    qc/*.png
    sample_index.csv
    sample_count.json
"""

import csv
import json
import shutil
import importlib.util
from pathlib import Path
from collections import Counter

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert


# =========================================================
# 0. 配置区：主要改这里
# =========================================================
SCRIPT_DIR = Path(__file__).resolve().parent

SOURCE_SCRIPTS = [
    {"name": "dongying",        "file": "dongyingbatch.py"},
    {"name": "helan_basin",     "file": "helanjinhaiyanpendi.py"},
    {"name": "huazhuang",       "file": "huazhuang.py"},
    {"name": "malin",           "file": "malinbatch_noise_dat.py"},
    {"name": "malin_newfold",   "file": "malinbatchnewfold&noise&q.py"},
    {"name": "tixing_salt",     "file": "tixingyanqiubatch_noise_dat.py"},
]

# 第一版先小规模 QC。满意后再改成 20、300 或 500。
NUM_PER_STRUCTURE = 5

# 输出尺寸：注意本项目的反射模型通常为 [trace, sample] = [N2, N1]
N1 = 512  # sample/depth/time axis
N2 = 512  # trace/x axis

DT = 0.004
WAVELET_LENGTH = 0.256

# 时空变非平稳卷积参数
# TIME_WIN/TIME_STEP 控制纵向时变平滑程度；X_GROUP 控制横向空变精度。
TIME_WIN = 128
TIME_STEP = 32
X_GROUP = 8

OUT_DIR = SCRIPT_DIR / "dataset_waveform_bwe_multistruct_timespace_ormsby_v2_wavy"
LQ_DIR = OUT_DIR / "lq"
GT_DIR = OUT_DIR / "gt"
META_DIR = OUT_DIR / "meta"
WAVELET_DIR = OUT_DIR / "wavelets"
QC_DIR = OUT_DIR / "qc"

START_INDEX = 1
RANDOM_SEED = 2026
COPY_SOURCE_SCRIPTS = True

# QC 中展示 3x3 代表位置：left/middle/right × top/middle/bottom
REP_XS = [0.15, 0.50, 0.85]
REP_DEPTHS = [0.15, 0.50, 0.85]
REP_X_NAMES = ["left", "middle", "right"]
REP_D_NAMES = ["top", "middle", "bottom"]

# 相位：第一版建议常相位 + 很弱的二维漂移，避免相位变化掩盖频带规律。
PHASE_PROB = 0.50
PHASE_RANGE = (-30.0, 30.0)
PHASE_DEPTH_DRIFT_RANGE = (-6.0, 6.0)
PHASE_X_DRIFT_RANGE = (-5.0, 5.0)

# QC 保存策略
QC_FIRST_N = 8
QC_EVERY = 50

# =========================================================
# 0.1 频率分布形态控制：让等频率分界线产生“平滑起伏”
# =========================================================
# 说明：
# - 保持整体浅层高频、深层低频；
# - 同时让 f3/f4 的等频率边界不要过于笔直；
# - 以“右高左低”为默认横向趋势。

# 横向主趋势：None 表示随机选择；
# 可选："left_high", "right_high", "middle_high", "middle_low"。
SPACE_PROFILE_FORCE_MODE = "right_high"
SPACE_PROFILE_AMP_RANGE = (0.12, 0.20)
SPACE_PROFILE_NOISE_STD = 0.010
SPACE_PROFILE_CLIP = (0.78, 1.24)

# 深度等效偏移：控制等频率线的弯曲程度。
# depth_warp > 0 表示该横向位置等效更浅，因此频率偏高。
DEPTH_WARP_RIGHT_HIGH_STRENGTH = 0.070
DEPTH_WARP_WAVE_STRENGTH = 0.045
DEPTH_WARP_CLIP = 0.12

# 高频端局部平滑起伏：主要作用于 f3/f4，不明显扰动 f1/f2。
HF_WAVE_LQ_F3 = 0.80
HF_WAVE_LQ_F4 = 1.25
HF_WAVE_GT_F3 = 1.10
HF_WAVE_GT_F4 = 1.70


# =========================================================
# 1. 基础工具函数
# =========================================================
def ensure_dirs():
    for d in [LQ_DIR, GT_DIR, META_DIR, WAVELET_DIR, QC_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def sanitize_float(x):
    return float(np.asarray(x).item())


def time_axis(dt=0.004, length=0.256):
    return np.arange(-length / 2.0, length / 2.0 + 0.5 * dt, dt, dtype=np.float32)


def normalize_wavelet(w):
    w = np.asarray(w, dtype=np.float64)
    w = w - np.mean(w)
    m = np.max(np.abs(w))
    if m > 1e-12:
        w = w / m
    return w.astype(np.float32)


def phase_rotate(w, phase_deg=0.0):
    w = np.asarray(w, dtype=np.float64)
    if abs(float(phase_deg)) < 1e-12:
        return normalize_wavelet(w)
    wh = np.imag(hilbert(w))
    phi = np.deg2rad(float(phase_deg))
    wp = np.cos(phi) * w - np.sin(phi) * wh
    return normalize_wavelet(wp)


def centered_wavelet_from_amp(amp, n_wavelet, nfft):
    amp = np.asarray(amp, dtype=np.float64)
    amp = np.maximum(amp, 0.0)
    amp[0] = 0.0
    w_full = np.fft.irfft(amp.astype(np.complex128), n=nfft)
    w_full = np.fft.fftshift(w_full)
    center = nfft // 2
    half = n_wavelet // 2
    start = center - half
    w = w_full[start:start + n_wavelet]
    return normalize_wavelet(w)


def high_frequency_taper(freqs, f_start=108.0, f_end=124.0):
    taper = np.ones_like(freqs, dtype=np.float64)
    taper[freqs >= f_end] = 0.0
    m = (freqs > f_start) & (freqs < f_end)
    if np.any(m):
        x = (freqs[m] - f_start) / (f_end - f_start + 1e-12)
        taper[m] = 0.5 + 0.5 * np.cos(np.pi * x)
    return taper


def smooth_max(a, b, p=10.0):
    a = np.maximum(np.asarray(a, dtype=np.float64), 0.0)
    b = np.maximum(np.asarray(b, dtype=np.float64), 0.0)
    return (a ** p + b ** p) ** (1.0 / p)


def trapezoid_amp(freqs, f1, f2, f3, f4):
    freqs = np.asarray(freqs, dtype=np.float64)
    amp = np.zeros_like(freqs, dtype=np.float64)

    m = (freqs >= f1) & (freqs < f2)
    if np.any(m):
        amp[m] = (freqs[m] - f1) / (f2 - f1 + 1e-12)

    amp[(freqs >= f2) & (freqs <= f3)] = 1.0

    m = (freqs > f3) & (freqs <= f4)
    if np.any(m):
        amp[m] = 1.0 - (freqs[m] - f3) / (f4 - f3 + 1e-12)

    return np.clip(amp, 0.0, 1.0)


def amplitude_spectrum(w, dt=0.004, nfft=4096):
    w = np.asarray(w, dtype=np.float32)
    W = np.fft.rfft(w, n=nfft)
    amp = np.abs(W)
    amp = amp / (np.max(amp) + 1e-12)
    f = np.fft.rfftfreq(nfft, d=dt)
    return f, amp


def fix_lq_band(b):
    f1, f2, f3, f4 = [float(x) for x in b]
    f1 = max(5.0, min(f1, 14.0))
    f2 = max(f2, f1 + 3.5)
    f3 = max(f3, f2 + 8.0)
    f4 = max(f4, f3 + 6.0)
    f4 = min(f4, 62.0)
    return np.array([f1, f2, f3, f4], dtype=np.float64)


def fix_gt_band(b, lq_b):
    f1, f2, f3, f4 = [float(x) for x in b]
    lq_b = np.asarray(lq_b, dtype=np.float64)

    # GT 低频端比 LQ 更向低频延伸
    f1 = max(1.5, min(f1, lq_b[0] - 2.0))
    f2 = max(f2, f1 + 3.0)
    f2 = min(f2, lq_b[1] - 2.0)

    # GT 高频端包络 LQ 高频端
    f3 = max(f3, lq_b[2] + 14.0)
    f4 = max(f4, f3 + 12.0)
    f4 = max(f4, lq_b[3] + 20.0)
    f4 = min(f4, 112.0)

    # 若 f2 被压得不合理，做最后保护
    if f2 <= f1 + 2.0:
        f2 = f1 + 3.0
    if f3 <= f2 + 12.0:
        f3 = f2 + 12.0
    if f4 <= f3 + 10.0:
        f4 = f3 + 10.0

    return np.array([f1, f2, f3, f4], dtype=np.float64)


def ormsby_pair_from_bands(band_lq, band_gt, phase_deg, dt=0.004, length=0.256):
    n = len(time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)

    A_lq = trapezoid_amp(freqs, *band_lq)
    A_gt_raw = trapezoid_amp(freqs, *band_gt)
    A_gt = smooth_max(A_gt_raw, A_lq, p=10.0)
    A_gt *= high_frequency_taper(freqs, f_start=108.0, f_end=124.0)
    A_gt[0] = 0.0
    A_gt = A_gt / (np.max(A_gt) + 1e-12)

    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)
    return phase_rotate(w_lq0, phase_deg), phase_rotate(w_gt0, phase_deg)


# =========================================================
# 2. Ormsby 时空变参数场
# =========================================================
def make_space_profile(rng, x_anchors):
    """
    返回横向 profile，中心值约为 1；>1 表示频带较高，<1 表示频带较低。

    V2-wavy 默认使用 right_high：右侧整体高频、左侧整体低频；
    同时保留轻微随机扰动，避免所有样本完全一致。
    """
    if SPACE_PROFILE_FORCE_MODE is None:
        mode = str(rng.choice(["left_high", "right_high", "middle_high", "middle_low"]))
    else:
        mode = str(SPACE_PROFILE_FORCE_MODE)

    amp = float(rng.uniform(SPACE_PROFILE_AMP_RANGE[0], SPACE_PROFILE_AMP_RANGE[1]))

    if mode == "left_high":
        prof = np.linspace(1.0 + amp, 1.0 - amp, len(x_anchors))
    elif mode == "right_high":
        prof = np.linspace(1.0 - amp, 1.0 + amp, len(x_anchors))
    elif mode == "middle_high":
        prof = 1.0 + amp * np.exp(-((x_anchors - 0.5) / 0.28) ** 2)
        prof = prof - (np.mean(prof) - 1.0)
    elif mode == "middle_low":
        prof = 1.0 - amp * np.exp(-((x_anchors - 0.5) / 0.28) ** 2)
        prof = prof - (np.mean(prof) - 1.0)
    else:
        raise ValueError(mode)

    # 很弱扰动，增强样本多样性；再约束范围。
    prof += rng.normal(0.0, SPACE_PROFILE_NOISE_STD, size=len(x_anchors))
    prof = np.clip(prof, SPACE_PROFILE_CLIP[0], SPACE_PROFILE_CLIP[1])
    return prof.astype(np.float64), mode, amp


def make_depth_warp_profile(rng, x_anchors, profile_mode):
    """
    构造横向方向的“等效深度偏移” depth_warp(x)。

    目的：
    - 保持浅层高频、深层低频的大趋势；
    - 但让等频率分界线产生平滑起伏，不再是规则直线/斜坡。

    depth_warp > 0：该 x 位置使用更浅的等效深度，频率偏高；
    depth_warp < 0：该 x 位置使用更深的等效深度，频率偏低。
    """
    x01 = np.asarray(x_anchors, dtype=np.float64)

    if profile_mode == "right_high":
        main_trend = np.linspace(-1.0, 1.0, len(x01))
    elif profile_mode == "left_high":
        main_trend = np.linspace(1.0, -1.0, len(x01))
    elif profile_mode == "middle_high":
        main_trend = np.exp(-((x01 - 0.5) / 0.28) ** 2)
        main_trend = main_trend - np.mean(main_trend)
        main_trend = main_trend / (np.max(np.abs(main_trend)) + 1e-12)
    elif profile_mode == "middle_low":
        main_trend = -np.exp(-((x01 - 0.5) / 0.28) ** 2)
        main_trend = main_trend - np.mean(main_trend)
        main_trend = main_trend / (np.max(np.abs(main_trend)) + 1e-12)
    else:
        main_trend = np.zeros_like(x01)

    phase1 = float(rng.uniform(0.0, 2.0 * np.pi))
    phase2 = float(rng.uniform(0.0, 2.0 * np.pi))

    wave_x = (
        0.65 * np.sin(2.0 * np.pi * x01 + phase1)
        + 0.35 * np.sin(4.0 * np.pi * x01 + phase2)
    )
    wave_x = wave_x - np.mean(wave_x)
    wave_x = wave_x / (np.max(np.abs(wave_x)) + 1e-12)

    depth_warp = (
        DEPTH_WARP_RIGHT_HIGH_STRENGTH * main_trend
        + DEPTH_WARP_WAVE_STRENGTH * wave_x
    )
    depth_warp = np.clip(depth_warp, -DEPTH_WARP_CLIP, DEPTH_WARP_CLIP)

    return depth_warp.astype(np.float64), wave_x.astype(np.float64), phase1, phase2


def make_phase_grid(rng, depth_anchors, x_anchors):
    if rng.random() >= PHASE_PROB:
        phase_grid = np.zeros((len(depth_anchors), len(x_anchors)), dtype=np.float64)
        return phase_grid, 0.0

    base = float(rng.uniform(PHASE_RANGE[0], PHASE_RANGE[1]))
    if abs(base) < 3.0:
        base = 3.0 if base >= 0 else -3.0

    d_drift = float(rng.uniform(PHASE_DEPTH_DRIFT_RANGE[0], PHASE_DEPTH_DRIFT_RANGE[1]))
    x_drift = float(rng.uniform(PHASE_X_DRIFT_RANGE[0], PHASE_X_DRIFT_RANGE[1]))

    d_term = np.linspace(-0.5, 0.5, len(depth_anchors))[:, None] * d_drift
    x_term = np.linspace(-0.5, 0.5, len(x_anchors))[None, :] * x_drift
    phase_grid = base + d_term + x_term
    return phase_grid.astype(np.float64), base


def make_ormsby_timespace_wavelet_model(rng, dt=0.004, length=0.256):
    # 更多锚点使参数场有足够自由度形成“平滑起伏”的等频率边界。
    depth_anchors = np.array([0.0, 0.20, 0.40, 0.62, 0.82, 1.0], dtype=np.float64)
    x_anchors = np.array([0.0, 0.125, 0.25, 0.375, 0.50, 0.625, 0.75, 0.875, 1.0], dtype=np.float64)

    # 1) 基础时变频带：浅层频带较高，深层高频端下降。
    lq_top = np.array([
        rng.uniform(8.5, 11.5),
        rng.uniform(14.0, 19.0),
        rng.uniform(33.0, 40.0),
        rng.uniform(48.0, 56.0),
    ], dtype=np.float64)
    lq_bottom = np.array([
        rng.uniform(7.0, 10.0),
        rng.uniform(12.0, 17.0),
        rng.uniform(25.0, 31.0),
        rng.uniform(37.0, 45.0),
    ], dtype=np.float64)

    gt_top = np.array([
        rng.uniform(2.5, 4.8),
        rng.uniform(6.0, 9.5),
        rng.uniform(64.0, 78.0),
        rng.uniform(92.0, 108.0),
    ], dtype=np.float64)
    gt_bottom = np.array([
        rng.uniform(2.5, 4.8),
        rng.uniform(5.5, 9.0),
        rng.uniform(50.0, 62.0),
        rng.uniform(76.0, 90.0),
    ], dtype=np.float64)

    # 2) 横向空变 profile：主要作用于高频端 f3/f4；低频端只轻微变化。
    profile, profile_mode, profile_amp = make_space_profile(rng, x_anchors)

    # 3) 等效深度偏移：让高/中/低频分界线产生起伏，而不是直线斜坡。
    depth_warp, boundary_wave_x, warp_phase1, warp_phase2 = make_depth_warp_profile(
        rng,
        x_anchors,
        profile_mode,
    )

    band_lq_grid = np.zeros((len(depth_anchors), len(x_anchors), 4), dtype=np.float64)
    band_gt_grid = np.zeros_like(band_lq_grid)

    # 不同参数的横向调制强度。
    # f3/f4 强；f1/f2 弱，避免低频端过度波动。
    lq_strength = np.array([0.25, 0.35, 0.90, 1.00], dtype=np.float64)
    gt_strength = np.array([0.15, 0.25, 0.75, 0.85], dtype=np.float64)

    for idp in range(len(depth_anchors)):
        for ix in range(len(x_anchors)):
            p = profile[ix]
            lq_factor = 1.0 + (p - 1.0) * lq_strength
            gt_factor = 1.0 + (p - 1.0) * gt_strength

            # 关键：用“等效深度”构造基础频带。
            # depth_warp > 0 表示该横向位置等效更浅，因此频率偏高。
            d = float(depth_anchors[idp])
            d_eff = float(np.clip(d - depth_warp[ix], 0.0, 1.0))

            lq_b = lq_top + (lq_bottom - lq_top) * d_eff
            gt_b = gt_top + (gt_bottom - gt_top) * d_eff

            # 低频端改用小幅加性扰动会更稳定；高频端使用乘性调制。
            lq_b[0] += (p - 1.0) * 4.0
            lq_b[1] += (p - 1.0) * 5.0
            lq_b[2:] *= lq_factor[2:]

            gt_b[0] += (p - 1.0) * 2.0
            gt_b[1] += (p - 1.0) * 2.5
            gt_b[2:] *= gt_factor[2:]

            # 只对 f3/f4 加入平滑波动，让等频率分界线更自然起伏。
            # d_gate 使扰动在浅/深边界较弱，在中部较强，避免破坏整体浅高深低趋势。
            d_gate = float(np.sin(np.pi * d))
            x_val = float(x_anchors[ix])
            hf_wave = (
                0.8 * np.sin(2.0 * np.pi * x_val + warp_phase1 + 0.7 * d)
                + 0.4 * np.sin(4.0 * np.pi * x_val + warp_phase2 - 0.5 * d)
            )

            lq_b[2] += HF_WAVE_LQ_F3 * hf_wave * d_gate
            lq_b[3] += HF_WAVE_LQ_F4 * hf_wave * d_gate
            gt_b[2] += HF_WAVE_GT_F3 * hf_wave * d_gate
            gt_b[3] += HF_WAVE_GT_F4 * hf_wave * d_gate

            # 小随机扰动，增强多样性；幅度保持较小，避免频率场变成噪声场。
            lq_b += rng.normal(0.0, [0.10, 0.12, 0.25, 0.30])
            gt_b += rng.normal(0.0, [0.08, 0.10, 0.35, 0.45])

            lq_b = fix_lq_band(lq_b)
            gt_b = fix_gt_band(gt_b, lq_b)
            band_lq_grid[idp, ix] = lq_b
            band_gt_grid[idp, ix] = gt_b

    phase_grid, phase_base = make_phase_grid(rng, depth_anchors, x_anchors)

    def interp_grid(x_norm, depth_norm, grid):
        """Bilinear interpolation over [depth_anchor, x_anchor]."""
        x_norm = float(np.clip(x_norm, 0.0, 1.0))
        depth_norm = float(np.clip(depth_norm, 0.0, 1.0))
        grid = np.asarray(grid, dtype=np.float64)

        # 先沿 x 插值，得到每个 depth_anchor 上的参数。
        vals_d = np.zeros((len(depth_anchors),) + grid.shape[2:], dtype=np.float64)
        for d in range(len(depth_anchors)):
            if grid.ndim == 3:
                for k in range(grid.shape[2]):
                    vals_d[d, k] = np.interp(x_norm, x_anchors, grid[d, :, k])
            else:
                vals_d[d] = np.interp(x_norm, x_anchors, grid[d, :])

        # 再沿 depth 插值。
        if grid.ndim == 3:
            out = np.zeros((grid.shape[2],), dtype=np.float64)
            for k in range(grid.shape[2]):
                out[k] = np.interp(depth_norm, depth_anchors, vals_d[:, k])
            return out
        return float(np.interp(depth_norm, depth_anchors, vals_d))

    def wavelet_func(x_norm, depth_norm):
        b_lq = fix_lq_band(interp_grid(x_norm, depth_norm, band_lq_grid))
        b_gt = fix_gt_band(interp_grid(x_norm, depth_norm, band_gt_grid), b_lq)
        phase = interp_grid(x_norm, depth_norm, phase_grid)
        w_lq, w_gt = ormsby_pair_from_bands(b_lq, b_gt, phase, dt=dt, length=length)
        return w_lq, w_gt, {
            "x_norm": sanitize_float(x_norm),
            "depth_norm": sanitize_float(depth_norm),
            "band_lq": [sanitize_float(x) for x in b_lq],
            "band_gt": [sanitize_float(x) for x in b_gt],
            "phase_deg": sanitize_float(phase),
        }

    meta = {
        "family": "ormsby",
        "variation": "time_space",
        "stationary": False,
        "time_varying": True,
        "space_varying": True,
        "noise": False,
        "same_size": True,
        "phase_deg": sanitize_float(phase_base),
        "depth_anchors": [sanitize_float(x) for x in depth_anchors],
        "x_anchors": [sanitize_float(x) for x in x_anchors],
        "space_profile_mode": profile_mode,
        "space_profile_amp": sanitize_float(profile_amp),
        "space_profile": [sanitize_float(x) for x in profile],
        "boundary_design": "right/space trend plus smooth depth-warp and high-frequency wave perturbation; preserves shallow-high/deep-low trend while making iso-frequency boundaries wavy.",
        "depth_warp": [sanitize_float(x) for x in depth_warp],
        "boundary_wave_x": [sanitize_float(x) for x in boundary_wave_x],
        "warp_phase1": sanitize_float(warp_phase1),
        "warp_phase2": sanitize_float(warp_phase2),
        "depth_warp_right_high_strength": sanitize_float(DEPTH_WARP_RIGHT_HIGH_STRENGTH),
        "depth_warp_wave_strength": sanitize_float(DEPTH_WARP_WAVE_STRENGTH),
        "hf_wave_lq_f3": sanitize_float(HF_WAVE_LQ_F3),
        "hf_wave_lq_f4": sanitize_float(HF_WAVE_LQ_F4),
        "hf_wave_gt_f3": sanitize_float(HF_WAVE_GT_F3),
        "hf_wave_gt_f4": sanitize_float(HF_WAVE_GT_F4),
        "band_lq_grid": [[[sanitize_float(v) for v in band_lq_grid[i, j]] for j in range(len(x_anchors))] for i in range(len(depth_anchors))],
        "band_gt_grid": [[[sanitize_float(v) for v in band_gt_grid[i, j]] for j in range(len(x_anchors))] for i in range(len(depth_anchors))],
        "phase_grid": [[sanitize_float(v) for v in row] for row in phase_grid],
        "ts_rule": "Time-space-varying Ormsby V2-wavy: high-frequency corners decrease with depth, follow right-high/left-low spatial trend, and include smooth undulating iso-frequency boundaries; GT band envelopes LQ at each local (x,t) position.",
    }

    return wavelet_func, meta


# =========================================================
# 3. 卷积、归一化、QC
# =========================================================
def convolve_along_depth(img, wavelet):
    img = np.asarray(img, dtype=np.float32)
    wavelet = np.asarray(wavelet, dtype=np.float32)
    n2, n1 = img.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))
    IMG = np.fft.rfft(img, n=nfft, axis=1)
    W = np.fft.rfft(wavelet, n=nfft)
    y = np.fft.irfft(IMG * W[None, :], n=nfft, axis=1)
    start = (nw - 1) // 2
    return y[:, start:start + n1].astype(np.float32)


def make_window_starts(n, win, step):
    if n <= win:
        return [0]
    starts = list(range(0, n - win + 1, step))
    if starts[-1] != n - win:
        starts.append(n - win)
    return sorted(set(starts))


def convolve_time_space_varying(img, wavelet_func, time_win=128, time_step=32, x_group=8):
    """
    时空变非平稳卷积：
    - 横向按 trace group 分组；
    - 纵向按 time window 分窗；
    - 每个局部 (x_group_center, time_window_center) 生成一对 Ormsby 子波；
    - 对该横向组做完整深度卷积，只取对应时间窗，用 Hann overlap-add 融合。
    """
    img = np.asarray(img, dtype=np.float32)
    n2, n1 = img.shape

    t_starts = make_window_starts(n1, time_win, time_step)
    t_weight = 0.05 + 0.95 * np.hanning(time_win).astype(np.float32)

    out_lq = np.zeros_like(img, dtype=np.float32)
    out_gt = np.zeros_like(img, dtype=np.float32)
    wsum = np.zeros_like(img, dtype=np.float32)

    records = []

    for x0 in range(0, n2, x_group):
        x1 = min(x0 + x_group, n2)
        x_mid = 0.5 * (x0 + x1 - 1)
        x_norm = float(np.clip(x_mid / max(n2 - 1, 1), 0.0, 1.0))
        img_g = img[x0:x1, :]

        for s in t_starts:
            e = s + time_win
            depth_norm = float(np.clip((s + 0.5 * time_win) / max(n1 - 1, 1), 0.0, 1.0))

            w_lq, w_gt, local_meta = wavelet_func(x_norm, depth_norm)
            conv_lq = convolve_along_depth(img_g, w_lq)
            conv_gt = convolve_along_depth(img_g, w_gt)

            out_lq[x0:x1, s:e] += conv_lq[:, s:e] * t_weight[None, :]
            out_gt[x0:x1, s:e] += conv_gt[:, s:e] * t_weight[None, :]
            wsum[x0:x1, s:e] += t_weight[None, :]

            rec = dict(local_meta)
            rec.update({
                "x_start": int(x0),
                "x_end": int(x1),
                "window_start": int(s),
                "window_end": int(e),
            })
            records.append(rec)

    out_lq = out_lq / np.maximum(wsum, 1e-6)
    out_gt = out_gt / np.maximum(wsum, 1e-6)
    return out_lq.astype(np.float32), out_gt.astype(np.float32), records


def normalize_pair_shared(lq, gt, percentile=99.5, scale_floor=1e-6):
    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)
    vals = np.concatenate([np.abs(lq).reshape(-1), np.abs(gt).reshape(-1)])
    scale = float(np.percentile(vals, percentile))
    scale = max(scale, float(scale_floor))
    lq_n = np.clip(lq / scale, -1.0, 1.0).astype(np.float32)
    gt_n = np.clip(gt / scale, -1.0, 1.0).astype(np.float32)
    return lq_n, gt_n, scale


def collect_representative_wavelets(wavelet_func):
    rep_w_lq = np.zeros((len(REP_DEPTHS), len(REP_XS), len(time_axis(DT, WAVELET_LENGTH))), dtype=np.float32)
    rep_w_gt = np.zeros_like(rep_w_lq)
    rep_metas = []
    for idp, d in enumerate(REP_DEPTHS):
        row = []
        for ix, x in enumerate(REP_XS):
            w_lq, w_gt, lm = wavelet_func(x, d)
            rep_w_lq[idp, ix] = w_lq
            rep_w_gt[idp, ix] = w_gt
            row.append(lm)
        rep_metas.append(row)
    return rep_w_lq, rep_w_gt, rep_metas


def compute_band_f4_maps(wavelet_func, n1=512, n2=512):
    # 用于 QC 的参数色图：为节省时间，按每 4 个像素采样后插值显示也可以；这里直接计算完整 512x512。
    lq_f4 = np.zeros((n1, n2), dtype=np.float32)
    gt_f4 = np.zeros((n1, n2), dtype=np.float32)
    for iz in range(n1):
        d = iz / max(n1 - 1, 1)
        for ix in range(n2):
            x = ix / max(n2 - 1, 1)
            _, _, lm = wavelet_func(x, d)
            lq_f4[iz, ix] = lm["band_lq"][3]
            gt_f4[iz, ix] = lm["band_gt"][3]
    return lq_f4, gt_f4


def save_qc_figure_timespace_ormsby(lq, gt, rep_w_lq, rep_w_gt, rep_metas, meta, out_png, dt=0.004):
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)

    clip = np.percentile(np.abs(np.concatenate([lq.reshape(-1), gt.reshape(-1)])), 99.0)
    clip = max(float(clip), 1e-6)
    x_trace = lq.shape[0] // 2
    t = time_axis(dt, WAVELET_LENGTH)

    fig = plt.figure(figsize=(22, 15), dpi=140)

    ax1 = plt.subplot(4, 3, 1)
    ax1.imshow(lq.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax1.set_title("LQ narrow-band, time-space-varying")

    ax2 = plt.subplot(4, 3, 2)
    ax2.imshow(gt.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax2.set_title("GT broadband, time-space-varying")

    ax3 = plt.subplot(4, 3, 3)
    ax3.plot(lq[x_trace, :], label="lq")
    ax3.plot(gt[x_trace, :], label="gt")
    ax3.set_title(f"Trace comparison x={x_trace}")
    ax3.legend(fontsize=8)
    ax3.grid(True, alpha=0.2)

    # 参数图：LQ/GT f4 map
    # 为避免 QC 过慢，这里根据 meta 的 anchor grid 近似生成 f4 map。
    x_vals = np.linspace(0, 1, N2)
    d_vals = np.linspace(0, 1, N1)
    depth_anchors = np.asarray(meta["depth_anchors"], dtype=np.float64)
    x_anchors = np.asarray(meta["x_anchors"], dtype=np.float64)
    band_lq_grid = np.asarray(meta["band_lq_grid"], dtype=np.float64)
    band_gt_grid = np.asarray(meta["band_gt_grid"], dtype=np.float64)

    def interp_f4_map(grid):
        # grid: [D, X, 4]
        temp = np.zeros((len(depth_anchors), N2), dtype=np.float32)
        for idp in range(len(depth_anchors)):
            temp[idp, :] = np.interp(x_vals, x_anchors, grid[idp, :, 3])
        out = np.zeros((N1, N2), dtype=np.float32)
        for ix in range(N2):
            out[:, ix] = np.interp(d_vals, depth_anchors, temp[:, ix])
        return out

    lq_f4_map = interp_f4_map(band_lq_grid)
    gt_f4_map = interp_f4_map(band_gt_grid)

    ax4 = plt.subplot(4, 3, 4)
    im4 = ax4.imshow(lq_f4_map, cmap="turbo", aspect="auto", origin="upper")
    ax4.set_title("LQ Ormsby f4 map (Hz)")
    fig.colorbar(im4, ax=ax4, shrink=0.75)

    ax5 = plt.subplot(4, 3, 5)
    im5 = ax5.imshow(gt_f4_map, cmap="turbo", aspect="auto", origin="upper")
    ax5.set_title("GT Ormsby f4 map (Hz)")
    fig.colorbar(im5, ax=ax5, shrink=0.75)

    ax6 = plt.subplot(4, 3, 6)
    mid_x = 1
    ax6.plot(REP_DEPTHS, [rep_metas[i][mid_x]["band_lq"][3] for i in range(3)], marker="o", label="LQ f4 @ middle x")
    ax6.plot(REP_DEPTHS, [rep_metas[i][mid_x]["band_gt"][3] for i in range(3)], marker="o", label="GT f4 @ middle x")
    mid_d = 1
    ax6.plot(REP_XS, [rep_metas[mid_d][j]["band_lq"][3] for j in range(3)], marker="s", label="LQ f4 @ middle depth")
    ax6.plot(REP_XS, [rep_metas[mid_d][j]["band_gt"][3] for j in range(3)], marker="s", label="GT f4 @ middle depth")
    ax6.set_title("Representative f4 trends")
    ax6.set_xlabel("normalized coordinate")
    ax6.set_ylabel("Hz")
    ax6.legend(fontsize=7)
    ax6.grid(True, alpha=0.25)

    # 代表性频谱：按 top/middle/bottom 三个深度分别画 left/middle/right。
    for idp, dname in enumerate(REP_D_NAMES):
        ax = plt.subplot(4, 3, 7 + idp)
        for ix, xname in enumerate(REP_X_NAMES):
            f_lq, a_lq = amplitude_spectrum(rep_w_lq[idp, ix], dt=dt)
            f_gt, a_gt = amplitude_spectrum(rep_w_gt[idp, ix], dt=dt)
            ax.plot(f_lq, a_lq, linestyle="--", linewidth=1.0, label=f"{xname} lq")
            ax.plot(f_gt, a_gt, linestyle="-", linewidth=1.0, label=f"{xname} gt")
        ax.set_xlim(0, 120)
        ax.set_ylim(0, 1.08)
        ax.set_title(f"Representative spectra: {dname}")
        ax.legend(fontsize=6, ncol=2)
        ax.grid(True, alpha=0.20)

    ax10 = plt.subplot(4, 3, 10)
    ax10.axis("off")
    local_show = []
    for idp, dname in enumerate(REP_D_NAMES):
        for ix, xname in enumerate(REP_X_NAMES):
            m = rep_metas[idp][ix]
            local_show.append({
                "pos": f"{xname}-{dname}",
                "lq_f4": round(m["band_lq"][3], 2),
                "gt_f4": round(m["band_gt"][3], 2),
                "lq_band": [round(v, 2) for v in m["band_lq"]],
                "gt_band": [round(v, 2) for v in m["band_gt"]],
            })
    ax10.text(0, 1, json.dumps(local_show, ensure_ascii=False, indent=2), va="top", ha="left", fontsize=6.5, family="monospace")
    ax10.set_title("3x3 local band meta")

    ax11 = plt.subplot(4, 3, 11)
    ax11.axis("off")
    meta_show = dict(meta)
    for k in ["band_lq_grid", "band_gt_grid", "phase_grid"]:
        meta_show[k] = "see json/npz"
    txt = json.dumps(meta_show, ensure_ascii=False, indent=2)
    ax11.text(0, 1, txt, va="top", ha="left", fontsize=6.5, family="monospace")
    ax11.set_title("global meta")

    ax12 = plt.subplot(4, 3, 12)
    ax12.axis("off")
    ax12.text(
        0, 1,
        "QC checklist:\n"
        "1) GT spectra envelope LQ at 3x3 positions.\n"
        "2) f4 decreases with depth but also changes along x.\n"
        "3) LQ/GT sections show no obvious vertical stripes.\n"
        "4) LQ/GT sections show no obvious time-window seams.\n"
        "5) Phase/peak positions remain consistent between LQ and GT.",
        va="top", ha="left", fontsize=9,
    )

    plt.tight_layout()
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)


# =========================================================
# 4. 动态加载反射结构脚本
# =========================================================
def load_generator_class(script_path, module_name):
    script_path = Path(script_path)
    if not script_path.exists():
        raise FileNotFoundError(f"Source script not found: {script_path}")
    spec = importlib.util.spec_from_file_location(module_name, str(script_path))
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    if not hasattr(mod, "GeologicalSeismicData"):
        raise AttributeError(f"{script_path.name} does not contain class GeologicalSeismicData")
    return mod.GeologicalSeismicData


def generate_reflectivity(GeneratorClass, seed, n1=512, n2=512):
    gen = GeneratorClass(seed=seed)
    try:
        model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0)
    except TypeError:
        if hasattr(gen, "generate_plausible_parameters"):
            params = gen.generate_plausible_parameters(n1=n1, n2=n2)
            model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0, params=params)
        else:
            raise
    model = np.asarray(model, dtype=np.float32)
    if model.shape != (n2, n1):
        raise ValueError(f"Unexpected model shape {model.shape}, expected {(n2, n1)}")
    return model


# =========================================================
# 5. 索引、复现信息
# =========================================================
def phase_group(phase_deg, eps=1e-6):
    return "zero_phase" if abs(float(phase_deg)) <= eps else "with_phase"


def write_summary_csv(rows):
    out_csv = OUT_DIR / "sample_index.csv"
    fields = [
        "id", "structure", "family", "variation", "phase_deg", "phase_group",
        "space_profile_mode", "lq_path", "gt_path", "meta_path", "wavelet_field_path", "w_lq_path", "w_gt_path",
    ]
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})
    print(f"[SAVE] sample_index.csv: {out_csv}")

    counts = {
        "total": len(rows),
        "by_structure": dict(Counter(r["structure"] for r in rows)),
        "by_family": dict(Counter(r["family"] for r in rows)),
        "by_phase_group": dict(Counter(r["phase_group"] for r in rows)),
        "by_space_profile_mode": dict(Counter(r["space_profile_mode"] for r in rows)),
    }
    out_json = OUT_DIR / "sample_count.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(counts, f, ensure_ascii=False, indent=2)
    print(f"[SAVE] sample_count.json: {out_json}")
    print(json.dumps(counts, ensure_ascii=False, indent=2))


def copy_sources_for_reproducibility():
    if not COPY_SOURCE_SCRIPTS:
        return
    src_dir = OUT_DIR / "source_scripts"
    src_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(__file__), src_dir / Path(__file__).name)
    for item in SOURCE_SCRIPTS:
        p = SCRIPT_DIR / item["file"]
        if p.exists():
            shutil.copy2(p, src_dir / p.name)


# =========================================================
# 6. 主程序
# =========================================================
def main():
    ensure_dirs()
    copy_sources_for_reproducibility()

    idx = START_INDEX
    rows = []
    rng_global = np.random.default_rng(RANDOM_SEED)

    print(
        f"Start generating Ormsby TIME-SPACE-VARYING BWE dataset: "
        f"{len(SOURCE_SCRIPTS)} structures × {NUM_PER_STRUCTURE} samples, "
        f"same-size {N2}x{N1}, no noise, x_group={X_GROUP}, time_win={TIME_WIN}, time_step={TIME_STEP}."
    )

    for s_i, item in enumerate(SOURCE_SCRIPTS):
        structure = item["name"]
        script_path = SCRIPT_DIR / item["file"]
        GeneratorClass = load_generator_class(script_path, module_name=f"gen_{structure}")
        print(f"\n[STRUCTURE] {structure} from {item['file']}")

        for j in range(NUM_PER_STRUCTURE):
            sample_seed = int(RANDOM_SEED * 100000 + s_i * 10000 + j)
            wavelet_rng = np.random.default_rng(sample_seed + 999)

            # 1) 反射结构
            model = generate_reflectivity(GeneratorClass, seed=sample_seed, n1=N1, n2=N2)

            # 2) Ormsby 时空变子波场
            wavelet_func, meta_w = make_ormsby_timespace_wavelet_model(
                wavelet_rng,
                dt=DT,
                length=WAVELET_LENGTH,
            )

            # 3) 时空变非平稳卷积
            lq, gt, local_records = convolve_time_space_varying(
                model,
                wavelet_func,
                time_win=TIME_WIN,
                time_step=TIME_STEP,
                x_group=X_GROUP,
            )

            # 4) 共享归一化
            lq, gt, shared_scale = normalize_pair_shared(lq, gt, percentile=99.5, scale_floor=1e-6)

            # 5) 代表子波保存
            rep_w_lq, rep_w_gt, rep_metas = collect_representative_wavelets(wavelet_func)

            stem = f"{idx:04d}"
            fname = f"{stem}.dat"
            lq.astype(np.float32).tofile(LQ_DIR / fname)
            gt.astype(np.float32).tofile(GT_DIR / fname)

            # 中心位置代表子波，兼容已有 split 脚本
            center_d = len(REP_DEPTHS) // 2
            center_x = len(REP_XS) // 2
            w_lq_path = WAVELET_DIR / f"{stem}_w_lq.npy"
            w_gt_path = WAVELET_DIR / f"{stem}_w_gt.npy"
            np.save(w_lq_path, rep_w_lq[center_d, center_x].astype(np.float32))
            np.save(w_gt_path, rep_w_gt[center_d, center_x].astype(np.float32))

            wavelet_field_path = WAVELET_DIR / f"{stem}_wavelet_field.npz"
            np.savez_compressed(
                wavelet_field_path,
                rep_xs=np.asarray(REP_XS, dtype=np.float32),
                rep_depths=np.asarray(REP_DEPTHS, dtype=np.float32),
                rep_w_lq=rep_w_lq.astype(np.float32),
                rep_w_gt=rep_w_gt.astype(np.float32),
                band_lq_grid=np.asarray(meta_w["band_lq_grid"], dtype=np.float32),
                band_gt_grid=np.asarray(meta_w["band_gt_grid"], dtype=np.float32),
                phase_grid=np.asarray(meta_w["phase_grid"], dtype=np.float32),
                depth_warp=np.asarray(meta_w.get("depth_warp", []), dtype=np.float32),
                boundary_wave_x=np.asarray(meta_w.get("boundary_wave_x", []), dtype=np.float32),
                x_anchors=np.asarray(meta_w["x_anchors"], dtype=np.float32),
                depth_anchors=np.asarray(meta_w["depth_anchors"], dtype=np.float32),
            )

            meta = dict(meta_w)
            meta.update({
                "id": stem,
                "structure": structure,
                "source_script": item["file"],
                "seed": int(sample_seed),
                "n1": int(N1),
                "n2": int(N2),
                "dt": float(DT),
                "wavelet_length": float(WAVELET_LENGTH),
                "time_win": int(TIME_WIN),
                "time_step": int(TIME_STEP),
                "x_group": int(X_GROUP),
                "representative_xs": [sanitize_float(x) for x in REP_XS],
                "representative_depths": [sanitize_float(d) for d in REP_DEPTHS],
                "shared_scale": sanitize_float(shared_scale),
                "num_local_records": int(len(local_records)),
                "local_records_preview": local_records[:12],
            })

            meta_path = META_DIR / f"{stem}.json"
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)

            # 6) QC
            should_qc = idx < START_INDEX + QC_FIRST_N or (idx - START_INDEX + 1) % QC_EVERY == 0
            if should_qc:
                qc_path = QC_DIR / f"{stem}_qc.png"
                save_qc_figure_timespace_ormsby(lq, gt, rep_w_lq, rep_w_gt, rep_metas, meta, qc_path, dt=DT)

            rows.append({
                "id": stem,
                "structure": structure,
                "family": "ormsby",
                "variation": "time_space",
                "phase_deg": sanitize_float(meta.get("phase_deg", 0.0)),
                "phase_group": phase_group(meta.get("phase_deg", 0.0)),
                "space_profile_mode": meta.get("space_profile_mode", ""),
                "lq_path": str(LQ_DIR / fname),
                "gt_path": str(GT_DIR / fname),
                "meta_path": str(meta_path),
                "wavelet_field_path": str(wavelet_field_path),
                "w_lq_path": str(w_lq_path),
                "w_gt_path": str(w_gt_path),
            })

            if (idx - START_INDEX + 1) % 10 == 0:
                print(f"[{idx - START_INDEX + 1}] done. latest structure={structure}, idx={stem}, profile={meta.get('space_profile_mode')}")

            idx += 1

    write_summary_csv(rows)
    print(f"\nAll done. Dataset saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
