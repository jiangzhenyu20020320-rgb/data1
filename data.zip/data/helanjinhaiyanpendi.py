import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter, map_coordinates, zoom

def downsample_x2(img):
    img_lp = gaussian_filter(img, sigma=0.5)  # 轻微低通，减少混叠
    return zoom(img_lp, zoom=(0.5, 0.5), order=1).astype(np.float32)

def ricker_wavelet(f0=60.0, dt=0.004, length=0.128):
    t = np.arange(-length/2, length/2 + dt, dt, dtype=np.float32)
    a = (np.pi * f0) ** 2
    w = (1.0 - 2.0 * a * t**2) * np.exp(-a * t**2)
    return w.astype(np.float32)
def convolve_along_depth(img, wavelet):
    n2, n1 = img.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))

    IMG = np.fft.rfft(img, n=nfft, axis=1)
    W = np.fft.rfft(wavelet, n=nfft)

    Y = IMG * W[None, :]
    y = np.fft.irfft(Y, n=nfft, axis=1)

    start = (nw - 1) // 2
    return y[:, start:start + n1].astype(np.float32)
def add_offset_noise(
    img,
    rng,
    snr_db=12.0,
    offset_exp=1.8,
    min_scale=0.35,
    max_scale=1.0,
    bandlimit=True,
    fmin=0.02,
    fmax=0.18
):
    n2, n1 = img.shape
    x = img.astype(np.float32)

    sig_rms = np.sqrt(np.mean(x**2) + 1e-12)
    noise_rms = sig_rms / (10.0 ** (snr_db / 20.0))

    i2 = np.arange(n2, dtype=np.float32)
    center = (n2 - 1) / 2.0
    off = np.abs(i2 - center) / (center + 1e-12)
    w = min_scale + (max_scale - min_scale) * (off ** offset_exp)

    noise = rng.standard_normal((n2, n1)).astype(np.float32)
    noise *= (noise_rms * w)[:, None]

    if bandlimit:
        F = np.fft.rfft(noise, axis=1)
        freqs = np.fft.rfftfreq(n1, d=1.0)
        win = np.zeros_like(freqs)
        win[(freqs >= fmin) & (freqs <= fmax)] = 1.0
        F *= win[None, :]
        noise = np.fft.irfft(F, n=n1, axis=1)

    return x + noise

class GeologicalSeismicData:

    def __init__(self, seed=31):
        self.rng = np.random.RandomState(seed)

    def seismic_and_slopes_2d(self, n1=256, n2=512, noise=0):  # 恢复 n2=512 以获得更宽的图像

        # 1. 创建基础反射系数
        reflectivity = self._make_reflectivity_2d(n1, n2)

        # 应用分层褶皱
        lower_params = {'a1': 0, 'b1': 0.013, 'a2': 5e-5, 'b2': 5e-5}  # 低频、高幅
        upper_params = {'a1': 0, 'b1': 0.008, 'a2': 5e-5, 'b2': 5e-5}  # 高频、低幅

        reflectivity = self._apply_sinusoidal_fold_2d_layered(
            reflectivity, n1, n2,
            boundary_i1=n1 // 1.5,
            upper_params=upper_params,
            lower_params=lower_params
        )

        minibasin_params = {
            'sag_center_x2': n2 // 1.3,  # 盆地中心位于图像中央
            'sag_depth': 80.0,  # 最大下沉深度 (像素)
            'sag_width': 50.0,  # 盆地横向宽度
            'i1_start_sag': 0,  # 地层开始下沉的深度
            'i1_end_sag': n1 - 10  # 地层最大下沉的深度
        }
        reflectivity = self._apply_minibasin_sag_2d(reflectivity, n1, n2, **minibasin_params)

        fault_start_detph = 20
        fault_end_detph = n1-1

        zone_params = {
            'zone_width': 8,  # 断层带宽度 (像素)
            'blur_sigma': 0.3,  # 模糊强度
            'attenuation_factor': 0.3  # 振幅衰减 (0.5 = 减弱50%)
        }
        # 4. 应用弯曲的铲状断层 (普通断层，不生长)
        fault1_params = {'x2_ref': 0, 'dip_top': 50, 'dip_bottom': 60, 'throw': 15, 'i1_start': fault_start_detph,
                         'i1_end':  fault_end_detph, 'growth_factor': 1.0}  # 1.0 表示无生长
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault1_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault1_params, **zone_params)

        reflectivity = self._apply_vertical_shear_2d(
            reflectivity, n1, n2,
        )
        # 6. 归一化和添加噪声
        image = reflectivity
        image = image / np.std(image)  # 归一化

        if noise > 0:
            noise_array = self.rng.randn(*image.shape)
            noise_array = gaussian_filter(noise_array, sigma=2.0, order=1)
            noise_array = noise_array * noise * np.std(image) / np.std(noise_array)
            image = image + noise_array

        return image

    def _make_reflectivity_2d(self, n1, n2):
        r = 2.0 * self.rng.rand(n1) - 1.0
        r = np.sign(r) * np.abs(r) ** 5
        reflectivity = np.tile(r[:, np.newaxis], (1, n2)).T
        return reflectivity

    def _apply_vertical_shear_2d(self, data, n1, n2, scale=0.05):

        from scipy.ndimage import map_coordinates

        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        coords = np.array([
            i2.astype(float),  # 横向坐标不变
            np.clip(i1 - scale * i2, 0, n1 - 1)  # 深度坐标剪切并裁剪
        ])

        return map_coordinates(data, coords, order=3, mode='nearest')
    def _apply_geometric_flexure_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, i1_start, i1_end,
                                    flexure_width, max_flexure_depth_shift, **kwargs):
        """
        模拟断层下降盘的几何挠曲/垂向倾斜（逆向拖曳）。
        通过在下降盘靠近断层区域应用深度相关的垂直位移来实现地层向断层弯曲。
        :param flexure_width: 挠曲效应影响的横向宽度。
        :param max_flexure_depth_shift: 挠曲产生的最大垂直位移量。
        """
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 1. 计算断层轨迹 (与位移函数相同)
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        # 2. 确定下降盘 (Downthrown Block)
        if dip_top > 0:
            # 断层向右倾斜，下降盘在右侧 (i2 > fault_x2_trace)。
            is_downthrown = (i2 > fault_x2_trace[np.newaxis, :])
            dist_to_fault = i2 - fault_x2_trace[np.newaxis, :]
            # 挠曲方向：地层需要向下凹陷，靠近断层面。这需要 **向上** 施加垂直位移。
            shift_direction = -1  # 使目标点数据来自更浅的源点 (i1 - shift)
        else:
            # 断层向左倾斜，下降盘在左侧 (i2 < fault_x2_trace)。
            is_downthrown = (i2 < fault_x2_trace[np.newaxis, :])
            dist_to_fault = fault_x2_trace[np.newaxis, :] - i2
            # 挠曲方向：地层需要向下凹陷，靠近断层面。这需要 **向上** 施加垂直位移。
            shift_direction = -1  # 使目标点数据来自更浅的源点 (i1 - shift)


        dist_clamped = np.clip(dist_to_fault, 0, flexure_width)

        # 线性衰减权重 (距离越远越小)
        horizontal_weight = (flexure_width - dist_clamped) / flexure_width

        # 4. 纵向权重 (深度相关)
        # 挠曲从 i1_start 开始，向下加剧
        i1_norm = np.clip((i1 - i1_start) / (i1_end - i1_start + 1e-6), 0, 1)

        # 我们希望挠曲在 i1_start 处为 0，向下加剧 (使用 i1_norm)
        depth_weight = i1_norm

        flexure_shift = (
                max_flexure_depth_shift * horizontal_weight * depth_weight * shift_direction
        )

        # 6. 最终位移遮罩
        flexure_mask = is_downthrown & (dist_to_fault > 0) & (dist_to_fault < flexure_width) & (i1 >= i1_start) & (
                    i1 < i1_end)

        # 7. 应用位移
        src_i1 = i1.astype(float)
        src_i2 = i2.astype(float)


        src_i1[flexure_mask] = np.clip(src_i1[flexure_mask] + flexure_shift[flexure_mask], 0, n1 - 1)

        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_stratigraphic_wedge_2d(self, data, n1, n2, i1_start, i1_end, x2_start, x2_end, direction='left'):

        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 1. 定义深度遮罩
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)

        # 2. 定义尖灭区间和横向距离
        x2_min = min(x2_start, x2_end)
        x2_max = max(x2_start, x2_end)
        x2_width = x2_max - x2_min

        if x2_width <= 0:
            return data

        # 3. 计算横向衰减因子 (Attenuation Factor)

        # 限制 x2 范围在尖灭区 [x2_min, x2_max]
        x2_active = np.clip(i2, x2_min, x2_max)

        if direction == 'left':
            # 衰减因子在 x2_max 处为 1，在 x2_min 处为 0 (从右向左尖灭)
            attenuation_factor = (x2_active - x2_min) / x2_width

        elif direction == 'right':
            # 衰减因子在 x2_min 处为 1，在 x2_max 处为 0 (从左向右尖灭)
            attenuation_factor = 1.0 - (x2_active - x2_min) / x2_width
        else:
            return data

        # 4. 组合遮罩和应用衰减
        wedge_mask = depth_mask & (i2 >= x2_min) & (i2 < x2_max)  # 确保只在目标横向区域内操作

        # 仅在遮罩区域应用衰减
        data[wedge_mask] *= attenuation_factor[wedge_mask]

        return data

    def _apply_minibasin_sag_2d(self, data, n1, n2, sag_center_x2, sag_depth, sag_width, i1_start_sag=0,
                                i1_end_sag=None, **kwargs):

        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        if i1_end_sag is None:
            i1_end_sag = n1

        # 1. 深度权重 (线性 ramp，从 0 增加到 1)
        # 确保只在有效深度范围 [i1_start_sag, i1_end_sag] 内有位移
        n1_effective = i1_end_sag - i1_start_sag
        if n1_effective <= 0:
            return data

        # i1_norm 在 i1_start_sag 处为 0，在 i1_end_sag 处为 1
        i1_norm = np.clip((i1 - i1_start_sag) / (n1_effective + 1e-6), 0, 1)
        depth_weight = i1_norm  # 越深，下沉量越大

        # 2. 横向形状 (Gaussian Trough)
        # Shift 在 sag_center_x2 处最大，向两侧衰减
        horizontal_shape = np.exp(-((i2 - sag_center_x2) ** 2) / (2 * sag_width ** 2))

        # 3. 最终位移 (向下位移，所以是正值 sag_shift)
        sag_shift = sag_depth * horizontal_shape * depth_weight

        # 4. 应用位移 (为了让地层向下弯曲，目标点的数据需要来自更浅的源点 i1 - sag_shift)
        src_i1 = np.clip(i1 - sag_shift, 0, n1 - 1)
        src_i2 = i2.astype(float)

        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')
    def _apply_sinusoidal_fold_2d_layered(self, data, n1, n2, boundary_i1, upper_params, lower_params):

        i1_range, i2_range = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        shift = np.zeros_like(i1_range, dtype=float)

        # 上层遮罩
        mask_upper = (i1_range < boundary_i1)
        up = upper_params
        shift[mask_upper] = (up['a1'] + up['b1'] * i1_range[mask_upper]) * \
                            np.sin((up['a2'] + up['b2'] * i2_range[mask_upper]) * i2_range[mask_upper])

        # 下层遮罩
        mask_lower = (i1_range >= boundary_i1)
        low = lower_params
        shift[mask_lower] = (low['a1'] + low['b1'] * i1_range[mask_lower]) * \
                            np.sin((low['a2'] + low['b2'] * i2_range[mask_lower]) * i2_range[mask_lower])

        # 应用位移
        x1_new = i1_range - shift

        coords = np.zeros((2, n2, n1))
        coords[0, :, :] = i2_range
        coords[1, :, :] = np.clip(x1_new, 0, n1 - 1)

        return map_coordinates(data, coords.reshape(2, n2, n1), order=3, mode='nearest')


    def _apply_salt_dome_2d(self, data, n1, n2, dome_center_x2, dome_height, dome_width, i1_start_lift=0,
                            i1_end_lift=None):

        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 如果未指定结束深度，则默认为模型底部
        if i1_end_lift is None:
            i1_end_lift = n1

        # 1. 定义有效深度范围
        n1_effective = i1_end_lift - i1_start_lift
        if n1_effective <= 0:
            return data

        # 2. 计算相对于起始深度的偏移
        i1_offset = np.maximum(0, i1 - i1_start_lift)

        # 3. 归一化到 [0, 1] 范围 (只考虑有效范围 D)
        i1_norm_raw = i1_offset / n1_effective

        # 4. 截断归一化深度：确保 x 在 [0, 1] 范围内
        i1_norm_clamped = np.clip(i1_norm_raw, 0, 1)

        uplift_scale = 4 * i1_norm_clamped * (1 - i1_norm_clamped)

        # 6. 计算最终位移
        shift = dome_height * np.exp(-((i2 - dome_center_x2) ** 2) / (2 * dome_width ** 2)) * uplift_scale

        # 源坐标
        src_i1 = np.clip(i1 + shift, 0, n1 - 1)
        src_i2 = i2.astype(float)

        coords = np.array([src_i2, src_i1])

        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_curved_normal_fault_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, throw, i1_start, i1_end,
                                      growth_factor=1.0):

        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([i2.astype(float), i1.astype(float)])

        # 1. 计算断层轨迹 (保持不变)
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        # 2. 侧向遮罩 (Side Mask) - 确定下降盘
        if dip_top > 0:
            # 倾角为正 (>0) 意味着断层向右倾斜，右侧是下降盘
            downthrown_mask = (i2 > fault_x2_trace[np.newaxis, :])
            # 上升盘在左侧
        else:
            # 倾角为负 (<0) 意味着断层向左倾斜，左侧是下降盘
            downthrown_mask = (i2 < fault_x2_trace[np.newaxis, :])
            # 上升盘在右侧

        # 3. 深度遮罩 (Depth Mask) - 确定活动/生长地层范围
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)

        # 4. 最终位移遮罩
        fault_mask = downthrown_mask & depth_mask

        # 5. 应用位移和生长效应

        # 使用基于 i1_start 的拉伸位移
        i1_offset_from_start = coords[1][fault_mask] - i1_start

        # 生长引起的额外位移 (拉伸)
        growth_displacement = i1_offset_from_start * (growth_factor - 1.0)

        # 总位移：(断层落差) + (生长拉伸)
        total_displacement = throw + growth_displacement

        src_i1 = coords[1][fault_mask] - total_displacement

        coords[1][fault_mask] = np.clip(src_i1, 0, n1 - 1)

        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_fault_zone_attenuation_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom,zone_width, blur_sigma, attenuation_factor, i1_start, i1_end, **kwargs):

        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 1. 计算断层轨迹 (与位移函数相同)
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        # 2. 距离遮罩 (Proximity Mask)
        fault_x2_trace_grid = fault_x2_trace[np.newaxis, :]
        dist_to_fault = np.abs(i2 - fault_x2_trace_grid)
        zone_mask_proximity = (dist_to_fault <= zone_width / 2.0)

        # 3. 深度遮罩 (Depth Mask)
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)

        # 4. 最终衰减遮罩
        zone_mask = zone_mask_proximity & depth_mask

        if np.any(zone_mask):
            # 应用模糊和衰减
            blurred_data = gaussian_filter(data, sigma=blur_sigma)
            data[zone_mask] = blurred_data[zone_mask]
            data[zone_mask] *= attenuation_factor
        return data


# --- 绘图函数 (保持不变) ---
def plot_2d_result(image):
    """(原代码) 绘图函数"""
    fig, axes = plt.subplots(1, 1, figsize=(9, 7))
    # 图像现在可以更宽 (n2=512)
    axes.imshow(image.T, cmap='gray', aspect='auto', origin='upper')
    axes.set_title('Seismic Image (Geological Model - No Convolution)')
    axes.set_xlabel('X2')
    axes.set_ylabel('X1 (Depth)')
    plt.tight_layout()
    plt.show()

# Example usage
# --- 批量生成部分（替换原来的 main 函数） ---
if __name__ == "__main__":
    import os
    import numpy as np

    # ===== 配置 =====
    NUM_MODELS = 300        # 生成多少对
    n1, n2 = 512, 512
    dt = 0.004

    CLEAN_DIR = "dataset3001-30hz/clean"
    NOISY_DIR = "dataset3001-20hz/noisy"
    os.makedirs(CLEAN_DIR, exist_ok=True)
    os.makedirs(NOISY_DIR, exist_ok=True)

    # 子波（零相位）
    w45 = ricker_wavelet(f0=30.0, dt=dt)   # clean
    w20 = ricker_wavelet(f0=20.0, dt=dt)   # noisy

    idx = 3001
    print("Start generating 256x256 clean/noisy pairs...")

    for i in range(NUM_MODELS):
        seed = 1000 + i
        generator = GeologicalSeismicData(seed=seed)

        # 1️⃣ 直接生成 256×256 反射系数模型
        model = generator.seismic_and_slopes_2d(
            n1=n1,
            n2=n2,
            noise=0
        )

        # 2️⃣ clean：60 Hz 卷积（无噪）
        clean = convolve_along_depth(model, w45)
        clean -= np.mean(clean)
        clean /= (np.std(clean) + 1e-12)

        # 3️⃣ noisy：20 Hz 卷积 + 噪声
        base = convolve_along_depth(model, w20)
        base -= np.mean(base)
        base /= (np.std(base) + 1e-12)

        noisy512 = add_offset_noise(
            base,
            rng=np.random.default_rng(2025 + idx),
            snr_db=12.0,
            offset_exp=1.8,
            min_scale=0.35,
            max_scale=1.0,
            bandlimit=True
        ).astype(np.float32)

        noisy256 = downsample_x2(noisy512)

        # 4️⃣ 保存
        fname = f"{idx:04d}.dat"
        clean.astype(np.float32).tofile(os.path.join(CLEAN_DIR, fname))
        noisy256.astype(np.float32).tofile(os.path.join(NOISY_DIR, fname))
        idx += 1

        if (i + 1) % 50 == 0:
            print(f"[{i+1}/{NUM_MODELS}] pairs generated")

    print("All done.")
