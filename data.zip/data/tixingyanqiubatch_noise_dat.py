import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter, map_coordinates, zoom

def downsample_x2(img):
    img_lp = gaussian_filter(img, sigma=0.5)  # 可选低通
    return zoom(img_lp, zoom=(0.5, 0.5), order=1).astype(np.float32)

def ricker_wavelet(f0=60.0, dt=0.004, length=0.256):
    t = np.arange(-length/2, length/2 + dt, dt, dtype=np.float32)
    pi2f2 = (np.pi * f0) ** 2
    w = (1.0 - 2.0 * pi2f2 * t**2) * np.exp(-pi2f2 * t**2)
    return w
def convolve_with_wavelet(img, wavelet):
    """
    img: (n2, n1)
    wavelet: (nw,)
    """
    n2, n1 = img.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))

    IMG = np.fft.rfft(img, n=nfft, axis=1)
    W = np.fft.rfft(wavelet, n=nfft)

    Y = IMG * W[None, :]
    y = np.fft.irfft(Y, n=nfft, axis=1)

    start = (nw - 1) // 2
    return y[:, start:start + n1].astype(np.float32)


def add_offset_dependent_noise(
    img,
    rng,
    snr_db=15.0,          # 越大越干净；越小噪声越强（典型 5~25dB）
    offset_exp=1.5,       # 噪声随偏移增长的指数（1~3）
    min_scale=0.4,        # 最小偏移处噪声比例（0~1）
    max_scale=1.0,        # 最大偏移处噪声比例（>=min_scale）
    bandlimit=True,       # 是否带限成“地震噪声”
    fmin=0.02, fmax=0.25  # 归一化频率（相对Nyquist）；不懂就用默认
):
    """
    img: shape (n2, n1)   # 你的剖面：x2在第0维，深度在第1维
    snr_db: 控制整体噪声强弱
    噪声模型：noise_std(i2) 随偏移增大而增大
    可选 bandlimit：让噪声沿深度方向更像地震噪声（带限）
    """
    n2, n1 = img.shape
    x = img.astype(np.float32)

    # 1) 用 SNR(dB) 计算总体噪声标准差（以 RMS 为基准）
    sig_rms = np.sqrt(np.mean(x**2) + 1e-12)
    noise_rms = sig_rms / (10.0**(snr_db / 20.0))   # SNR = 20log10(sig/noise)
    # 2) 构造“偏移权重”：中心偏移小、两侧偏移大（你可按需要改成单边）
    i2 = np.arange(n2, dtype=np.float32)
    center = (n2 - 1) / 2.0
    off = np.abs(i2 - center) / (center + 1e-12)    # 0~1
    w = min_scale + (max_scale - min_scale) * (off**offset_exp)  # 0~1(或更大)

    # 3) 生成噪声（每条道不同强度）
    noise = rng.standard_normal((n2, n1)).astype(np.float32)
    noise *= (noise_rms * w)[:, None]

    # 4) 可选：带限（沿深度轴做简单频域窗）
    if bandlimit:
        F = np.fft.rfft(noise, axis=1)
        freqs = np.fft.rfftfreq(n1, d=1.0)  # 归一化频率 0~0.5
        # 简单余弦过渡带通窗
        win = np.zeros_like(freqs, dtype=np.float32)

        # 过渡宽度
        tw = 0.02
        f1, f2 = max(fmin - tw, 0.0), fmin
        f3, f4 = fmax, min(fmax + tw, 0.5)

        # 低端上升
        m = (freqs >= f1) & (freqs < f2)
        if np.any(m):
            t = (freqs[m] - f1) / (f2 - f1 + 1e-12)
            win[m] = 0.5 - 0.5 * np.cos(np.pi * t)
        # 通带
        win[(freqs >= f2) & (freqs <= f3)] = 1.0
        # 高端下降
        m = (freqs > f3) & (freqs <= f4)
        if np.any(m):
            t = (freqs[m] - f3) / (f4 - f3 + 1e-12)
            win[m] = 0.5 + 0.5 * np.cos(np.pi * t)

        F *= win[None, :]
        noise = np.fft.irfft(F, n=n1, axis=1).astype(np.float32)

    return x + noise

class GeologicalSeismicData:

    def __init__(self, seed=31):
        self.rng = np.random.RandomState(seed)

    def seismic_and_slopes_2d(self, n1=256, n2=256, noise=0):

        # 1. 创建基础反射系数 (来自您的代码)
        reflectivity = self._make_reflectivity_2d(n1, n2)
        lower_params = {'a1': 0, 'b1': 0.013, 'a2': 5e-5, 'b2': 5e-5}  # 低频、高幅
        upper_params = {'a1': 0, 'b1': 0.008, 'a2': 5e-5, 'b2': 5e-5}  # 高频、低幅

        reflectivity = self._apply_sinusoidal_fold_2d_layered(
            reflectivity, n1, n2,
            boundary_i1=n1 // 1.5,
            upper_params=upper_params,
            lower_params=lower_params
        )

        fault_start_detph = 190
        fault_end_detph = 260

        zone_params = {
            'zone_width': 9.5,  # 断层带宽度 (像素)
            'blur_sigma': 0.5,  # 模糊强度
            'attenuation_factor': 0.8  # 振幅衰减 (0.5 = 减弱50%)
        }

        # --- 断层 3 (右侧) ---
        fault3_params = {'x2_ref': 120, 'dip_top': 90, 'dip_bottom': 45, 'throw': 30,'i1_start': fault_start_detph,'i1_end': n1}
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault3_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault3_params, **zone_params)
        dome_center = n2 // 1.8
        reflectivity = self._apply_sharp_salt_dome_2d(
            reflectivity,
            n1, n2,
            dome_center_x2=dome_center,
            dome_height=70,  # 上拱 80 个采样点，可再调
            dome_half_width=80,  # 半宽 35 像素，越小越尖
            i1_start_lift=10,  # 从这个深度开始抬
            i1_end_lift=600,  # 到这个深度结束
            sharpness_h=4,  # 水平边界陡一点
            sharpness_v=3  # 垂向集中一点
        )
        reflectivity = self._apply_vertical_shear_2d(
            reflectivity, n1, n2,
        )


        # 6. 归一化和添加噪声
        # 图像现在直接是变形后的反射系数
        image = reflectivity
        image = image / np.std(image)  # 归一化

        if noise > 0:
            noise_array = self.rng.randn(*image.shape)
            noise_array = gaussian_filter(noise_array, sigma=2.0, order=1)
            noise_array = noise_array * noise * np.std(image) / np.std(noise_array)
            image = image + noise_array

        return image

    def _make_reflectivity_2d(self, n1, n2):
        # 1. 生成基础随机序列
        r = 2.0 * self.rng.rand(n1) - 1.0
        p=1.5
        # 2. 创建动态门槛向量 (随深度变化)
        # 上半部分门槛高 (如 0.9，留下的层少，稀疏)
        # 下半部分门槛低 (如 0.4，留下的层多，密集)
        depth_axis = np.linspace(0, 1, n1) ** p

        # 使用线性插值控制：从 0.92 (顶部) 降到 0.6 (底部)
        # 您可以调整这两个数值来改变疏密对比度
        threshold_vec = 0.96 - (0.96 - 0.60) * depth_axis

        # 3. 应用动态门槛
        # 只有当随机数的绝对值大于该深度对应的门槛时，才保留
        mask = np.abs(r) > threshold_vec
        r_sparse = np.zeros_like(r)
        r_sparse[mask] = r[mask]

        # 4. 增强对比度并保持符号
        # 使用较大的幂次可以进一步让背景更干净
        r_final = np.sign(r_sparse) * np.abs(r_sparse) ** 3

        # 5. 扩展为二维
        reflectivity = np.tile(r_final[:, np.newaxis], (1, n2)).T
        return reflectivity

    def _apply_sharp_salt_dome_2d(self, data, n1, n2,
                                  dome_center_x2,
                                  dome_height,
                                  dome_half_width,
                                  i1_start_lift=0,
                                  i1_end_lift=None,
                                  sharpness_h=4,
                                  sharpness_v=3):
        """
        尖锐盐丘几何变换（让盐丘边界更陡）。

        dome_center_x2 : 盐丘中心位置 (x2 index)
        dome_height    : 最大上拱高度 (正值=向上拱起)
        dome_half_width: 半宽，越小越“瘦高”
        sharpness_h    : 水平“尖锐度”，>1 时边缘更陡
        sharpness_v    : 垂向“尖锐度”，>1 时上拱集中在中上部
        """
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        if i1_end_lift is None:
            i1_end_lift = n1

        # 1. 垂向权重：只在 i1_start_lift ~ i1_end_lift 之间上拱
        n1_eff = max(i1_end_lift - i1_start_lift, 1)
        i1_norm = np.clip((i1 - i1_start_lift) / float(n1_eff), 0.0, 1.0)

        # 原来是一个“帽形” 4x(1-x)，我们让它更尖一些
        base_v = 4.0 * i1_norm * (1.0 - i1_norm)  # 0~1 的拱形
        depth_weight = base_v ** sharpness_v  # 指数 >1 就更尖

        # 2. 水平形状：用 super-Gaussian，让两侧收得更快
        x_norm = (i2 - dome_center_x2) / float(dome_half_width)
        # super-Gaussian：指数越大越“瘦高”
        horizontal_shape = np.exp(-(x_norm ** (2 * sharpness_h)))

        # 3. 最终位移 (正值=向上拱起，因此源点从更深处取数据)
        shift = dome_height * horizontal_shape * depth_weight

        # 4. 应用位移
        src_i1 = np.clip(i1 + shift, 0, n1 - 1)  # data 从更深的位置“抬上来”
        src_i2 = i2.astype(float)

        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_sinusoidal_fold_2d_layered(self, data, n1, n2, boundary_i1, upper_params, lower_params):
        """
        新函数：应用分层褶皱
        在 boundary_i1 上下使用不同的褶皱参数
        """
        i1_range, i2_range = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        shift = np.zeros_like(i1_range, dtype=float)

        # 上层遮罩
        mask_upper = (i1_range < boundary_i1)
        up = upper_params
        shift[mask_upper] = (up['a1'] + up['b1'] * i1_range[mask_upper]) * \
                            np.sin((up['a2'] + up['b2'] * i2_range[mask_upper]) * i2_range[mask_upper])

        # 下层遮罩
        mask_lower = (i1_range >= boundary_i1)
        low = lower_params
        shift[mask_lower] = (low['a1'] + low['b1'] * i1_range[mask_lower]) * \
                            np.sin((low['a2'] + low['b2'] * i2_range[mask_lower]) * i2_range[mask_lower])

        # 应用位移
        x1_new = i1_range - shift

        coords = np.zeros((2, n2, n1))
        coords[0, :, :] = i2_range
        coords[1, :, :] = np.clip(x1_new, 0, n1 - 1)

        return map_coordinates(data, coords.reshape(2, n2, n1), order=3, mode='nearest')

    def _apply_unconformity_2d(self, data, n1, n2, erosion_height, erosion_width, new_sediment_r_val, i1_max_depth):
        """
        模拟角度不整合面。
        :param erosion_height: 侵蚀面波动的幅度。
        :param erosion_width: 侵蚀面波动的波长。
        :param new_sediment_r_val: 上覆新地层的反射系数 (例如，设置为0或小的随机值)。
        :param i1_max_depth: 不整合面可以到达的最大深度 (例如 i1=100)。
        """
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 1. 定义侵蚀面轨迹 I(x2)
        # 基础深度 (例如 n1/3)
        base_depth = i1_max_depth

        # 波动 (例如，一个慢速的正弦波，使其弯曲)
        # (n2 / erosion_width) 控制周期数
        wave = erosion_height * np.sin(2 * np.pi * i2 / erosion_width)

        # 最终侵蚀面深度（垂直于 x2 方向的数组）
        erosion_surface_i1 = (base_depth + wave).astype(int)

        # 2. 创建一个遮罩来标识上覆地层区域
        # 将 erosion_surface_i1 扩展到 (n2, n1) 形状
        surface_grid = erosion_surface_i1[np.newaxis, :]

        # 上覆地层区域的遮罩: i1 坐标小于侵蚀面深度的地方
        upper_mask = i1 < surface_grid

        # 3. 截断/覆盖下伏地层 (即 data[upper_mask])

        # 方法 A: 用平坦的（水平的）新反射系数覆盖。
        # 创建一个随机的、低幅度的水平反射系数作为上覆新地层
        if new_sediment_r_val == 'flat':
            # 创建新的、平坦的反射系数 (例如，r 随深度变化，但没有横向变化)
            r_new = self.rng.rand(n1) * 0.3  # 0.3 是振幅因子
            # 铺设一个新的、平坦的反射系数层 (n2 x n1)
            new_reflectivity = np.tile(r_new[:, np.newaxis], (1, n2)).T

            # 仅在 upper_mask 区域使用新的反射系数
            data[upper_mask] = new_reflectivity[upper_mask]

        # 方法 B: 简单地将该区域设为零（空白/低反射）
        elif new_sediment_r_val == 'blank':
            data[upper_mask] = 0.0

        return data

    def _apply_salt_dome_2d(self, data, n1, n2, dome_center_x2, dome_height, dome_width, i1_start_lift=0,
                            i1_end_lift=None):
        """
        模拟盐丘的上拱 (Drape)
        修正：隆起精确地限制在 [i1_start_lift, i1_end_lift] 深度范围内。
        """
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 如果未指定结束深度，则默认为模型底部
        if i1_end_lift is None:
            i1_end_lift = n1

        # 1. 定义有效深度范围
        n1_effective = i1_end_lift - i1_start_lift
        if n1_effective <= 0:
            return data

        # 2. 计算相对于起始深度的偏移
        i1_offset = np.maximum(0, i1 - i1_start_lift)

        # 3. 归一化到 [0, 1] 范围 (只考虑有效范围 D)
        i1_norm_raw = i1_offset / n1_effective

        # 4. 截断归一化深度：确保 x 在 [0, 1] 范围内
        i1_norm_clamped = np.clip(i1_norm_raw, 0, 1)

        # 5. 使用抛物线形状的权重: x * (1 - x)。
        # 当 i1 < i1_start_lift 时, x=0, Weight=0。
        # 当 i1 >= i1_end_lift 时, x=1, Weight=0。
        uplift_scale = 4 * i1_norm_clamped * (1 - i1_norm_clamped)

        # 6. 计算最终位移
        shift = dome_height * np.exp(-((i2 - dome_center_x2) ** 2) / (2 * dome_width ** 2)) * uplift_scale

        # 源坐标
        src_i1 = np.clip(i1 + shift, 0, n1 - 1)
        src_i2 = i2.astype(float)

        coords = np.array([src_i2, src_i1])

        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_curved_normal_fault_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, throw, i1_start,i1_end):
        """
        新函数：模拟弯曲的正断层 (铲状断层)
        - dip_top: 顶部的倾角 (度)
        - dip_bottom: 底部的倾角 (度)
        """
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([i2.astype(float), i1.astype(float)])

        # 1. 计算断层轨迹
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        # 2. 侧向遮罩 (Side Mask)
        if dip_top > 0:
            side_mask = (i2 > fault_x2_trace[np.newaxis, :])
        else:
            side_mask = (i2 < fault_x2_trace[np.newaxis, :])

        # 3. 深度遮罩 (Depth Mask)
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)

        # 4. 最终位移遮罩
        fault_mask = side_mask & depth_mask

        # 5. 应用位移
        src_i1 = coords[1][fault_mask] - throw
        coords[1][fault_mask] = np.clip(src_i1, 0, n1 - 1)
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_vertical_shear_2d(self, data, n1, n2, scale=0.05):

        from scipy.ndimage import map_coordinates

        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        coords = np.array([
            i2.astype(float),  # 横向坐标不变
            np.clip(i1 - scale * i2, 0, n1 - 1)  # 深度坐标剪切并裁剪
        ])

        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_fault_zone_attenuation_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom,
                                         zone_width, blur_sigma, attenuation_factor, i1_start,i1_end,**kwargs):
        """
        新函数：在断层路径周围应用模糊和振幅衰减
        """
        # 1. 重新计算断层路径 (与 _apply_curved_normal_fault_2d 中的几何计算完全相同)
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 1. 计算断层轨迹 (与位移函数相同)
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        # 2. 距离遮罩 (Proximity Mask)
        fault_x2_trace_grid = fault_x2_trace[np.newaxis, :]
        dist_to_fault = np.abs(i2 - fault_x2_trace_grid)
        zone_mask_proximity = (dist_to_fault <= zone_width / 2.0)

        # 3. 深度遮罩 (Depth Mask)
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)

        # 4. 最终衰减遮罩
        zone_mask = zone_mask_proximity & depth_mask

        if np.any(zone_mask):
            # 应用模糊和衰减
            blurred_data = gaussian_filter(data, sigma=blur_sigma)
            data[zone_mask] = blurred_data[zone_mask]
            data[zone_mask] *= attenuation_factor
        return data

def plot_2d_result(image):
    """(原代码) 绘图函数"""
    fig, axes = plt.subplots(1, 1, figsize=(12, 12))
    axes.imshow(image.T, cmap='gray', aspect='auto', origin='upper')
    axes.set_title('Seismic Image (Geological Model - No Convolution)')
    axes.set_xlabel('X2')
    axes.set_ylabel('X1 (Depth)')
    plt.tight_layout()
    plt.show()

def batch_generate(
            generator,
            n_images=20,
            n1=256,
            n2=256,
            noise_level_range=(0.0, 0.3),
            salt_count_range=(0, 3),
            fault_count_range=(0, 3),
            random_seed=1234,
            save_dir=None
    ):
        """
        批量生成地震模型（未卷积版本）。
        可生成 N 张图，每张图结构完全随机。

        generator: GeologicalSeismicData 实例
        n_images: 生成多少张
        n1, n2: 尺寸
        noise_level_range: 噪声强度范围
        salt_count_range: 随机盐丘数量范围
        fault_count_range: 随机断层数量范围
        save_dir: 若不为空，将保存为 PNG
        """

        rng = np.random.RandomState(random_seed)

        images = []

        for i in range(n_images):

            # ---- 随机选择盐丘数量 ----
            salt_count = rng.randint(salt_count_range[0], salt_count_range[1] + 1)

            # ---- 随机选择断层数量 ----
            fault_count = rng.randint(fault_count_range[0], fault_count_range[1] + 1)

            # ---- 随机噪声强度 ----
            noise_level = rng.uniform(noise_level_range[0], noise_level_range[1])

            # ---- 让你的模型每次随机不同结构 ----
            generator.rng = np.random.RandomState(rng.randint(0, 999999))

            # ---- 获取原始 reflectivity（无卷积地震图） ----
            img = generator.seismic_and_slopes_2d(
                n1=n1,
                n2=n2,
                noise=noise_level
            )

            images.append(img)

            # ---- 可选保存 ----
            if save_dir is not None:
                import os
                os.makedirs(save_dir, exist_ok=True)

                fig, ax = plt.subplots(figsize=(10, 10))

                ax.imshow(img.T, cmap='gray', aspect='auto', origin='upper')
                ax.set_title(f"Seismic Image #{i + 1} (seed={generator.rng.randint(10000)})")
                ax.set_xlabel("X2")
                ax.set_ylabel("X1 (depth)")

                # 设置刻度可以更科学
                ax.set_xticks(np.linspace(0, n2, 6))
                ax.set_yticks(np.linspace(0, n1, 6))

                fig.tight_layout()
                fig.savefig(f"{save_dir}/img_{i:04d}.png", dpi=150)
                plt.close(fig)

        return np.array(images)
# Example usage
if __name__ == "__main__":

    generator = GeologicalSeismicData(seed=31)

    out_clean = "dataset501-30hz/clean"
    out_noisy = "dataset501-20hz/noisy"
    os.makedirs(out_clean, exist_ok=True)
    os.makedirs(out_noisy, exist_ok=True)

    rng = np.random.default_rng(2025)
    idx = 501

    # === 子波参数 ===
    dt = 0.004
    w60 = ricker_wavelet(f0=30, dt=dt)
    w20 = ricker_wavelet(f0=20, dt=dt)

    for i in range(500):
        # 1) 生成一张 512×512 反射系数模型
        model = generator.seismic_and_slopes_2d(
            n1=512,
            n2=512,
            noise=0.0
        )

        # 2) clean：30 Hz 卷积（无噪），保持 512×512
        clean = convolve_with_wavelet(model, w60)
        clean /= (np.std(clean) + 1e-6)

        # 3) noisy512：20 Hz 卷积 + 偏移噪声（先在512上做）
        base_20 = convolve_with_wavelet(model, w20)
        base_20 /= (np.std(base_20) + 1e-6)

        noisy512 = add_offset_dependent_noise(
            base_20,
            rng=rng,
            snr_db=8.0,
            offset_exp=1.5,
            min_scale=0.4,
            max_scale=1.0,
            bandlimit=True
        ).astype(np.float32)

        # 4) noisy256：下采样
        noisy256 = downsample_x2(noisy512)

        # 5) 保存：clean(512) / noisy(256) 同名配对
        fname = f"{idx:04d}.dat"
        clean.astype(np.float32).tofile(os.path.join(out_clean, fname))
        noisy256.astype(np.float32).tofile(os.path.join(out_noisy, fname))
        idx += 1

    print("Done!")


