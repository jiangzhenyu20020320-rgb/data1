import os
from scipy.signal import hilbert
import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter, map_coordinates, zoom
def ricker_wavelet_with_phase(frequency=25, phase_deg=0, dt=0.004, length=0.256, return_t=True):
    """
    生成带相位(常相位旋转)的 Ricker 子波
    w_phase = cos(phi)*w - sin(phi)*Hilbert(w)
    """
    t = np.arange(-length / 2, length / 2, dt)

    # 1) 零相位 Ricker
    w0 = (1 - 2 * (np.pi ** 2) * (frequency ** 2) * (t ** 2)) * \
         np.exp(-(np.pi ** 2) * (frequency ** 2) * (t ** 2))

    # 2) Hilbert 变换得到 90° 分量
    w_h = np.imag(hilbert(w0))

    # 3) 常相位旋转
    phi = np.deg2rad(phase_deg)
    w_phase = np.cos(phi) * w0 - np.sin(phi) * w_h
    print("dt used:", dt, "nt:", len(t))

    if return_t:
        return t, w_phase
    return w_phase

def add_offset_noise(img, rng, snr_db=15.0,
                     offset_exp=1.8, min_scale=0.4, max_scale=1.0,
                     bandlimit=True, fmin=0.02, fmax=0.25):
    """
    偏移剖面噪声（offset-dependent noise）
    img: (n2, n1)  # 你的图像：X2在第0维，深度在第1维
    snr_db: 控制噪声强弱（典型 8~25dB；越小噪声越强）
    offset_exp/min_scale/max_scale: 控制“远偏移更吵”的程度
    bandlimit: True 时把噪声带限成更像地震噪声的形态
    """
    n2, n1 = img.shape
    x = img.astype(np.float32)

    # 用全图 RMS 定一个总噪声水平（由 snr_db 控制）
    sig_rms = np.sqrt(np.mean(x**2) + 1e-12)
    noise_rms = sig_rms / (10.0 ** (snr_db / 20.0))

    # 以中心道为近偏移，向两侧偏移增大（0~1）
    i2 = np.arange(n2, dtype=np.float32)
    center = (n2 - 1) / 2.0
    off = np.abs(i2 - center) / (center + 1e-12)

    # 每条道噪声标准差权重：近偏移小，远偏移大
    w = min_scale + (max_scale - min_scale) * (off ** offset_exp)

    # 生成噪声并按道加权
    noise = rng.standard_normal((n2, n1)).astype(np.float32)
    noise *= (noise_rms * w)[:, None]

    # 可选：沿深度方向带限（让噪声更像地震噪声，不那么“像素白噪声”）
    if bandlimit:
        F = np.fft.rfft(noise, axis=1)
        freqs = np.fft.rfftfreq(n1, d=1.0)  # 归一化频率 0~0.5
        win = np.zeros_like(freqs, dtype=np.float32)

        tw = 0.02  # 过渡带宽
        f1, f2 = max(fmin - tw, 0.0), fmin
        f3, f4 = fmax, min(fmax + tw, 0.5)

        m = (freqs >= f1) & (freqs < f2)
        if np.any(m):
            t = (freqs[m] - f1) / (f2 - f1 + 1e-12)
            win[m] = 0.5 - 0.5 * np.cos(np.pi * t)
        win[(freqs >= f2) & (freqs <= f3)] = 1.0
        m = (freqs > f3) & (freqs <= f4)
        if np.any(m):
            t = (freqs[m] - f3) / (f4 - f3 + 1e-12)
            win[m] = 0.5 + 0.5 * np.cos(np.pi * t)

        F *= win[None, :]
        noise = np.fft.irfft(F, n=n1, axis=1).astype(np.float32)

    return x + noise





class GeologicalSeismicData:

    def __init__(self, seed=31):
        self.rng = np.random.RandomState(seed)

    def generate_plausible_parameters(self, n1, n2):
        """
        (新) 批量生成符合地质逻辑的参数。

        基本逻辑：
        1. 定义一个主要的盐丘构造。
        2. 定义一个主要的生长断层（可能与盐丘有关，也可能独立）。
        3. 定义一个主要的裂谷大断层（带拖曳效应）。
        4. 定义次要的尖灭和剪切。
        """
        params = {}

        # --- 1. 分层褶皱 ---
        params['folding'] = {
            'boundary_i1': n1 // self.rng.uniform(2.5, 4.5),  # 褶皱边界深度
            'lower_amp': self.rng.uniform(0.02, 0.04),  # 深层褶皱幅度
            'lower_freq_b': self.rng.uniform(4e-5, 6e-5),  # 深层褶皱频率
            'upper_amp': self.rng.uniform(0.005, 0.015),  # 浅层褶皱幅度
            'upper_freq_b': self.rng.uniform(7e-4, 9e-4)  # 浅层褶皱频率
        }

        # --- 2. 地层尖灭 ---
        # (保持在右侧，模拟盆地边缘)
        wedge_width = self.rng.uniform(50, 100)
        params['wedge'] = {
            'i1_start': self.rng.uniform(n1 * 0.7, n1 * 0.8),  # 尖灭深度
            'i1_end': self.rng.uniform(n1 * 0.85, n1 * 0.95),
            'x2_start': n2,  # 从右边缘开始
            'x2_end': n2 - wedge_width,  # 尖灭宽度
            'direction': 'right'
        }

        # --- 3. 盐丘 ---
        params['salt_dome'] = {
            'dome_center_x2': self.rng.uniform(n2 * 0.15, n2 * 0.3),  # 盐丘中心 (在左侧)
            'dome_height': self.rng.uniform(30, 50),
            'dome_width': self.rng.uniform(40, 60),
            'i1_start_lift': self.rng.uniform(40, 60),  # 隆起起始深度
            'i1_end_lift': self.rng.uniform(180, 220)  # 隆起结束深度
        }

        # --- 4. 断层 ---
        fault_start_depth = self.rng.uniform(10, 30)
        fault_end_depth = self.rng.uniform(180, 220)

        # 4a. 断层 1 (普通断层，在模型中间)
        params['fault1'] = {
            'x2_ref': self.rng.uniform(n2 * 0.45, n2 * 0.55),
            'dip_top': self.rng.uniform(-60, -40),
            'dip_bottom': self.rng.uniform(20, 40),
            'throw': self.rng.uniform(10, 20),
            'i1_start': fault_start_depth,
            'i1_end': fault_end_depth,
            'growth_factor': 1.0  # 无生长
        }

        # 4b. 断层 2 (生长断层, 靠近盐丘，模拟盐丘相关的塌陷)
        # 逻辑：位置在盐丘的右侧
        salt_right_edge = params['salt_dome']['dome_center_x2'] + params['salt_dome']['dome_width']
        params['fault2'] = {
            'x2_ref': salt_right_edge + self.rng.uniform(40, 80),
            'dip_top': self.rng.uniform(-60, -40),  # 倾向盐丘
            'dip_bottom': self.rng.uniform(10, 20),
            'throw': self.rng.uniform(10, 15),
            'i1_start': fault_start_depth,
            'i1_end': fault_end_depth,
            'growth_factor': self.rng.uniform(1.15, 1.30)  # 有生长
        }

        # 4c. 断层 3 (大型裂谷断层，带拖曳效应，在模型右侧)
        params['fault3'] = {
            'x2_ref': self.rng.uniform(n2 * 0.8, n2 * 0.9),
            'dip_top': self.rng.uniform(80, 90),  # 陡峭
            'dip_bottom': self.rng.uniform(30, 50),  # 变缓
            'throw': self.rng.uniform(25, 40),
            'i1_start': fault_start_depth,
            'i1_end': n1,  # 延伸到底部
            'growth_factor': 1.0  # 无生长
        }

        # 4d. 断层 3 的拖曳效应
        params['flexure3'] = {
            'flexure_width': self.rng.uniform(30, 50),
            'max_flexure_depth_shift': self.rng.uniform(20, 35)
        }

        # --- 5. 衰减带参数 (所有断层共用) ---
        params['zone'] = {
            'zone_width': self.rng.uniform(6, 10),
            'blur_sigma': self.rng.uniform(0.3, 0.7),
            'attenuation_factor': self.rng.uniform(0.3, 0.6)
        }

        # --- 6. 垂向剪切 ---
        params['shear'] = {
            'scale': self.rng.uniform(0.03, 0.08)
        }

        return params

    def seismic_and_slopes_2d(self, n1=256, n2=512, noise=0, params=None):

        # 1. 创建基础反射系数
        reflectivity = self._make_reflectivity_2d(n1, n2)

        # (修改) 如果没有提供参数，则使用一组固定的默认值（用于调试）
        if params is None:
            # (使用您上一版代码中的硬编码值作为默认值)
            params = self.generate_plausible_parameters(n1, n2)
            # (为了简化，我们直接调用生成器。在实际应用中，这里可以放一组固定的默认值)

        # 应用分层褶皱
        p_fold = params['folding']
        lower_params = {'a1': 0, 'b1': p_fold['lower_amp'], 'a2': 5e-5, 'b2': p_fold['lower_freq_b']}
        upper_params = {'a1': 0, 'b1': p_fold['upper_amp'], 'a2': 8e-4, 'b2': p_fold['upper_freq_b']}

        reflectivity = self._apply_sinusoidal_fold_2d_layered(
            reflectivity, n1, n2,
            boundary_i1=p_fold['boundary_i1'],
            upper_params=upper_params,
            lower_params=lower_params
        )

        # --- 2.5. 模拟地层尖灭 ---
        reflectivity = self._apply_stratigraphic_wedge_2d(
            reflectivity, n1, n2, **params['wedge']
        )

        #  模拟盐丘上拱
        reflectivity = self._apply_salt_dome_2d(
            reflectivity, n1, n2, **params['salt_dome']
        )

        zone_params = params['zone']

        # 4. 应用弯曲的铲状断层

        # --- 断层 1 ---
        fault1_params = params['fault1']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault1_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault1_params, **zone_params)

        # --- 断层 2 (生长断层) ---
        fault2_params = params['fault2']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault2_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault2_params, **zone_params)

        # --- 断层 3 (大断层) ---
        fault3_params = params['fault3']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault3_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault3_params, **zone_params)

        # --- 5.5. 应用断层拖曳 (断层3) ---
        # 组合 fault3 和 flexure3 的参数
        flexure_params = {**fault3_params, **params['flexure3']}
        reflectivity = self._apply_geometric_flexure_2d(
            reflectivity, n1, n2, **flexure_params
        )

        reflectivity = self._apply_vertical_shear_2d(
            reflectivity, n1, n2, **params['shear']
        )

        # 6. 归一化和添加噪声
        image = reflectivity
        image = image / np.std(image)  # 归一化

        if noise > 0:
            noise_array = self.rng.randn(*image.shape)
            noise_array = gaussian_filter(noise_array, sigma=2.0, order=1)
            noise_array = noise_array * noise * np.std(image) / np.std(noise_array)
            image = image + noise_array

        return image

    def _make_reflectivity_2d(self, n1, n2):
        r = 2.0 * self.rng.rand(n1) - 1.0
        r = np.sign(r) * np.abs(r) ** 5
        reflectivity = np.tile(r[:, np.newaxis], (1, n2)).T
        return reflectivity

    def _apply_vertical_shear_2d(self, data, n1, n2, scale=0.05):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([
            i2.astype(float),  # 横向坐标不变
            np.clip(i1 - scale * i2, 0, n1 - 1)  # 深度坐标剪切并裁剪
        ])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_stratigraphic_wedge_2d(self, data, n1, n2, i1_start, i1_end, x2_start, x2_end, direction='left'):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        x2_min = min(x2_start, x2_end)
        x2_max = max(x2_start, x2_end)
        x2_width = x2_max - x2_min
        if x2_width <= 0:
            return data
        x2_active = np.clip(i2, x2_min, x2_max)
        if direction == 'left':
            attenuation_factor = (x2_active - x2_min) / x2_width
        elif direction == 'right':
            attenuation_factor = 1.0 - (x2_active - x2_min) / x2_width
        else:
            return data
        wedge_mask = depth_mask & (i2 >= x2_min) & (i2 < x2_max)
        data[wedge_mask] *= attenuation_factor[wedge_mask]
        return data

    def _apply_sinusoidal_fold_2d_layered(self, data, n1, n2, boundary_i1, upper_params, lower_params):
        i1_range, i2_range = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        shift = np.zeros_like(i1_range, dtype=float)
        mask_upper = (i1_range < boundary_i1)
        up = upper_params
        shift[mask_upper] = (up['a1'] + up['b1'] * i1_range[mask_upper]) * \
                            np.sin((up['a2'] + up['b2'] * i2_range[mask_upper]) * i2_range[mask_upper])
        mask_lower = (i1_range >= boundary_i1)
        low = lower_params
        shift[mask_lower] = (low['a1'] + low['b1'] * i1_range[mask_lower]) * \
                            np.sin((low['a2'] + low['b2'] * i2_range[mask_lower]) * i2_range[mask_lower])
        x1_new = i1_range - shift
        coords = np.zeros((2, n2, n1))
        coords[0, :, :] = i2_range
        coords[1, :, :] = np.clip(x1_new, 0, n1 - 1)
        return map_coordinates(data, coords.reshape(2, n2, n1), order=3, mode='nearest')

    def _apply_salt_dome_2d(self, data, n1, n2, dome_center_x2, dome_height, dome_width, i1_start_lift=0,
                            i1_end_lift=None):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        if i1_end_lift is None:
            i1_end_lift = n1
        n1_effective = i1_end_lift - i1_start_lift
        if n1_effective <= 0:
            return data
        i1_offset = np.maximum(0, i1 - i1_start_lift)
        i1_norm_raw = i1_offset / n1_effective
        i1_norm_clamped = np.clip(i1_norm_raw, 0, 1)
        uplift_scale = 4 * i1_norm_clamped * (1 - i1_norm_clamped)
        shift = dome_height * np.exp(-((i2 - dome_center_x2) ** 2) / (2 * dome_width ** 2)) * uplift_scale
        src_i1 = np.clip(i1 + shift, 0, n1 - 1)
        src_i2 = i2.astype(float)
        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_curved_normal_fault_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, throw, i1_start, i1_end,
                                      growth_factor=1.0):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([i2.astype(float), i1.astype(float)])
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        if dip_top > 0:
            downthrown_mask = (i2 > fault_x2_trace[np.newaxis, :])
        else:
            downthrown_mask = (i2 < fault_x2_trace[np.newaxis, :])
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        fault_mask = downthrown_mask & depth_mask
        i1_offset_from_start = coords[1][fault_mask] - i1_start
        growth_displacement = i1_offset_from_start * (growth_factor - 1.0)
        total_displacement = throw + growth_displacement
        src_i1 = coords[1][fault_mask] - total_displacement
        coords[1][fault_mask] = np.clip(src_i1, 0, n1 - 1)
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_fault_zone_attenuation_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom,
                                         zone_width, blur_sigma, attenuation_factor, i1_start, i1_end, **kwargs):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        fault_x2_trace_grid = fault_x2_trace[np.newaxis, :]
        dist_to_fault = np.abs(i2 - fault_x2_trace_grid)
        zone_mask_proximity = (dist_to_fault <= zone_width / 2.0)
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        zone_mask = zone_mask_proximity & depth_mask
        if np.any(zone_mask):
            blurred_data = gaussian_filter(data, sigma=blur_sigma)
            data[zone_mask] = blurred_data[zone_mask]
            data[zone_mask] *= attenuation_factor
        return data

    def _apply_geometric_flexure_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, i1_start, i1_end,
                                    flexure_width, max_flexure_depth_shift, **kwargs):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        if dip_top > 0:
            is_downthrown = (i2 > fault_x2_trace[np.newaxis, :])
            dist_to_fault = i2 - fault_x2_trace[np.newaxis, :]
            shift_direction = -1
        else:
            is_downthrown = (i2 < fault_x2_trace[np.newaxis, :])
            dist_to_fault = fault_x2_trace[np.newaxis, :] - i2
            shift_direction = -1
        dist_clamped = np.clip(dist_to_fault, 0, flexure_width)
        horizontal_weight = (flexure_width - dist_clamped) / flexure_width
        i1_norm = np.clip((i1 - i1_start) / (i1_end - i1_start + 1e-6), 0, 1)
        depth_weight = i1_norm
        flexure_shift = (
                max_flexure_depth_shift * horizontal_weight * depth_weight * shift_direction
        )
        flexure_mask = is_downthrown & (dist_to_fault > 0) & (dist_to_fault < flexure_width) & (i1 >= i1_start) & (
                i1 < i1_end)
        src_i1 = i1.astype(float)
        src_i2 = i2.astype(float)
        src_i1[flexure_mask] = np.clip(src_i1[flexure_mask] + flexure_shift[flexure_mask], 0, n1 - 1)
        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')


    def convolve_with_wavelet(self, image, wavelet):
        """
        对每条道进行 1D 卷积（沿 X1，即 axis=1）
        image: shape (n2, n1)
        wavelet: 1D Ricker wavelet
        """
        n2, n1 = image.shape
        output = np.zeros_like(image)

        # 对每一条道进行卷积
        for i2 in range(n2):
            output[i2, :] = np.convolve(image[i2, :], wavelet, mode='same')

        return output


# --- 绘图函数 (修改：接受标题) ---
def plot_2d_result(image, title='Seismic Image (Geological Model - No Convolution)'):
    """(修改) 绘图函数，接受自定义标题"""
    fig, axes = plt.subplots(1, 1, figsize=(12, 7))
    axes.imshow(image.T, cmap='gray', aspect='auto', origin='upper')
    axes.set_title(title)
    axes.set_xlabel('X2')
    axes.set_ylabel('X1 (Depth)')
    plt.tight_layout()
    plt.show()

def plot_wavelets_by_phase(frequency, phases_deg, dt=0.004, length=0.256, title=None):
    fig, ax = plt.subplots(1, 1, figsize=(10, 4))
    for ph in phases_deg:
        t, w = ricker_wavelet_with_phase(frequency=frequency, phase_deg=ph, dt=dt, length=length, return_t=True)
        ax.plot(t, w, label=f"{ph}°")
    ax.axhline(0, linewidth=1)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Amplitude")
    ax.set_title(title or f"Ricker wavelets with phase rotation (f0={frequency} Hz)")
    ax.legend(ncol=4, fontsize=9)
    plt.tight_layout()
    plt.show()

def downsample_x2(img):
    # (512,512) -> (256,256)
    return zoom(img, zoom=(0.5, 0.5), order=1).astype(np.float32)  # order=1 双线性

# =====================================================================
# Layer-controlled broadband amplitude attenuation SVG generation pipeline
# =====================================================================
import argparse
from pathlib import Path


def ricker_wavelet_zero_phase(frequency=30.0, dt=0.004, length=0.256):
    """Zero-phase Ricker wavelet without console printing."""
    t = np.arange(-length / 2.0, length / 2.0 + dt, dt, dtype=np.float32)
    a = (np.pi * float(frequency) * t) ** 2
    w = (1.0 - 2.0 * a) * np.exp(-a)
    w = w / (np.max(np.abs(w)) + 1.0e-12)
    return w.astype(np.float32)


def normalize_zero_mean_unit_std(x):
    """Normalize the base LQ section before applying broadband amplitude modulation."""
    x = x.astype(np.float32)
    return ((x - np.mean(x)) / (np.std(x) + 1.0e-12)).astype(np.float32)


def smooth_box_window_1d(n, top, bottom, edge_softness=14):
    """
    Soft rectangular layer window along the depth/time axis.

    The output is close to 1 within [top, bottom] and gradually tapers to 0
    around the layer top and bottom. This avoids an artificial hard boundary.
    """
    z = np.arange(n, dtype=np.float32)
    top = float(np.clip(top, 0, n - 1))
    bottom = float(np.clip(bottom, 0, n - 1))
    if bottom <= top:
        bottom = min(float(n - 1), top + 1.0)

    s = max(float(edge_softness), 1.0)
    enter = 1.0 / (1.0 + np.exp(-(z - top) / s))
    leave = 1.0 / (1.0 + np.exp((z - bottom) / s))
    win = enter * leave
    win = win / (win.max() + 1.0e-12)
    return win.astype(np.float32)


def make_layer_energy_mask(n2, n1, top_ratio=0.38, bottom_ratio=0.62, edge_softness=14):
    """
    Create a middle-layer broadband amplitude mask.

    Shape: (n2, n1). Values are in [0, 1]. A value close to 1 means the
    corresponding time/depth sample belongs to the weakened layer.
    """
    top = float(top_ratio) * n1
    bottom = float(bottom_ratio) * n1
    win_z = smooth_box_window_1d(n1, top=top, bottom=bottom, edge_softness=edge_softness)
    mask = np.tile(win_z[None, :], (n2, 1)).astype(np.float32)
    return np.clip(mask, 0.0, 1.0)


def apply_layer_energy_attenuation(section, layer_mask, layer_amp_loss=0.45):
    """
    Apply layer-controlled broadband amplitude weakening.

    This simulates A(t,x)<1 in the selected stratigraphic interval. It is a
    frequency-independent scaling and does not perform Q filtering, so the
    spectral shape and wavelet width are approximately preserved.
    """
    x = section.astype(np.float32)
    m = np.clip(layer_mask.astype(np.float32), 0.0, 1.0)
    loss = float(np.clip(layer_amp_loss, 0.0, 0.95))
    amp_field = 1.0 - loss * m
    return (x * amp_field).astype(np.float32), amp_field.astype(np.float32)


def save_gray_svg(section, out_path, clip_value=None, clip_percentile=98.0, gain=1.8, figsize=(2.56, 2.56), dpi=100):
    """
    Save a seismic section as grayscale SVG.

    The seismic section is raster data embedded in an SVG container. The display
    uses robust percentile clipping and tanh contrast enhancement.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    x = section.astype(np.float32)
    if clip_value is None:
        clip_value = float(np.percentile(np.abs(x), clip_percentile))
    clip_value = max(float(clip_value), 1.0e-8)

    disp = np.clip(x, -clip_value, clip_value) / clip_value
    disp = np.tanh(float(gain) * disp) / np.tanh(float(gain))

    fig, ax = plt.subplots(figsize=figsize)
    ax.imshow(disp.T, cmap="gray", vmin=-1.0, vmax=1.0, aspect="auto", origin="upper")
    ax.set_axis_off()
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    fig.savefig(out_path, format="svg", dpi=dpi, bbox_inches="tight", pad_inches=0)
    plt.close(fig)


def save_mask_svg(mask, out_path, figsize=(2.56, 2.56), dpi=100):
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=figsize)
    ax.imshow(mask.T, cmap="gray", vmin=0.0, vmax=1.0, aspect="auto", origin="upper")
    ax.set_axis_off()
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    fig.savefig(out_path, format="svg", dpi=dpi, bbox_inches="tight", pad_inches=0)
    plt.close(fig)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate LQ synthetic seismic SVGs with middle-layer broadband energy weakening."
    )
    parser.add_argument("--num_images", type=int, default=5, help="Small-batch sample count.")
    parser.add_argument("--out_dir", type=str, default="lq_layer_energy_outputs", help="Output root directory.")
    parser.add_argument("--n1", type=int, default=256, help="Depth/time samples.")
    parser.add_argument("--n2", type=int, default=256, help="Lateral samples.")
    parser.add_argument("--start_seed", type=int, default=0, help="First random seed.")
    parser.add_argument("--dt", type=float, default=0.004, help="Sampling interval in seconds.")
    parser.add_argument("--lq_freq", type=float, default=30.0, help="LQ Ricker dominant frequency in Hz.")
    parser.add_argument("--wavelet_length", type=float, default=0.256, help="Ricker wavelet length in seconds.")

    parser.add_argument("--layer_top_ratio", type=float, default=0.38, help="Top of the weakened layer as a fraction of n1.")
    parser.add_argument("--layer_bottom_ratio", type=float, default=0.62, help="Bottom of the weakened layer as a fraction of n1.")
    parser.add_argument("--layer_amp_loss", type=float, default=0.45, help="Broadband amplitude loss inside the layer. 0.45 means about 45% weakening at the layer center.")
    parser.add_argument("--layer_edge_softness", type=float, default=12.0, help="Soft transition width near the layer top and bottom, in samples.")

    parser.add_argument("--clip_percentile", type=float, default=98.0, help="Display clipping percentile.")
    parser.add_argument("--display_gain", type=float, default=1.8, help="Tanh display gain.")
    parser.add_argument("--save_base", action="store_true", help="Also save the unmodulated 30 Hz LQ SVG for comparison.")
    parser.add_argument("--save_mask", action="store_true", help="Also save the layer amplitude field/mask SVG.")
    return parser.parse_args()


def main():
    args = parse_args()
    out_root = Path(args.out_dir)
    layer_dir = out_root / "lq_layer_energy_svg"
    base_dir = out_root / "lq_base_svg"
    mask_dir = out_root / "layer_energy_mask_svg"

    dirs = [layer_dir]
    if args.save_base:
        dirs.append(base_dir)
    if args.save_mask:
        dirs.append(mask_dir)
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)

    lq_wavelet = ricker_wavelet_zero_phase(
        frequency=args.lq_freq, dt=args.dt, length=args.wavelet_length
    )

    for i in range(args.num_images):
        seed = args.start_seed + i
        generator = GeologicalSeismicData(seed=seed)
        params = generator.generate_plausible_parameters(n1=args.n1, n2=args.n2)

        # Reflectivity model: no noise.
        reflectivity = generator.seismic_and_slopes_2d(
            n1=args.n1, n2=args.n2, noise=0, params=params
        )

        # Base LQ: 30 Hz Ricker convolution only.
        lq_base = generator.convolve_with_wavelet(reflectivity, lq_wavelet).astype(np.float32)
        lq_base = normalize_zero_mean_unit_std(lq_base)

        # Broadband layer-controlled amplitude weakening: A(t,x)<1 in the middle layer.
        layer_mask = make_layer_energy_mask(
            args.n2,
            args.n1,
            top_ratio=args.layer_top_ratio,
            bottom_ratio=args.layer_bottom_ratio,
            edge_softness=args.layer_edge_softness,
        )
        lq_layer_energy, amp_field = apply_layer_energy_attenuation(
            lq_base,
            layer_mask,
            layer_amp_loss=args.layer_amp_loss,
        )

        # Use the base LQ clip so the layer weakening remains visually visible.
        clip_value = float(np.percentile(np.abs(lq_base), args.clip_percentile))
        fname = f"{i + 1:04d}"

        save_gray_svg(
            lq_layer_energy,
            layer_dir / f"{fname}_LQ_layer_energy_weakening.svg",
            clip_value=clip_value,
            clip_percentile=args.clip_percentile,
            gain=args.display_gain,
        )

        if args.save_base:
            save_gray_svg(
                lq_base,
                base_dir / f"{fname}_LQ_base_30Hz.svg",
                clip_value=clip_value,
                clip_percentile=args.clip_percentile,
                gain=args.display_gain,
            )

        if args.save_mask:
            save_mask_svg(amp_field, mask_dir / f"{fname}_A_tx_layer_energy_field.svg")

        print(
            f"[{i + 1}/{args.num_images}] saved layer-energy LQ SVG "
            f"(seed={seed}, LQ={args.lq_freq:g} Hz, amp_loss={args.layer_amp_loss:g})."
        )

    print(f"Done. Output root: {out_root.resolve()}")


if __name__ == "__main__":
    main()
