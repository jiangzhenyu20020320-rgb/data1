from pathlib import Path
import csv
import json
import random
import shutil
from collections import defaultdict, Counter

ROOT = Path(r"D:\dateset0309\dataset_waveform_bwe_multistruct_timevarying_v6_ricker_shoulder")

LQ_DIR = ROOT / "lq"
GT_DIR = ROOT / "gt"
META_DIR = ROOT / "meta"
INDEX_CSV = ROOT / "sample_index.csv"

TRAIN_LQ = ROOT / "train" / "lq"
TRAIN_GT = ROOT / "train" / "gt"
TRAIN_META = ROOT / "train" / "meta"

VAL_LQ = ROOT / "val" / "lq"
VAL_GT = ROOT / "val" / "gt"
VAL_META = ROOT / "val" / "meta"

VAL_RATIO = 0.20
SEED = 20260612
COPY_META = True


def ensure_dirs():
    for d in [TRAIN_LQ, TRAIN_GT, TRAIN_META, VAL_LQ, VAL_GT, VAL_META]:
        d.mkdir(parents=True, exist_ok=True)


def clear_split_dirs():
    # 只清空 train/val，不动原始 lq/gt/meta/sample_index.csv
    for d in [TRAIN_LQ, TRAIN_GT, TRAIN_META, VAL_LQ, VAL_GT, VAL_META]:
        if d.exists():
            for p in d.glob("*"):
                if p.is_file():
                    p.unlink()


def load_rows():
    if INDEX_CSV.exists():
        rows = []
        with open(INDEX_CSV, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for r in reader:
                sid = str(r.get("id", "")).strip()
                if not sid:
                    continue
                name = sid if sid.endswith(".dat") else f"{int(sid):04d}.dat"
                rows.append({
                    "name": name,
                    "id": sid,
                    "structure": r.get("structure", "unknown_structure"),
                    "family": r.get("family", "unknown_family"),
                })
        return rows

    # fallback：没有 sample_index.csv 时，从 meta 读取
    rows = []
    for p in sorted(LQ_DIR.glob("*.dat")):
        meta_path = META_DIR / p.name.replace(".dat", ".json")
        meta = {}
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                meta = {}
        rows.append({
            "name": p.name,
            "id": p.stem,
            "structure": meta.get("structure", "unknown_structure"),
            "family": meta.get("family", "unknown_family"),
        })
    return rows


def copy_pair(name, split):
    src_lq = LQ_DIR / name
    src_gt = GT_DIR / name
    src_meta = META_DIR / name.replace(".dat", ".json")

    if not src_lq.exists():
        raise FileNotFoundError(src_lq)
    if not src_gt.exists():
        raise FileNotFoundError(src_gt)

    if split == "train":
        shutil.copy2(src_lq, TRAIN_LQ / name)
        shutil.copy2(src_gt, TRAIN_GT / name)
        if COPY_META and src_meta.exists():
            shutil.copy2(src_meta, TRAIN_META / src_meta.name)
    elif split == "val":
        shutil.copy2(src_lq, VAL_LQ / name)
        shutil.copy2(src_gt, VAL_GT / name)
        if COPY_META and src_meta.exists():
            shutil.copy2(src_meta, VAL_META / src_meta.name)
    else:
        raise ValueError(split)


def write_split_index(train_rows, val_rows):
    out_csv = ROOT / "split_index.csv"
    fields = ["split", "id", "name", "structure", "family"]
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for split, rows in [("train", train_rows), ("val", val_rows)]:
            for r in rows:
                writer.writerow({
                    "split": split,
                    "id": r["id"],
                    "name": r["name"],
                    "structure": r["structure"],
                    "family": r["family"],
                })

    out_json = ROOT / "split_count.json"
    count = {
        "total": len(train_rows) + len(val_rows),
        "train": len(train_rows),
        "val": len(val_rows),
        "train_by_structure": dict(Counter(r["structure"] for r in train_rows)),
        "val_by_structure": dict(Counter(r["structure"] for r in val_rows)),
        "train_by_family": dict(Counter(r["family"] for r in train_rows)),
        "val_by_family": dict(Counter(r["family"] for r in val_rows)),
        "train_by_structure_family": dict(Counter(f"{r['structure']}_{r['family']}" for r in train_rows)),
        "val_by_structure_family": dict(Counter(f"{r['structure']}_{r['family']}" for r in val_rows)),
    }
    out_json.write_text(json.dumps(count, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(count, ensure_ascii=False, indent=2))


def main():
    ensure_dirs()
    clear_split_dirs()

    rows = load_rows()
    if not rows:
        raise RuntimeError(f"No samples found in {ROOT}")

    groups = defaultdict(list)
    for r in rows:
        groups[(r["structure"], r["family"])].append(r)

    rng = random.Random(SEED)
    train_rows = []
    val_rows = []

    for key, group_rows in sorted(groups.items()):
        group_rows = list(group_rows)
        rng.shuffle(group_rows)

        if len(group_rows) <= 1:
            n_val = 0
        else:
            n_val = max(1, round(len(group_rows) * VAL_RATIO))

        val_part = group_rows[:n_val]
        train_part = group_rows[n_val:]

        val_rows.extend(val_part)
        train_rows.extend(train_part)

        print(f"group={key}, total={len(group_rows)}, train={len(train_part)}, val={len(val_part)}")

    train_rows = sorted(train_rows, key=lambda r: r["name"])
    val_rows = sorted(val_rows, key=lambda r: r["name"])

    for r in train_rows:
        copy_pair(r["name"], "train")
    for r in val_rows:
        copy_pair(r["name"], "val")

    write_split_index(train_rows, val_rows)

    print()
    print("[OK] split completed")
    print(f"root      : {ROOT}")
    print(f"train num : {len(train_rows)}")
    print(f"val num   : {len(val_rows)}")
    print(f"train lq  : {TRAIN_LQ}")
    print(f"train gt  : {TRAIN_GT}")
    print(f"val lq    : {VAL_LQ}")
    print(f"val gt    : {VAL_GT}")


if __name__ == "__main__":
    main()