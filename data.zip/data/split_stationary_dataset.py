# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import csv
import json
import random
import shutil
from collections import Counter, defaultdict
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(
        description="Split stationary BWE dataset into train/val folders."
    )
    parser.add_argument(
        "--root",
        default=r"D:\dateset0309\dataset_waveform_bwe_multistruct_stationary_sf1_narrow_lq_target_bwe",
        help="Dataset root containing lq/, gt/, meta/, wavelets/, qc/.",
    )
    parser.add_argument(
        "--val_ratio",
        type=float,
        default=0.10,
        help="Validation ratio. Default: 0.10",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=2026,
        help="Random seed.",
    )
    parser.add_argument(
        "--mode",
        choices=["copy", "move", "hardlink"],
        default="copy",
        help="How to create split files. Default: copy.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Remove existing train/ and val/ before splitting.",
    )
    return parser.parse_args()


def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def remove_if_needed(path: Path, overwrite: bool):
    if path.exists():
        if overwrite:
            print(f"[REMOVE] {path}")
            shutil.rmtree(path)
        else:
            raise FileExistsError(
                f"{path} already exists. Use --overwrite to remove it first."
            )


def read_meta(meta_path: Path):
    if not meta_path.exists():
        return {
            "structure": "unknown_structure",
            "family": "unknown_family",
            "phase_deg": "",
        }
    try:
        with open(meta_path, "r", encoding="utf-8") as f:
            meta = json.load(f)
        return {
            "structure": str(meta.get("structure", "unknown_structure")),
            "family": str(meta.get("family", "unknown_family")),
            "phase_deg": meta.get("phase_deg", ""),
        }
    except Exception as e:
        print(f"[WARN] failed to read meta: {meta_path}, error={e}")
        return {
            "structure": "bad_meta",
            "family": "bad_meta",
            "phase_deg": "",
        }


def transfer_file(src: Path, dst: Path, mode: str):
    if not src.exists():
        return False

    ensure_dir(dst.parent)

    if mode == "copy":
        shutil.copy2(src, dst)
    elif mode == "move":
        shutil.move(str(src), str(dst))
    elif mode == "hardlink":
        try:
            dst.hardlink_to(src)
        except Exception:
            shutil.copy2(src, dst)
    else:
        raise ValueError(f"Unsupported mode: {mode}")

    return True


def get_samples(root: Path):
    lq_dir = root / "lq"
    gt_dir = root / "gt"
    meta_dir = root / "meta"

    if not lq_dir.is_dir():
        raise FileNotFoundError(f"LQ directory not found: {lq_dir}")
    if not gt_dir.is_dir():
        raise FileNotFoundError(f"GT directory not found: {gt_dir}")

    lq_files = {p.stem: p for p in sorted(lq_dir.glob("*.dat"))}
    gt_files = {p.stem: p for p in sorted(gt_dir.glob("*.dat"))}

    common_stems = sorted(set(lq_files).intersection(gt_files))
    if not common_stems:
        raise RuntimeError("No paired .dat files found.")

    missing_lq = sorted(set(gt_files) - set(lq_files))
    missing_gt = sorted(set(lq_files) - set(gt_files))
    if missing_lq:
        print(f"[WARN] {len(missing_lq)} GT files have no LQ pair.")
    if missing_gt:
        print(f"[WARN] {len(missing_gt)} LQ files have no GT pair.")

    samples = []
    for stem in common_stems:
        meta_path = meta_dir / f"{stem}.json"
        meta = read_meta(meta_path)
        samples.append(
            {
                "id": stem,
                "lq": lq_files[stem],
                "gt": gt_files[stem],
                "meta": meta_path,
                "structure": meta["structure"],
                "family": meta["family"],
                "phase_deg": meta["phase_deg"],
            }
        )

    return samples


def stratified_split(samples, val_ratio: float, seed: int):
    rng = random.Random(seed)

    groups = defaultdict(list)
    for s in samples:
        key = (s["structure"], s["family"])
        groups[key].append(s)

    train_samples = []
    val_samples = []

    for key, group in sorted(groups.items()):
        rng.shuffle(group)
        n = len(group)

        n_val = int(round(n * val_ratio))
        if val_ratio > 0 and n >= 2:
            n_val = max(1, n_val)
        n_val = min(n_val, n - 1) if n > 1 else 0

        val_part = group[:n_val]
        train_part = group[n_val:]

        val_samples.extend(val_part)
        train_samples.extend(train_part)

        print(
            f"[GROUP] structure={key[0]:<16} family={key[1]:<8} "
            f"total={n:4d} train={len(train_part):4d} val={len(val_part):4d}"
        )

    rng.shuffle(train_samples)
    rng.shuffle(val_samples)

    return train_samples, val_samples


def copy_split(samples, root: Path, split_name: str, mode: str):
    split_root = root / split_name

    rows = []

    for s in samples:
        stem = s["id"]

        dst_lq = split_root / "lq" / f"{stem}.dat"
        dst_gt = split_root / "gt" / f"{stem}.dat"
        dst_meta = split_root / "meta" / f"{stem}.json"

        transfer_file(s["lq"], dst_lq, mode)
        transfer_file(s["gt"], dst_gt, mode)

        if s["meta"].exists():
            transfer_file(s["meta"], dst_meta, mode)

        # wavelets
        w_dir = root / "wavelets"
        w_lq = w_dir / f"{stem}_w_lq.npy"
        w_gt = w_dir / f"{stem}_w_gt.npy"

        dst_w_lq = split_root / "wavelets" / f"{stem}_w_lq.npy"
        dst_w_gt = split_root / "wavelets" / f"{stem}_w_gt.npy"

        transfer_file(w_lq, dst_w_lq, mode)
        transfer_file(w_gt, dst_w_gt, mode)

        # qc, only if exists
        qc_dir = root / "qc"
        qc_png = qc_dir / f"{stem}_qc.png"
        dst_qc = split_root / "qc" / f"{stem}_qc.png"
        transfer_file(qc_png, dst_qc, mode)

        rows.append(
            {
                "id": stem,
                "split": split_name,
                "structure": s["structure"],
                "family": s["family"],
                "phase_deg": s["phase_deg"],
                "lq_path": str(dst_lq),
                "gt_path": str(dst_gt),
                "meta_path": str(dst_meta) if dst_meta.exists() else "",
                "w_lq_path": str(dst_w_lq) if dst_w_lq.exists() else "",
                "w_gt_path": str(dst_w_gt) if dst_w_gt.exists() else "",
                "qc_path": str(dst_qc) if dst_qc.exists() else "",
            }
        )

    return rows


def write_index(root: Path, rows):
    out_csv = root / "split_index.csv"
    fields = [
        "id",
        "split",
        "structure",
        "family",
        "phase_deg",
        "lq_path",
        "gt_path",
        "meta_path",
        "w_lq_path",
        "w_gt_path",
        "qc_path",
    ]

    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})

    print(f"[SAVE] {out_csv}")


def write_count_json(root: Path, train_samples, val_samples):
    def count_block(samples):
        return {
            "total": len(samples),
            "by_structure": dict(Counter(s["structure"] for s in samples)),
            "by_family": dict(Counter(s["family"] for s in samples)),
            "by_structure_family": dict(
                Counter(f"{s['structure']}_{s['family']}" for s in samples)
            ),
        }

    out = {
        "train": count_block(train_samples),
        "val": count_block(val_samples),
        "total": len(train_samples) + len(val_samples),
    }

    out_json = root / "split_count.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"[SAVE] {out_json}")
    print(json.dumps(out, ensure_ascii=False, indent=2))


def main():
    args = parse_args()

    root = Path(args.root)
    if not root.is_dir():
        raise FileNotFoundError(f"Dataset root not found: {root}")

    if not (0.0 < args.val_ratio < 1.0):
        raise ValueError("--val_ratio must be between 0 and 1.")

    train_root = root / "train"
    val_root = root / "val"

    remove_if_needed(train_root, args.overwrite)
    remove_if_needed(val_root, args.overwrite)

    for split in ["train", "val"]:
        for sub in ["lq", "gt", "meta", "wavelets", "qc"]:
            ensure_dir(root / split / sub)

    samples = get_samples(root)
    print(f"[INFO] paired samples found: {len(samples)}")

    train_samples, val_samples = stratified_split(
        samples=samples,
        val_ratio=args.val_ratio,
        seed=args.seed,
    )

    print(f"[INFO] train samples: {len(train_samples)}")
    print(f"[INFO] val samples:   {len(val_samples)}")

    train_rows = copy_split(train_samples, root, "train", args.mode)
    val_rows = copy_split(val_samples, root, "val", args.mode)

    all_rows = train_rows + val_rows
    write_index(root, all_rows)
    write_count_json(root, train_samples, val_samples)

    print("\n[DONE]")
    print(f"Train LQ: {root / 'train' / 'lq'}")
    print(f"Train GT: {root / 'train' / 'gt'}")
    print(f"Val   LQ: {root / 'val' / 'lq'}")
    print(f"Val   GT: {root / 'val' / 'gt'}")


if __name__ == "__main__":
    main()