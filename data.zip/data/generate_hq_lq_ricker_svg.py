import os
from scipy.signal import hilbert
import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter, map_coordinates, zoom
def ricker_wavelet_with_phase(frequency=25, phase_deg=0, dt=0.004, length=0.256, return_t=True):
    """
    生成带相位(常相位旋转)的 Ricker 子波
    w_phase = cos(phi)*w - sin(phi)*Hilbert(w)
    """
    t = np.arange(-length / 2, length / 2, dt)

    # 1) 零相位 Ricker
    w0 = (1 - 2 * (np.pi ** 2) * (frequency ** 2) * (t ** 2)) * \
         np.exp(-(np.pi ** 2) * (frequency ** 2) * (t ** 2))

    # 2) Hilbert 变换得到 90° 分量
    w_h = np.imag(hilbert(w0))

    # 3) 常相位旋转
    phi = np.deg2rad(phase_deg)
    w_phase = np.cos(phi) * w0 - np.sin(phi) * w_h
    print("dt used:", dt, "nt:", len(t))

    if return_t:
        return t, w_phase
    return w_phase

def add_offset_noise(img, rng, snr_db=15.0,
                     offset_exp=1.8, min_scale=0.4, max_scale=1.0,
                     bandlimit=True, fmin=0.02, fmax=0.25):
    """
    偏移剖面噪声（offset-dependent noise）
    img: (n2, n1)  # 你的图像：X2在第0维，深度在第1维
    snr_db: 控制噪声强弱（典型 8~25dB；越小噪声越强）
    offset_exp/min_scale/max_scale: 控制“远偏移更吵”的程度
    bandlimit: True 时把噪声带限成更像地震噪声的形态
    """
    n2, n1 = img.shape
    x = img.astype(np.float32)

    # 用全图 RMS 定一个总噪声水平（由 snr_db 控制）
    sig_rms = np.sqrt(np.mean(x**2) + 1e-12)
    noise_rms = sig_rms / (10.0 ** (snr_db / 20.0))

    # 以中心道为近偏移，向两侧偏移增大（0~1）
    i2 = np.arange(n2, dtype=np.float32)
    center = (n2 - 1) / 2.0
    off = np.abs(i2 - center) / (center + 1e-12)

    # 每条道噪声标准差权重：近偏移小，远偏移大
    w = min_scale + (max_scale - min_scale) * (off ** offset_exp)

    # 生成噪声并按道加权
    noise = rng.standard_normal((n2, n1)).astype(np.float32)
    noise *= (noise_rms * w)[:, None]

    # 可选：沿深度方向带限（让噪声更像地震噪声，不那么“像素白噪声”）
    if bandlimit:
        F = np.fft.rfft(noise, axis=1)
        freqs = np.fft.rfftfreq(n1, d=1.0)  # 归一化频率 0~0.5
        win = np.zeros_like(freqs, dtype=np.float32)

        tw = 0.02  # 过渡带宽
        f1, f2 = max(fmin - tw, 0.0), fmin
        f3, f4 = fmax, min(fmax + tw, 0.5)

        m = (freqs >= f1) & (freqs < f2)
        if np.any(m):
            t = (freqs[m] - f1) / (f2 - f1 + 1e-12)
            win[m] = 0.5 - 0.5 * np.cos(np.pi * t)
        win[(freqs >= f2) & (freqs <= f3)] = 1.0
        m = (freqs > f3) & (freqs <= f4)
        if np.any(m):
            t = (freqs[m] - f3) / (f4 - f3 + 1e-12)
            win[m] = 0.5 + 0.5 * np.cos(np.pi * t)

        F *= win[None, :]
        noise = np.fft.irfft(F, n=n1, axis=1).astype(np.float32)

    return x + noise





class GeologicalSeismicData:

    def __init__(self, seed=31):
        self.rng = np.random.RandomState(seed)

    def generate_plausible_parameters(self, n1, n2):
        """
        (新) 批量生成符合地质逻辑的参数。

        基本逻辑：
        1. 定义一个主要的盐丘构造。
        2. 定义一个主要的生长断层（可能与盐丘有关，也可能独立）。
        3. 定义一个主要的裂谷大断层（带拖曳效应）。
        4. 定义次要的尖灭和剪切。
        """
        params = {}

        # --- 1. 分层褶皱 ---
        params['folding'] = {
            'boundary_i1': n1 // self.rng.uniform(2.5, 4.5),  # 褶皱边界深度
            'lower_amp': self.rng.uniform(0.02, 0.04),  # 深层褶皱幅度
            'lower_freq_b': self.rng.uniform(4e-5, 6e-5),  # 深层褶皱频率
            'upper_amp': self.rng.uniform(0.005, 0.015),  # 浅层褶皱幅度
            'upper_freq_b': self.rng.uniform(7e-4, 9e-4)  # 浅层褶皱频率
        }

        # --- 2. 地层尖灭 ---
        # (保持在右侧，模拟盆地边缘)
        wedge_width = self.rng.uniform(50, 100)
        params['wedge'] = {
            'i1_start': self.rng.uniform(n1 * 0.7, n1 * 0.8),  # 尖灭深度
            'i1_end': self.rng.uniform(n1 * 0.85, n1 * 0.95),
            'x2_start': n2,  # 从右边缘开始
            'x2_end': n2 - wedge_width,  # 尖灭宽度
            'direction': 'right'
        }

        # --- 3. 盐丘 ---
        params['salt_dome'] = {
            'dome_center_x2': self.rng.uniform(n2 * 0.15, n2 * 0.3),  # 盐丘中心 (在左侧)
            'dome_height': self.rng.uniform(30, 50),
            'dome_width': self.rng.uniform(40, 60),
            'i1_start_lift': self.rng.uniform(40, 60),  # 隆起起始深度
            'i1_end_lift': self.rng.uniform(180, 220)  # 隆起结束深度
        }

        # --- 4. 断层 ---
        fault_start_depth = self.rng.uniform(10, 30)
        fault_end_depth = self.rng.uniform(180, 220)

        # 4a. 断层 1 (普通断层，在模型中间)
        params['fault1'] = {
            'x2_ref': self.rng.uniform(n2 * 0.45, n2 * 0.55),
            'dip_top': self.rng.uniform(-60, -40),
            'dip_bottom': self.rng.uniform(20, 40),
            'throw': self.rng.uniform(10, 20),
            'i1_start': fault_start_depth,
            'i1_end': fault_end_depth,
            'growth_factor': 1.0  # 无生长
        }

        # 4b. 断层 2 (生长断层, 靠近盐丘，模拟盐丘相关的塌陷)
        # 逻辑：位置在盐丘的右侧
        salt_right_edge = params['salt_dome']['dome_center_x2'] + params['salt_dome']['dome_width']
        params['fault2'] = {
            'x2_ref': salt_right_edge + self.rng.uniform(40, 80),
            'dip_top': self.rng.uniform(-60, -40),  # 倾向盐丘
            'dip_bottom': self.rng.uniform(10, 20),
            'throw': self.rng.uniform(10, 15),
            'i1_start': fault_start_depth,
            'i1_end': fault_end_depth,
            'growth_factor': self.rng.uniform(1.15, 1.30)  # 有生长
        }

        # 4c. 断层 3 (大型裂谷断层，带拖曳效应，在模型右侧)
        params['fault3'] = {
            'x2_ref': self.rng.uniform(n2 * 0.8, n2 * 0.9),
            'dip_top': self.rng.uniform(80, 90),  # 陡峭
            'dip_bottom': self.rng.uniform(30, 50),  # 变缓
            'throw': self.rng.uniform(25, 40),
            'i1_start': fault_start_depth,
            'i1_end': n1,  # 延伸到底部
            'growth_factor': 1.0  # 无生长
        }

        # 4d. 断层 3 的拖曳效应
        params['flexure3'] = {
            'flexure_width': self.rng.uniform(30, 50),
            'max_flexure_depth_shift': self.rng.uniform(20, 35)
        }

        # --- 5. 衰减带参数 (所有断层共用) ---
        params['zone'] = {
            'zone_width': self.rng.uniform(6, 10),
            'blur_sigma': self.rng.uniform(0.3, 0.7),
            'attenuation_factor': self.rng.uniform(0.3, 0.6)
        }

        # --- 6. 垂向剪切 ---
        params['shear'] = {
            'scale': self.rng.uniform(0.03, 0.08)
        }

        return params

    def seismic_and_slopes_2d(self, n1=256, n2=512, noise=0, params=None):

        # 1. 创建基础反射系数
        reflectivity = self._make_reflectivity_2d(n1, n2)

        # (修改) 如果没有提供参数，则使用一组固定的默认值（用于调试）
        if params is None:
            # (使用您上一版代码中的硬编码值作为默认值)
            params = self.generate_plausible_parameters(n1, n2)
            # (为了简化，我们直接调用生成器。在实际应用中，这里可以放一组固定的默认值)

        # 应用分层褶皱
        p_fold = params['folding']
        lower_params = {'a1': 0, 'b1': p_fold['lower_amp'], 'a2': 5e-5, 'b2': p_fold['lower_freq_b']}
        upper_params = {'a1': 0, 'b1': p_fold['upper_amp'], 'a2': 8e-4, 'b2': p_fold['upper_freq_b']}

        reflectivity = self._apply_sinusoidal_fold_2d_layered(
            reflectivity, n1, n2,
            boundary_i1=p_fold['boundary_i1'],
            upper_params=upper_params,
            lower_params=lower_params
        )

        # --- 2.5. 模拟地层尖灭 ---
        reflectivity = self._apply_stratigraphic_wedge_2d(
            reflectivity, n1, n2, **params['wedge']
        )

        #  模拟盐丘上拱
        reflectivity = self._apply_salt_dome_2d(
            reflectivity, n1, n2, **params['salt_dome']
        )

        zone_params = params['zone']

        # 4. 应用弯曲的铲状断层

        # --- 断层 1 ---
        fault1_params = params['fault1']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault1_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault1_params, **zone_params)

        # --- 断层 2 (生长断层) ---
        fault2_params = params['fault2']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault2_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault2_params, **zone_params)

        # --- 断层 3 (大断层) ---
        fault3_params = params['fault3']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault3_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault3_params, **zone_params)

        # --- 5.5. 应用断层拖曳 (断层3) ---
        # 组合 fault3 和 flexure3 的参数
        flexure_params = {**fault3_params, **params['flexure3']}
        reflectivity = self._apply_geometric_flexure_2d(
            reflectivity, n1, n2, **flexure_params
        )

        reflectivity = self._apply_vertical_shear_2d(
            reflectivity, n1, n2, **params['shear']
        )

        # 6. 归一化和添加噪声
        image = reflectivity
        image = image / np.std(image)  # 归一化

        if noise > 0:
            noise_array = self.rng.randn(*image.shape)
            noise_array = gaussian_filter(noise_array, sigma=2.0, order=1)
            noise_array = noise_array * noise * np.std(image) / np.std(noise_array)
            image = image + noise_array

        return image

    def _make_reflectivity_2d(self, n1, n2):
        r = 2.0 * self.rng.rand(n1) - 1.0
        r = np.sign(r) * np.abs(r) ** 5
        reflectivity = np.tile(r[:, np.newaxis], (1, n2)).T
        return reflectivity

    def _apply_vertical_shear_2d(self, data, n1, n2, scale=0.05):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([
            i2.astype(float),  # 横向坐标不变
            np.clip(i1 - scale * i2, 0, n1 - 1)  # 深度坐标剪切并裁剪
        ])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_stratigraphic_wedge_2d(self, data, n1, n2, i1_start, i1_end, x2_start, x2_end, direction='left'):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        x2_min = min(x2_start, x2_end)
        x2_max = max(x2_start, x2_end)
        x2_width = x2_max - x2_min
        if x2_width <= 0:
            return data
        x2_active = np.clip(i2, x2_min, x2_max)
        if direction == 'left':
            attenuation_factor = (x2_active - x2_min) / x2_width
        elif direction == 'right':
            attenuation_factor = 1.0 - (x2_active - x2_min) / x2_width
        else:
            return data
        wedge_mask = depth_mask & (i2 >= x2_min) & (i2 < x2_max)
        data[wedge_mask] *= attenuation_factor[wedge_mask]
        return data

    def _apply_sinusoidal_fold_2d_layered(self, data, n1, n2, boundary_i1, upper_params, lower_params):
        i1_range, i2_range = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        shift = np.zeros_like(i1_range, dtype=float)
        mask_upper = (i1_range < boundary_i1)
        up = upper_params
        shift[mask_upper] = (up['a1'] + up['b1'] * i1_range[mask_upper]) * \
                            np.sin((up['a2'] + up['b2'] * i2_range[mask_upper]) * i2_range[mask_upper])
        mask_lower = (i1_range >= boundary_i1)
        low = lower_params
        shift[mask_lower] = (low['a1'] + low['b1'] * i1_range[mask_lower]) * \
                            np.sin((low['a2'] + low['b2'] * i2_range[mask_lower]) * i2_range[mask_lower])
        x1_new = i1_range - shift
        coords = np.zeros((2, n2, n1))
        coords[0, :, :] = i2_range
        coords[1, :, :] = np.clip(x1_new, 0, n1 - 1)
        return map_coordinates(data, coords.reshape(2, n2, n1), order=3, mode='nearest')

    def _apply_salt_dome_2d(self, data, n1, n2, dome_center_x2, dome_height, dome_width, i1_start_lift=0,
                            i1_end_lift=None):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        if i1_end_lift is None:
            i1_end_lift = n1
        n1_effective = i1_end_lift - i1_start_lift
        if n1_effective <= 0:
            return data
        i1_offset = np.maximum(0, i1 - i1_start_lift)
        i1_norm_raw = i1_offset / n1_effective
        i1_norm_clamped = np.clip(i1_norm_raw, 0, 1)
        uplift_scale = 4 * i1_norm_clamped * (1 - i1_norm_clamped)
        shift = dome_height * np.exp(-((i2 - dome_center_x2) ** 2) / (2 * dome_width ** 2)) * uplift_scale
        src_i1 = np.clip(i1 + shift, 0, n1 - 1)
        src_i2 = i2.astype(float)
        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_curved_normal_fault_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, throw, i1_start, i1_end,
                                      growth_factor=1.0):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([i2.astype(float), i1.astype(float)])
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        if dip_top > 0:
            downthrown_mask = (i2 > fault_x2_trace[np.newaxis, :])
        else:
            downthrown_mask = (i2 < fault_x2_trace[np.newaxis, :])
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        fault_mask = downthrown_mask & depth_mask
        i1_offset_from_start = coords[1][fault_mask] - i1_start
        growth_displacement = i1_offset_from_start * (growth_factor - 1.0)
        total_displacement = throw + growth_displacement
        src_i1 = coords[1][fault_mask] - total_displacement
        coords[1][fault_mask] = np.clip(src_i1, 0, n1 - 1)
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_fault_zone_attenuation_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom,
                                         zone_width, blur_sigma, attenuation_factor, i1_start, i1_end, **kwargs):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        fault_x2_trace_grid = fault_x2_trace[np.newaxis, :]
        dist_to_fault = np.abs(i2 - fault_x2_trace_grid)
        zone_mask_proximity = (dist_to_fault <= zone_width / 2.0)
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        zone_mask = zone_mask_proximity & depth_mask
        if np.any(zone_mask):
            blurred_data = gaussian_filter(data, sigma=blur_sigma)
            data[zone_mask] = blurred_data[zone_mask]
            data[zone_mask] *= attenuation_factor
        return data

    def _apply_geometric_flexure_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, i1_start, i1_end,
                                    flexure_width, max_flexure_depth_shift, **kwargs):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        if dip_top > 0:
            is_downthrown = (i2 > fault_x2_trace[np.newaxis, :])
            dist_to_fault = i2 - fault_x2_trace[np.newaxis, :]
            shift_direction = -1
        else:
            is_downthrown = (i2 < fault_x2_trace[np.newaxis, :])
            dist_to_fault = fault_x2_trace[np.newaxis, :] - i2
            shift_direction = -1
        dist_clamped = np.clip(dist_to_fault, 0, flexure_width)
        horizontal_weight = (flexure_width - dist_clamped) / flexure_width
        i1_norm = np.clip((i1 - i1_start) / (i1_end - i1_start + 1e-6), 0, 1)
        depth_weight = i1_norm
        flexure_shift = (
                max_flexure_depth_shift * horizontal_weight * depth_weight * shift_direction
        )
        flexure_mask = is_downthrown & (dist_to_fault > 0) & (dist_to_fault < flexure_width) & (i1 >= i1_start) & (
                i1 < i1_end)
        src_i1 = i1.astype(float)
        src_i2 = i2.astype(float)
        src_i1[flexure_mask] = np.clip(src_i1[flexure_mask] + flexure_shift[flexure_mask], 0, n1 - 1)
        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')


    def convolve_with_wavelet(self, image, wavelet):
        """
        对每条道进行 1D 卷积（沿 X1，即 axis=1）
        image: shape (n2, n1)
        wavelet: 1D Ricker wavelet
        """
        n2, n1 = image.shape
        output = np.zeros_like(image)

        # 对每一条道进行卷积
        for i2 in range(n2):
            output[i2, :] = np.convolve(image[i2, :], wavelet, mode='same')

        return output


# --- 绘图函数 (修改：接受标题) ---
def plot_2d_result(image, title='Seismic Image (Geological Model - No Convolution)'):
    """(修改) 绘图函数，接受自定义标题"""
    fig, axes = plt.subplots(1, 1, figsize=(12, 7))
    axes.imshow(image.T, cmap='gray', aspect='auto', origin='upper')
    axes.set_title(title)
    axes.set_xlabel('X2')
    axes.set_ylabel('X1 (Depth)')
    plt.tight_layout()
    plt.show()

def plot_wavelets_by_phase(frequency, phases_deg, dt=0.004, length=0.256, title=None):
    fig, ax = plt.subplots(1, 1, figsize=(10, 4))
    for ph in phases_deg:
        t, w = ricker_wavelet_with_phase(frequency=frequency, phase_deg=ph, dt=dt, length=length, return_t=True)
        ax.plot(t, w, label=f"{ph}°")
    ax.axhline(0, linewidth=1)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Amplitude")
    ax.set_title(title or f"Ricker wavelets with phase rotation (f0={frequency} Hz)")
    ax.legend(ncol=4, fontsize=9)
    plt.tight_layout()
    plt.show()

def downsample_x2(img):
    # (512,512) -> (256,256)
    return zoom(img, zoom=(0.5, 0.5), order=1).astype(np.float32)  # order=1 双线性

# ======================================================================
# HQ/LQ noise-free synthetic seismic record generation
# - HQ: reflectivity convolved with a conventional 50-Hz Ricker wavelet
# - LQ: reflectivity convolved with a conventional 30-Hz Ricker wavelet
# - No noise, no Q filtering, no extra attenuation, no downsampling
# - Save grayscale SVG figures
# ======================================================================

import argparse
from pathlib import Path


def ricker_wavelet(frequency=50.0, dt=0.004, length=0.256):
    """
    Conventional zero-phase Ricker wavelet.

    Parameters
    ----------
    frequency : float
        Dominant frequency in Hz.
    dt : float
        Sampling interval in seconds.
    length : float
        Total wavelet length in seconds.
    """
    t = np.arange(-length / 2.0, length / 2.0 + dt, dt, dtype=np.float64)
    a = (np.pi * float(frequency) * t) ** 2
    w = (1.0 - 2.0 * a) * np.exp(-a)
    w = w / (np.max(np.abs(w)) + 1.0e-12)
    return w.astype(np.float32)


def convolve_along_depth_fft(image, wavelet):
    """
    Convolve each trace with the wavelet along the depth/time axis.

    The input section follows the convention used in the original script:
        image.shape = (n2, n1), where axis=0 is X2 and axis=1 is depth/time.
    """
    image = np.asarray(image, dtype=np.float32)
    wavelet = np.asarray(wavelet, dtype=np.float32)
    n2, n1 = image.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))

    image_f = np.fft.rfft(image, n=nfft, axis=1)
    wavelet_f = np.fft.rfft(wavelet, n=nfft)
    out = np.fft.irfft(image_f * wavelet_f[None, :], n=nfft, axis=1)

    start = (nw - 1) // 2
    return out[:, start:start + n1].astype(np.float32)


def standardize_pair(hq, lq):
    """
    Remove mean and use a common amplitude scale for HQ/LQ display consistency.
    """
    hq = np.asarray(hq, dtype=np.float32)
    lq = np.asarray(lq, dtype=np.float32)

    hq = hq - np.mean(hq)
    lq = lq - np.mean(lq)

    scale = max(float(np.percentile(np.abs(hq), 99.5)), float(np.percentile(np.abs(lq), 99.5)), 1.0e-12)
    hq = hq / scale
    lq = lq / scale
    return hq.astype(np.float32), lq.astype(np.float32)


def save_gray_svg(section, out_path, clip_percentile=99.0, with_axes=False, xlabel='X2', ylabel='X1'):
    """
    Save a seismic section as a grayscale SVG figure.

    Note: seismic sections are image-like arrays; matplotlib stores the section
    as an embedded raster image inside the SVG container, while text/axes remain
    vector objects if axes are enabled.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    section = np.asarray(section, dtype=np.float32)
    vmax = float(np.percentile(np.abs(section), clip_percentile))
    vmax = vmax if vmax > 0 else 1.0

    # 4 in × 4 in at 128 dpi corresponds to a 512 × 512 display canvas.
    fig, ax = plt.subplots(figsize=(4.0, 4.0), dpi=128)
    ax.imshow(
        section.T,
        cmap='gray',
        vmin=-vmax,
        vmax=vmax,
        aspect='auto',
        origin='upper',
        interpolation='nearest',
    )

    if with_axes:
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
    else:
        ax.set_axis_off()
        ax.set_position([0.0, 0.0, 1.0, 1.0])

    fig.savefig(out_path, format='svg', bbox_inches='tight' if with_axes else None, pad_inches=0.0)
    plt.close(fig)


def save_pair_gray_svg(hq, lq, out_path, clip_percentile=99.0):
    """
    Save HQ and LQ sections in one side-by-side grayscale SVG figure.
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    vmax = max(
        float(np.percentile(np.abs(hq), clip_percentile)),
        float(np.percentile(np.abs(lq), clip_percentile)),
        1.0e-12,
    )

    plt.rcParams.update({
        'font.family': 'Times New Roman',
        'svg.fonttype': 'none',
    })

    fig, axes = plt.subplots(1, 2, figsize=(8.0, 4.0), dpi=128)
    for ax, data, title in zip(axes, [hq, lq], ['HQ: 50 Hz Ricker', 'LQ: 30 Hz Ricker']):
        ax.imshow(
            data.T,
            cmap='gray',
            vmin=-vmax,
            vmax=vmax,
            aspect='auto',
            origin='upper',
            interpolation='nearest',
        )
        ax.set_title(title, fontsize=12)
        ax.set_xticks([])
        ax.set_yticks([])

    fig.tight_layout(pad=0.2, w_pad=0.3)
    fig.savefig(out_path, format='svg', bbox_inches='tight', pad_inches=0.01)
    plt.close(fig)


def parse_args():
    parser = argparse.ArgumentParser(
        description='Generate noise-free HQ/LQ synthetic seismic records and save grayscale SVG figures.'
    )
    parser.add_argument('--num_images', type=int, default=10, help='Number of samples to generate. Default: 10.')
    parser.add_argument('--n1', type=int, default=256, help='Depth/time samples. Default: 512.')
    parser.add_argument('--n2', type=int, default=256, help='Lateral samples. Default: 512.')
    parser.add_argument('--start_seed', type=int, default=0, help='First random seed. Default: 0.')
    parser.add_argument('--dt', type=float, default=0.004, help='Sampling interval in seconds. Default: 0.004.')
    parser.add_argument('--wavelet_length', type=float, default=0.256, help='Ricker wavelet length in seconds. Default: 0.256.')
    parser.add_argument('--hq_freq', type=float, default=40.0, help='HQ Ricker dominant frequency in Hz. Default: 40.')
    parser.add_argument('--lq_freq', type=float, default=20.0, help='LQ Ricker dominant frequency in Hz. Default: 20.')
    parser.add_argument('--out_dir', type=str, default='hq_lq_synthetic_svg', help='Output folder.')
    parser.add_argument('--clip_percentile', type=float, default=99.0, help='Symmetric display clipping percentile. Default: 99.')
    parser.add_argument('--with_axes', action='store_true', help='Save separate HQ/LQ SVG files with axes.')
    parser.add_argument('--save_pair', action='store_true', help='Also save side-by-side HQ/LQ SVG previews.')
    parser.add_argument('--save_dat', action='store_true', help='Also save HQ/LQ float32 .dat files.')
    return parser.parse_args()


def main():
    args = parse_args()
    out_root = Path(args.out_dir)
    hq_svg_dir = out_root / 'hq_svg'
    lq_svg_dir = out_root / 'lq_svg'
    pair_svg_dir = out_root / 'pair_svg'
    hq_dat_dir = out_root / 'hq_dat'
    lq_dat_dir = out_root / 'lq_dat'

    hq_wavelet = ricker_wavelet(frequency=args.hq_freq, dt=args.dt, length=args.wavelet_length)
    lq_wavelet = ricker_wavelet(frequency=args.lq_freq, dt=args.dt, length=args.wavelet_length)

    print(f'Generating {args.num_images} noise-free HQ/LQ synthetic seismic records...')
    print(f'HQ wavelet: {args.hq_freq:g} Hz Ricker')
    print(f'LQ wavelet: {args.lq_freq:g} Hz Ricker')
    print(f'Output: {out_root.resolve()}')

    for i in range(args.num_images):
        seed = args.start_seed + i
        generator = GeologicalSeismicData(seed=seed)
        params = generator.generate_plausible_parameters(n1=args.n1, n2=args.n2)

        # Generate reflectivity only. No noise is added here.
        reflectivity = generator.seismic_and_slopes_2d(n1=args.n1, n2=args.n2, noise=0, params=params)

        # HQ/LQ synthetic records: only wavelet convolution, no noise/attenuation/downsampling.
        hq = convolve_along_depth_fft(reflectivity, hq_wavelet)
        lq = convolve_along_depth_fft(reflectivity, lq_wavelet)
        hq, lq = standardize_pair(hq, lq)

        fname = f'{i + 1:04d}'
        save_gray_svg(hq, hq_svg_dir / f'{fname}_HQ_50Hz.svg', clip_percentile=args.clip_percentile, with_axes=args.with_axes)
        save_gray_svg(lq, lq_svg_dir / f'{fname}_LQ_30Hz.svg', clip_percentile=args.clip_percentile, with_axes=args.with_axes)

        if args.save_pair:
            save_pair_gray_svg(hq, lq, pair_svg_dir / f'{fname}_HQ_LQ_pair.svg', clip_percentile=args.clip_percentile)

        if args.save_dat:
            hq_dat_dir.mkdir(parents=True, exist_ok=True)
            lq_dat_dir.mkdir(parents=True, exist_ok=True)
            hq.astype(np.float32).tofile(hq_dat_dir / f'{fname}_HQ_50Hz.dat')
            lq.astype(np.float32).tofile(lq_dat_dir / f'{fname}_LQ_30Hz.dat')

        print(f'[{i + 1}/{args.num_images}] saved sample {fname}, seed={seed}')

    print('All done.')


if __name__ == '__main__':
    main()

