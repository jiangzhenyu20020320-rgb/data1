# -*- coding: utf-8 -*-
r"""
Multi-structure time-space-varying Ormsby waveform-preserving bandwidth-extension dataset generator.

V6-weaker-checked: weaker time-varying Ormsby fields and built-in LQ/GT pair-alignment self-check.

目标：
- 多结构 + Ormsby 子波
- time-space-varying wavelet: 子波参数同时随深度/时间 t 和横向位置 x 变化
- 无噪声、同尺寸 LQ/GT（512x512 -> 512x512）
- LQ/GT 同源：每个局部 (x,t) 位置的 GT Ormsby 频带包络 LQ Ormsby 频带

使用方式：
把本脚本放到和以下构造生成脚本同一个文件夹：
  dongyingbatch.py
  helanjinhaiyanpendi.py
  huazhuang.py
  malinbatch_noise_dat.py
  malinbatchnewfold&noise&q.py
  tixingyanqiubatch_noise_dat.py

运行：
  python multi_structure_timespace_ormsby_bwe_v6_weaker_checked.py

输出：
  dataset_waveform_bwe_multistruct_timespace_ormsby_v6_weaker_checked/
    lq/*.dat
    gt/*.dat
    meta/*.json
    wavelets/*_w_lq.npy
    wavelets/*_w_gt.npy
    wavelets/*_wavelet_field.npz
    qc/*.png
    sample_index.csv
    sample_count.json
"""

import csv
import json
import shutil
import importlib.util
from pathlib import Path
from collections import Counter

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert


# =========================================================
# 0. 配置区：主要改这里
# =========================================================
SCRIPT_DIR = Path(__file__).resolve().parent

SOURCE_SCRIPTS = [
    {"name": "dongying",        "file": "dongyingbatch.py"},
    {"name": "helan_basin",     "file": "helanjinhaiyanpendi.py"},
    {"name": "huazhuang",       "file": "huazhuang.py"},
    {"name": "malin",           "file": "malinbatch_noise_dat.py"},
    {"name": "malin_newfold",   "file": "malinbatchnewfold&noise&q.py"},
    {"name": "tixing_salt",     "file": "tixingyanqiubatch_noise_dat.py"},
]

# 第一版先小规模 QC。满意后再改成 20、300 或 500。
NUM_PER_STRUCTURE = 500

# 输出尺寸：注意本项目的反射模型通常为 [trace, sample] = [N2, N1]
N1 = 512  # sample/depth/time axis
N2 = 512  # trace/x axis

DT = 0.004  # Nyquist = 125 Hz; sufficient for GT f4 <= 90 Hz
WAVELET_LENGTH = 0.256

# 时空变非平稳卷积参数
# TIME_WIN/TIME_STEP 控制纵向时变平滑程度；X_GROUP 控制横向空变精度。
TIME_WIN = 128
TIME_STEP = 32
X_GROUP = 8

OUT_DIR = SCRIPT_DIR / "dataset_waveform_bwe_multistruct_timespace_ormsby_v6_weaker_checked"
LQ_DIR = OUT_DIR / "lq"
GT_DIR = OUT_DIR / "gt"
META_DIR = OUT_DIR / "meta"
WAVELET_DIR = OUT_DIR / "wavelets"
QC_DIR = OUT_DIR / "qc"

START_INDEX = 1
RANDOM_SEED = 2026
COPY_SOURCE_SCRIPTS = True

# 为避免旧文件残留导致后续 merge 时出现“同名但不同源”的错配，默认每次运行前清空输出目录。
RESET_OUTPUT_DIR = True

# 生成时进行 LQ/GT 配对自检。若检测到明显方向/配对异常，会自动换 seed 重试。
STRICT_PAIR_CHECK = True
MAX_PAIR_RETRY = 12
PAIR_SAME_CORR_MIN = 0.12
PAIR_ORIENTATION_MARGIN = 0.08

# QC 中展示 3x3 代表位置：left/middle/right × top/middle/bottom
REP_XS = [0.15, 0.50, 0.85]
REP_DEPTHS = [0.15, 0.50, 0.85]
REP_X_NAMES = ["left", "middle", "right"]
REP_D_NAMES = ["top", "middle", "bottom"]

# 相位：第一版建议常相位 + 很弱的二维漂移，避免相位变化掩盖频带规律。
PHASE_PROB = 0.50
PHASE_RANGE = (-30.0, 30.0)
PHASE_DEPTH_DRIFT_RANGE = (-6.0, 6.0)
PHASE_X_DRIFT_RANGE = (-5.0, 5.0)

# QC 保存策略
QC_FIRST_N = 8
QC_EVERY = 50

# =========================================================
# 0.1 频率分布形态控制：更宽频率范围 + 类速度模型的复杂平滑频率场
# =========================================================
# 设计目标：
# 1) 整体仍然浅层高频、深层低频；
# 2) 频率边界不再是直线/单一斜坡，而是有平滑起伏、透镜体、低频槽等形态；
# 3) LQ f3 控制在约 22-40 Hz；GT f3 控制在约 56-70 Hz。

# 横向/二维模式：None 表示随机；也可固定为：
# "right_high_wavy", "left_high_wavy", "middle_high_lens", "middle_low_channel", "two_anomalies", "tilted_fault_like"
SPACE_PATTERN_FORCE_MODE = None
SPACE_PATTERN_POOL = [
    "right_high_wavy",
    "left_high_wavy",
    "middle_high_lens",
    "middle_low_channel",
    "two_anomalies",
    "tilted_fault_like",
]

# 这一版直接控制 QC 中展示的 f3 参数：
# - LQ f3: 约 22-40 Hz，抬高底层频率以减弱时变
# - GT f3: 约 56-70 Hz，保留拓频但避免深部过强差异
# 注意：Ormsby 必须满足 f1 < f2 < f3 < f4，因此 f4 会在 f3 基础上自动向右留出过渡带。
LQ_F3_MIN_RANGE = (15.0, 20.0)
LQ_F3_MAX_RANGE = (35.0, 39.0)
GT_F3_MIN_RANGE = (56.0, 60.0)
GT_F3_MAX_RANGE = (66.0, 70.0)

# f4 只作为 f3 后的高频滚降终点，不再作为 QC 主控参数。
# gap 越大，高频滚降段越宽；gap 太小容易让波形振铃更明显。
LQ_F4_GAP_RANGE = (3.0, 6.0)
GT_F4_GAP_RANGE = (7.0, 13.0)
GT_F4_HARD_RANGE = (62.0, 88.0)

# 复杂频率场强度。越大，等频率边界越像“速度模型”中的起伏界面。
DEPTH_TREND_POWER_RANGE = (0.95, 1.35)
X_TREND_STRENGTH_RANGE = (0.06, 0.16)
WAVE_STRENGTH_RANGE = (0.04, 0.11)
BUMP_STRENGTH_RANGE = (0.05, 0.15)
CHANNEL_STRENGTH_RANGE = (0.04, 0.12)

# 高频角点局部扰动，主要影响 f3/f4，不明显扰动 f1/f2。
HF_DETAIL_LQ_F3 = 0.38
HF_DETAIL_LQ_F4 = 0.50
HF_DETAIL_GT_F3 = 0.45
HF_DETAIL_GT_F4 = 0.75

# 锚点随机扰动：V6 降低扰动，避免局部子波差异过强导致 LQ/GT 视觉相关性过低。
LQ_BAND_NOISE = [0.06, 0.08, 0.16, 0.25]
GT_BAND_NOISE = [0.05, 0.07, 0.20, 0.35]


# =========================================================
# 1. 基础工具函数
# =========================================================
def ensure_dirs():
    if RESET_OUTPUT_DIR and OUT_DIR.exists():
        print(f"[RESET] Removing old output directory to avoid stale/mismatched files: {OUT_DIR}")
        shutil.rmtree(OUT_DIR)
    for d in [LQ_DIR, GT_DIR, META_DIR, WAVELET_DIR, QC_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def sanitize_float(x):
    return float(np.asarray(x).item())


def time_axis(dt=0.004, length=0.256):
    return np.arange(-length / 2.0, length / 2.0 + 0.5 * dt, dt, dtype=np.float32)


def normalize_wavelet(w):
    w = np.asarray(w, dtype=np.float64)
    w = w - np.mean(w)
    m = np.max(np.abs(w))
    if m > 1e-12:
        w = w / m
    return w.astype(np.float32)


def phase_rotate(w, phase_deg=0.0):
    w = np.asarray(w, dtype=np.float64)
    if abs(float(phase_deg)) < 1e-12:
        return normalize_wavelet(w)
    wh = np.imag(hilbert(w))
    phi = np.deg2rad(float(phase_deg))
    wp = np.cos(phi) * w - np.sin(phi) * wh
    return normalize_wavelet(wp)


def centered_wavelet_from_amp(amp, n_wavelet, nfft):
    amp = np.asarray(amp, dtype=np.float64)
    amp = np.maximum(amp, 0.0)
    amp[0] = 0.0
    w_full = np.fft.irfft(amp.astype(np.complex128), n=nfft)
    w_full = np.fft.fftshift(w_full)
    center = nfft // 2
    half = n_wavelet // 2
    start = center - half
    w = w_full[start:start + n_wavelet]
    return normalize_wavelet(w)


def high_frequency_taper(freqs, f_start=105.0, f_end=120.0):
    taper = np.ones_like(freqs, dtype=np.float64)
    taper[freqs >= f_end] = 0.0
    m = (freqs > f_start) & (freqs < f_end)
    if np.any(m):
        x = (freqs[m] - f_start) / (f_end - f_start + 1e-12)
        taper[m] = 0.5 + 0.5 * np.cos(np.pi * x)
    return taper


def smooth_max(a, b, p=10.0):
    a = np.maximum(np.asarray(a, dtype=np.float64), 0.0)
    b = np.maximum(np.asarray(b, dtype=np.float64), 0.0)
    return (a ** p + b ** p) ** (1.0 / p)


def trapezoid_amp(freqs, f1, f2, f3, f4):
    freqs = np.asarray(freqs, dtype=np.float64)
    amp = np.zeros_like(freqs, dtype=np.float64)

    m = (freqs >= f1) & (freqs < f2)
    if np.any(m):
        amp[m] = (freqs[m] - f1) / (f2 - f1 + 1e-12)

    amp[(freqs >= f2) & (freqs <= f3)] = 1.0

    m = (freqs > f3) & (freqs <= f4)
    if np.any(m):
        amp[m] = 1.0 - (freqs[m] - f3) / (f4 - f3 + 1e-12)

    return np.clip(amp, 0.0, 1.0)


def amplitude_spectrum(w, dt=0.004, nfft=4096):
    w = np.asarray(w, dtype=np.float32)
    W = np.fft.rfft(w, n=nfft)
    amp = np.abs(W)
    amp = amp / (np.max(amp) + 1e-12)
    f = np.fft.rfftfreq(nfft, d=dt)
    return f, amp


def fix_lq_band(b):
    """Protect LQ Ormsby band while targeting a weaker time-varying f3 range around 22-40 Hz."""
    f1, f2, f3, f4 = [float(x) for x in b]

    # LQ f3 is the requested QC parameter range.
    f3 = float(np.clip(f3, 22.0, 40.0))

    # Low-side corners follow f3 but remain physically ordered.
    f1 = float(np.clip(f1, 0.5, min(10.0, f3 - 4.0)))
    f2 = max(f2, f1 + 0.8)
    f2 = min(f2, f3 - 3.0)

    # f4 is only the high-frequency roll-off end; it must be higher than f3.
    f4 = max(f4, f3 + 2.5)
    f4 = float(np.clip(f4, 18.0, 50.0))

    # Final ordering protection.
    if f2 <= f1 + 0.7:
        f2 = f1 + 0.7
    if f3 <= f2 + 2.5:
        f3 = f2 + 2.5
    if f4 <= f3 + 2.0:
        f4 = f3 + 2.0

    # Keep requested f3 target after protection.
    f3 = float(np.clip(f3, 22.0, 40.0))
    f2 = min(f2, f3 - 2.5)
    f1 = min(f1, f2 - 0.7)
    f4 = float(np.clip(max(f4, f3 + 2.0), 18.0, 50.0))

    return np.array([f1, f2, f3, f4], dtype=np.float64)

def fix_gt_band(b, lq_b):
    """Protect GT band and force broadband envelope over the local LQ band.

    This version targets a milder GT f3 range around 56-70 Hz, so the high-frequency passband
    end is clearly higher than the LQ f3 range.
    """
    f1, f2, f3, f4 = [float(x) for x in b]
    lq_b = np.asarray(lq_b, dtype=np.float64)

    # Low-frequency side extends below LQ.
    f1 = max(0.2, min(f1, lq_b[0] - 0.8))
    f2 = max(f2, f1 + 0.8)
    f2 = min(f2, lq_b[1] - 0.5)

    # Main request: push GT f3 to 50-70 Hz.
    f3 = float(np.clip(f3, 56.0, 70.0))
    f3 = max(f3, lq_b[2] + 8.0)
    f3 = float(np.clip(f3, 56.0, 70.0))

    # f4 is the roll-off end after f3.
    f4 = max(f4, f3 + 6.0)
    f4 = float(np.clip(f4, GT_F4_HARD_RANGE[0], GT_F4_HARD_RANGE[1]))

    # Final legal ordering protection.
    if f2 <= f1 + 0.7:
        f2 = f1 + 0.7
    if f3 <= f2 + 8.0:
        f3 = f2 + 8.0
    if f4 <= f3 + 5.0:
        f4 = f3 + 5.0

    # Keep requested high-frequency target after protection.
    f3 = float(np.clip(f3, 56.0, 70.0))
    f4 = float(np.clip(max(f4, f3 + 5.0), GT_F4_HARD_RANGE[0], GT_F4_HARD_RANGE[1]))

    return np.array([f1, f2, f3, f4], dtype=np.float64)

def ormsby_pair_from_bands(band_lq, band_gt, phase_deg, dt=0.004, length=0.256):
    n = len(time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)

    A_lq = trapezoid_amp(freqs, *band_lq)
    A_gt_raw = trapezoid_amp(freqs, *band_gt)
    A_gt = smooth_max(A_gt_raw, A_lq, p=10.0)
    A_gt *= high_frequency_taper(freqs, f_start=105.0, f_end=120.0)
    A_gt[0] = 0.0
    A_gt = A_gt / (np.max(A_gt) + 1e-12)

    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)
    return phase_rotate(w_lq0, phase_deg), phase_rotate(w_gt0, phase_deg)


# =========================================================
# 2. Ormsby 时空变参数场
# =========================================================
def make_space_profile(rng, x_anchors):
    """
    返回横向 profile，中心值约为 1；>1 表示频带较高，<1 表示频带较低。

    V2-wavy 默认使用 right_high：右侧整体高频、左侧整体低频；
    同时保留轻微随机扰动，避免所有样本完全一致。
    """
    if SPACE_PROFILE_FORCE_MODE is None:
        mode = str(rng.choice(["left_high", "right_high", "middle_high", "middle_low"]))
    else:
        mode = str(SPACE_PROFILE_FORCE_MODE)

    amp = float(rng.uniform(SPACE_PROFILE_AMP_RANGE[0], SPACE_PROFILE_AMP_RANGE[1]))

    if mode == "left_high":
        prof = np.linspace(1.0 + amp, 1.0 - amp, len(x_anchors))
    elif mode == "right_high":
        prof = np.linspace(1.0 - amp, 1.0 + amp, len(x_anchors))
    elif mode == "middle_high":
        prof = 1.0 + amp * np.exp(-((x_anchors - 0.5) / 0.28) ** 2)
        prof = prof - (np.mean(prof) - 1.0)
    elif mode == "middle_low":
        prof = 1.0 - amp * np.exp(-((x_anchors - 0.5) / 0.28) ** 2)
        prof = prof - (np.mean(prof) - 1.0)
    else:
        raise ValueError(mode)

    # 很弱扰动，增强样本多样性；再约束范围。
    prof += rng.normal(0.0, SPACE_PROFILE_NOISE_STD, size=len(x_anchors))
    prof = np.clip(prof, SPACE_PROFILE_CLIP[0], SPACE_PROFILE_CLIP[1])
    return prof.astype(np.float64), mode, amp


def make_depth_warp_profile(rng, x_anchors, profile_mode):
    """
    构造横向方向的“等效深度偏移” depth_warp(x)。

    目的：
    - 保持浅层高频、深层低频的大趋势；
    - 但让等频率分界线产生平滑起伏，不再是规则直线/斜坡。

    depth_warp > 0：该 x 位置使用更浅的等效深度，频率偏高；
    depth_warp < 0：该 x 位置使用更深的等效深度，频率偏低。
    """
    x01 = np.asarray(x_anchors, dtype=np.float64)

    if profile_mode == "right_high":
        main_trend = np.linspace(-1.0, 1.0, len(x01))
    elif profile_mode == "left_high":
        main_trend = np.linspace(1.0, -1.0, len(x01))
    elif profile_mode == "middle_high":
        main_trend = np.exp(-((x01 - 0.5) / 0.28) ** 2)
        main_trend = main_trend - np.mean(main_trend)
        main_trend = main_trend / (np.max(np.abs(main_trend)) + 1e-12)
    elif profile_mode == "middle_low":
        main_trend = -np.exp(-((x01 - 0.5) / 0.28) ** 2)
        main_trend = main_trend - np.mean(main_trend)
        main_trend = main_trend / (np.max(np.abs(main_trend)) + 1e-12)
    else:
        main_trend = np.zeros_like(x01)

    phase1 = float(rng.uniform(0.0, 2.0 * np.pi))
    phase2 = float(rng.uniform(0.0, 2.0 * np.pi))

    wave_x = (
        0.65 * np.sin(2.0 * np.pi * x01 + phase1)
        + 0.35 * np.sin(4.0 * np.pi * x01 + phase2)
    )
    wave_x = wave_x - np.mean(wave_x)
    wave_x = wave_x / (np.max(np.abs(wave_x)) + 1e-12)

    depth_warp = (
        DEPTH_WARP_RIGHT_HIGH_STRENGTH * main_trend
        + DEPTH_WARP_WAVE_STRENGTH * wave_x
    )
    depth_warp = np.clip(depth_warp, -DEPTH_WARP_CLIP, DEPTH_WARP_CLIP)

    return depth_warp.astype(np.float64), wave_x.astype(np.float64), phase1, phase2


def make_phase_grid(rng, depth_anchors, x_anchors):
    if rng.random() >= PHASE_PROB:
        phase_grid = np.zeros((len(depth_anchors), len(x_anchors)), dtype=np.float64)
        return phase_grid, 0.0

    base = float(rng.uniform(PHASE_RANGE[0], PHASE_RANGE[1]))
    if abs(base) < 3.0:
        base = 3.0 if base >= 0 else -3.0

    d_drift = float(rng.uniform(PHASE_DEPTH_DRIFT_RANGE[0], PHASE_DEPTH_DRIFT_RANGE[1]))
    x_drift = float(rng.uniform(PHASE_X_DRIFT_RANGE[0], PHASE_X_DRIFT_RANGE[1]))

    d_term = np.linspace(-0.5, 0.5, len(depth_anchors))[:, None] * d_drift
    x_term = np.linspace(-0.5, 0.5, len(x_anchors))[None, :] * x_drift
    phase_grid = base + d_term + x_term
    return phase_grid.astype(np.float64), base


def make_ormsby_timespace_wavelet_model(rng, dt=0.004, length=0.256):
    """
    V6-weaker-checked Ormsby time-space-varying wavelet model.

    Main design:
    - LQ f3 is constrained to about 22-40 Hz;
    - GT f3 is constrained to about 56-70 Hz;
    - f4 is generated as a legal high-frequency roll-off endpoint after f3;
    - frequency field is not a single smooth slope, but a velocity-model-like
      2-D field made from depth trend + lateral trend + sinusoidal undulations
      + Gaussian lenses/channels.
    """
    # More anchors give the f4 map enough degrees of freedom.
    depth_anchors = np.array([0.0, 0.12, 0.25, 0.40, 0.56, 0.72, 0.86, 1.0], dtype=np.float64)
    x_anchors = np.array([0.0, 0.10, 0.20, 0.32, 0.44, 0.56, 0.68, 0.80, 0.90, 1.0], dtype=np.float64)

    D, X = np.meshgrid(depth_anchors, x_anchors, indexing="ij")

    if SPACE_PATTERN_FORCE_MODE is None:
        pattern_mode = str(rng.choice(SPACE_PATTERN_POOL))
    else:
        pattern_mode = str(SPACE_PATTERN_FORCE_MODE)

    depth_power = float(rng.uniform(DEPTH_TREND_POWER_RANGE[0], DEPTH_TREND_POWER_RANGE[1]))
    depth_high = 1.0 - D ** depth_power  # shallow high, deep low

    x_strength = float(rng.uniform(X_TREND_STRENGTH_RANGE[0], X_TREND_STRENGTH_RANGE[1]))
    if pattern_mode == "right_high_wavy":
        x_trend = 2.0 * X - 1.0
    elif pattern_mode == "left_high_wavy":
        x_trend = 1.0 - 2.0 * X
    elif pattern_mode == "middle_high_lens":
        x_trend = np.exp(-((X - 0.50) / 0.25) ** 2)
        x_trend = (x_trend - np.mean(x_trend)) / (np.max(np.abs(x_trend - np.mean(x_trend))) + 1e-12)
    elif pattern_mode == "middle_low_channel":
        x_trend = -np.exp(-((X - 0.50) / 0.22) ** 2)
        x_trend = (x_trend - np.mean(x_trend)) / (np.max(np.abs(x_trend - np.mean(x_trend))) + 1e-12)
    elif pattern_mode == "two_anomalies":
        x_trend = 0.45 * np.sin(2.0 * np.pi * X + rng.uniform(0, 2*np.pi))
    elif pattern_mode == "tilted_fault_like":
        boundary = 0.35 + 0.30 * X + 0.06 * np.sin(2*np.pi*X + rng.uniform(0, 2*np.pi))
        x_trend = np.tanh((boundary - D) / 0.08)
    else:
        x_trend = np.zeros_like(X)

    # Wavy iso-frequency boundaries.
    wave_strength = float(rng.uniform(WAVE_STRENGTH_RANGE[0], WAVE_STRENGTH_RANGE[1]))
    ph1 = float(rng.uniform(0.0, 2.0 * np.pi))
    ph2 = float(rng.uniform(0.0, 2.0 * np.pi))
    wave_2d = (
        0.60 * np.sin(2.0 * np.pi * (X + 0.32 * D) + ph1)
        + 0.35 * np.sin(4.0 * np.pi * (X - 0.18 * D) + ph2)
        + 0.25 * np.sin(2.0 * np.pi * (D + 0.25 * X) + 0.5 * ph1)
    )
    wave_2d = wave_2d / (np.max(np.abs(wave_2d)) + 1e-12)

    # Velocity-model-like lenses and channels.
    anomaly = np.zeros_like(D, dtype=np.float64)
    n_bumps = int(rng.integers(2, 5))
    bump_records = []
    for _ in range(n_bumps):
        cx = float(rng.uniform(0.15, 0.85))
        cd = float(rng.uniform(0.15, 0.85))
        sx = float(rng.uniform(0.12, 0.32))
        sd = float(rng.uniform(0.10, 0.28))
        amp = float(rng.uniform(BUMP_STRENGTH_RANGE[0], BUMP_STRENGTH_RANGE[1]))
        sign = float(rng.choice([-1.0, 1.0]))
        g = np.exp(-(((X - cx) / sx) ** 2 + ((D - cd) / sd) ** 2))
        anomaly += sign * amp * g
        bump_records.append({"cx": cx, "depth": cd, "sx": sx, "sd": sd, "amp": sign * amp})

    # Optional low-frequency curved channel.
    channel_strength = float(rng.uniform(CHANNEL_STRENGTH_RANGE[0], CHANNEL_STRENGTH_RANGE[1]))
    channel_center = 0.35 + 0.30 * X + 0.06 * np.sin(2*np.pi*X + rng.uniform(0, 2*np.pi))
    channel = -channel_strength * np.exp(-((D - channel_center) / 0.10) ** 2)

    # Combine: depth trend dominates; lateral/anomaly terms deform boundaries.
    hf_norm = (
        0.58 * depth_high
        + x_strength * x_trend
        + wave_strength * wave_2d
        + 0.70 * anomaly
        + 0.70 * channel
    )

    # Robust normalization to [0,1], preserving relative variations but avoiding extreme outliers.
    lo, hi = np.percentile(hf_norm, [3.0, 97.0])
    hf_norm = (hf_norm - lo) / (hi - lo + 1e-12)
    hf_norm = np.clip(hf_norm, 0.0, 1.0)

    # Enforce broad shallow-high/deep-low trend softly: shallow rows should statistically exceed deep rows.
    hf_norm = 0.90 * hf_norm + 0.10 * depth_high
    hf_norm = np.clip(hf_norm, 0.0, 1.0)

    lq_f3_min = float(rng.uniform(LQ_F3_MIN_RANGE[0], LQ_F3_MIN_RANGE[1]))
    lq_f3_max = float(rng.uniform(LQ_F3_MAX_RANGE[0], LQ_F3_MAX_RANGE[1]))
    gt_f3_min = float(rng.uniform(GT_F3_MIN_RANGE[0], GT_F3_MIN_RANGE[1]))
    gt_f3_max = float(rng.uniform(GT_F3_MAX_RANGE[0], GT_F3_MAX_RANGE[1]))

    lq_f3_grid = lq_f3_min + (lq_f3_max - lq_f3_min) * hf_norm
    gt_f3_base = gt_f3_min + (gt_f3_max - gt_f3_min) * hf_norm

    # Add small high-frequency detail to f3; still smooth because it is evaluated on coarse anchors.
    detail = (
        np.sin(2*np.pi*(X + 0.25*D) + ph1)
        + 0.5*np.sin(4*np.pi*(X - 0.15*D) + ph2)
    ) / 1.5
    d_gate = np.sin(np.pi * D)
    lq_f3_grid = np.clip(lq_f3_grid + HF_DETAIL_LQ_F3 * detail * d_gate, 22.0, 40.0)
    gt_f3_grid = np.clip(gt_f3_base + HF_DETAIL_GT_F3 * detail * d_gate, 56.0, 70.0)

    band_lq_grid = np.zeros((len(depth_anchors), len(x_anchors), 4), dtype=np.float64)
    band_gt_grid = np.zeros_like(band_lq_grid)

    for idp in range(len(depth_anchors)):
        for ix in range(len(x_anchors)):
            d = float(depth_anchors[idp])
            h = float(hf_norm[idp, ix])
            f3_lq = float(lq_f3_grid[idp, ix])
            f3_gt = float(gt_f3_grid[idp, ix])

            # LQ band: directly target f3 in 15-40 Hz.
            f1_lq = 0.12 * f3_lq + rng.normal(0.0, LQ_BAND_NOISE[0])
            f2_lq = 0.36 * f3_lq + rng.normal(0.0, LQ_BAND_NOISE[1])
            f3_lq = f3_lq + rng.normal(0.0, LQ_BAND_NOISE[2])
            f4_lq = f3_lq + rng.uniform(LQ_F4_GAP_RANGE[0], LQ_F4_GAP_RANGE[1]) + rng.normal(0.0, LQ_BAND_NOISE[3])
            lq_b = fix_lq_band([f1_lq, f2_lq, f3_lq, f4_lq])

            # GT is derived from local LQ and the same hf_norm field, so it remains paired/aligned.
            low_margin = 1.5 + 1.5 * h
            f1_gt = lq_b[0] - low_margin + rng.normal(0.0, GT_BAND_NOISE[0])
            f2_gt = lq_b[1] - (1.0 + 1.0 * h) + rng.normal(0.0, GT_BAND_NOISE[1])
            f3_gt = max(f3_gt + rng.normal(0.0, GT_BAND_NOISE[2]), lq_b[2] + 8.0)
            f4_gt = f3_gt + rng.uniform(GT_F4_GAP_RANGE[0], GT_F4_GAP_RANGE[1]) + rng.normal(0.0, GT_BAND_NOISE[3])
            gt_b = fix_gt_band([f1_gt, f2_gt, f3_gt, f4_gt], lq_b)

            band_lq_grid[idp, ix] = lq_b
            band_gt_grid[idp, ix] = gt_b

    phase_grid, phase_base = make_phase_grid(rng, depth_anchors, x_anchors)

    def interp_grid(x_norm, depth_norm, grid):
        """Bilinear interpolation over [depth_anchor, x_anchor]."""
        x_norm = float(np.clip(x_norm, 0.0, 1.0))
        depth_norm = float(np.clip(depth_norm, 0.0, 1.0))
        grid = np.asarray(grid, dtype=np.float64)

        vals_d = np.zeros((len(depth_anchors),) + grid.shape[2:], dtype=np.float64)
        for d in range(len(depth_anchors)):
            if grid.ndim == 3:
                for k in range(grid.shape[2]):
                    vals_d[d, k] = np.interp(x_norm, x_anchors, grid[d, :, k])
            else:
                vals_d[d] = np.interp(x_norm, x_anchors, grid[d, :])

        if grid.ndim == 3:
            out = np.zeros((grid.shape[2],), dtype=np.float64)
            for k in range(grid.shape[2]):
                out[k] = np.interp(depth_norm, depth_anchors, vals_d[:, k])
            return out
        return float(np.interp(depth_norm, depth_anchors, vals_d))

    def wavelet_func(x_norm, depth_norm):
        b_lq = fix_lq_band(interp_grid(x_norm, depth_norm, band_lq_grid))
        b_gt = fix_gt_band(interp_grid(x_norm, depth_norm, band_gt_grid), b_lq)
        phase = interp_grid(x_norm, depth_norm, phase_grid)
        w_lq, w_gt = ormsby_pair_from_bands(b_lq, b_gt, phase, dt=dt, length=length)
        return w_lq, w_gt, {
            "x_norm": sanitize_float(x_norm),
            "depth_norm": sanitize_float(depth_norm),
            "band_lq": [sanitize_float(x) for x in b_lq],
            "band_gt": [sanitize_float(x) for x in b_gt],
            "phase_deg": sanitize_float(phase),
        }

    meta = {
        "family": "ormsby",
        "variation": "time_space",
        "stationary": False,
        "time_varying": True,
        "space_varying": True,
        "noise": False,
        "same_size": True,
        "phase_deg": sanitize_float(phase_base),
        "depth_anchors": [sanitize_float(x) for x in depth_anchors],
        "x_anchors": [sanitize_float(x) for x in x_anchors],
        "space_profile_mode": pattern_mode,
        "space_profile_amp": sanitize_float(x_strength),
        "pattern_mode": pattern_mode,
        "depth_power": sanitize_float(depth_power),
        "x_trend_strength": sanitize_float(x_strength),
        "wave_strength": sanitize_float(wave_strength),
        "channel_strength": sanitize_float(channel_strength),
        "bump_records": bump_records,
        "lq_f3_min_target": sanitize_float(lq_f3_min),
        "lq_f3_max_target": sanitize_float(lq_f3_max),
        "gt_f3_min_target": sanitize_float(gt_f3_min),
        "gt_f3_max_target": sanitize_float(gt_f3_max),
        "requested_lq_f3_range": "22-40 Hz",
        "requested_gt_f3_range": "56-70 Hz",
        "lq_f4_gap_range": [sanitize_float(LQ_F4_GAP_RANGE[0]), sanitize_float(LQ_F4_GAP_RANGE[1])],
        "gt_f4_gap_range": [sanitize_float(GT_F4_GAP_RANGE[0]), sanitize_float(GT_F4_GAP_RANGE[1])],
        "hf_norm_grid": [[sanitize_float(v) for v in row] for row in hf_norm],
        "band_lq_grid": [[[sanitize_float(v) for v in band_lq_grid[i, j]] for j in range(len(x_anchors))] for i in range(len(depth_anchors))],
        "band_gt_grid": [[[sanitize_float(v) for v in band_gt_grid[i, j]] for j in range(len(x_anchors))] for i in range(len(depth_anchors))],
        "phase_grid": [[sanitize_float(v) for v in row] for row in phase_grid],
        "ts_rule": "Time-space-varying Ormsby V6-weaker-checked: LQ f3 is constrained to about 22-40 Hz; GT f3 is constrained to about 56-70 Hz; f4 is generated as a legal roll-off endpoint after f3; depth variation and local perturbations are weakened; GT band envelopes local LQ.",
    }

    return wavelet_func, meta


# =========================================================
# 3. 卷积、归一化、QC
# =========================================================
def convolve_along_depth(img, wavelet):
    img = np.asarray(img, dtype=np.float32)
    wavelet = np.asarray(wavelet, dtype=np.float32)
    n2, n1 = img.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))
    IMG = np.fft.rfft(img, n=nfft, axis=1)
    W = np.fft.rfft(wavelet, n=nfft)
    y = np.fft.irfft(IMG * W[None, :], n=nfft, axis=1)
    start = (nw - 1) // 2
    return y[:, start:start + n1].astype(np.float32)


def make_window_starts(n, win, step):
    if n <= win:
        return [0]
    starts = list(range(0, n - win + 1, step))
    if starts[-1] != n - win:
        starts.append(n - win)
    return sorted(set(starts))


def convolve_time_space_varying(img, wavelet_func, time_win=128, time_step=32, x_group=8):
    """
    时空变非平稳卷积：
    - 横向按 trace group 分组；
    - 纵向按 time window 分窗；
    - 每个局部 (x_group_center, time_window_center) 生成一对 Ormsby 子波；
    - 对该横向组做完整深度卷积，只取对应时间窗，用 Hann overlap-add 融合。
    """
    img = np.asarray(img, dtype=np.float32)
    n2, n1 = img.shape

    t_starts = make_window_starts(n1, time_win, time_step)
    t_weight = 0.05 + 0.95 * np.hanning(time_win).astype(np.float32)

    out_lq = np.zeros_like(img, dtype=np.float32)
    out_gt = np.zeros_like(img, dtype=np.float32)
    wsum = np.zeros_like(img, dtype=np.float32)

    records = []

    for x0 in range(0, n2, x_group):
        x1 = min(x0 + x_group, n2)
        x_mid = 0.5 * (x0 + x1 - 1)
        x_norm = float(np.clip(x_mid / max(n2 - 1, 1), 0.0, 1.0))
        img_g = img[x0:x1, :]

        for s in t_starts:
            e = s + time_win
            depth_norm = float(np.clip((s + 0.5 * time_win) / max(n1 - 1, 1), 0.0, 1.0))

            w_lq, w_gt, local_meta = wavelet_func(x_norm, depth_norm)
            conv_lq = convolve_along_depth(img_g, w_lq)
            conv_gt = convolve_along_depth(img_g, w_gt)

            out_lq[x0:x1, s:e] += conv_lq[:, s:e] * t_weight[None, :]
            out_gt[x0:x1, s:e] += conv_gt[:, s:e] * t_weight[None, :]
            wsum[x0:x1, s:e] += t_weight[None, :]

            rec = dict(local_meta)
            rec.update({
                "x_start": int(x0),
                "x_end": int(x1),
                "window_start": int(s),
                "window_end": int(e),
            })
            records.append(rec)

    out_lq = out_lq / np.maximum(wsum, 1e-6)
    out_gt = out_gt / np.maximum(wsum, 1e-6)
    return out_lq.astype(np.float32), out_gt.astype(np.float32), records


def normalize_pair_shared(lq, gt, percentile=99.5, scale_floor=1e-6):
    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)
    vals = np.concatenate([np.abs(lq).reshape(-1), np.abs(gt).reshape(-1)])
    scale = float(np.percentile(vals, percentile))
    scale = max(scale, float(scale_floor))
    lq_n = np.clip(lq / scale, -1.0, 1.0).astype(np.float32)
    gt_n = np.clip(gt / scale, -1.0, 1.0).astype(np.float32)
    return lq_n, gt_n, scale


def _norm_for_pair_check(x):
    x = np.asarray(x, dtype=np.float32)
    p = float(np.percentile(np.abs(x), 99.5))
    p = max(p, 1e-6)
    return np.clip(x / p, -1.0, 1.0).astype(np.float32)


def _zcorr(a, b):
    a = np.asarray(a, dtype=np.float32).reshape(-1)
    b = np.asarray(b, dtype=np.float32).reshape(-1)
    a = a - float(a.mean())
    b = b - float(b.mean())
    den = float(np.sqrt(np.sum(a * a) * np.sum(b * b)))
    if den < 1e-12:
        return 0.0
    return float(np.sum(a * b) / den)


def _abs_grad(a):
    a = np.asarray(a, dtype=np.float32)
    gy = np.diff(a, axis=0, append=a[-1:, :])
    gx = np.diff(a, axis=1, append=a[:, -1:])
    return np.sqrt(gx * gx + gy * gy).astype(np.float32)


def pair_alignment_self_check(lq, gt, same_corr_min=PAIR_SAME_CORR_MIN, orientation_margin=PAIR_ORIENTATION_MARGIN):
    """Check that LQ and GT are still the same physical pair.

    This is not a training metric. It is a generation-time safety gate, using the same
    gradient-orientation logic as diagnose_bwe_pair_alignment.py. It catches stale-file,
    transposed-image, or accidental wrong-pair problems before writing the sample.
    """
    lq_g = _abs_grad(_norm_for_pair_check(lq))
    candidates = {
        "same": gt,
        "transpose": gt.T,
        "flipud": np.flipud(gt),
        "fliplr": np.fliplr(gt),
        "rot90": np.rot90(gt, 1),
        "rot180": np.rot90(gt, 2),
        "rot270": np.rot90(gt, 3),
    }
    scores = {}
    for name, arr in candidates.items():
        if arr.shape != lq.shape:
            scores[name] = float("nan")
        else:
            scores[name] = _zcorr(lq_g, _abs_grad(_norm_for_pair_check(arr)))
    best_name = max(scores, key=lambda k: -999.0 if np.isnan(scores[k]) else scores[k])
    same_score = scores.get("same", float("nan"))
    best_score = scores.get(best_name, float("nan"))
    status = "ok"
    if best_name != "same" and best_score > same_score + orientation_margin:
        status = f"possible_orientation_issue_best_{best_name}"
    if same_score < same_corr_min:
        status = "possible_wrong_pair_or_very_different" if status == "ok" else status + "|low_same_corr"
    return {
        "status": status,
        "same_corr": sanitize_float(same_score),
        "best_orientation": best_name,
        "best_corr": sanitize_float(best_score),
        "scores": {k: sanitize_float(v) if not np.isnan(v) else None for k, v in scores.items()},
    }


def collect_representative_wavelets(wavelet_func):
    rep_w_lq = np.zeros((len(REP_DEPTHS), len(REP_XS), len(time_axis(DT, WAVELET_LENGTH))), dtype=np.float32)
    rep_w_gt = np.zeros_like(rep_w_lq)
    rep_metas = []
    for idp, d in enumerate(REP_DEPTHS):
        row = []
        for ix, x in enumerate(REP_XS):
            w_lq, w_gt, lm = wavelet_func(x, d)
            rep_w_lq[idp, ix] = w_lq
            rep_w_gt[idp, ix] = w_gt
            row.append(lm)
        rep_metas.append(row)
    return rep_w_lq, rep_w_gt, rep_metas


def compute_band_f4_maps(wavelet_func, n1=512, n2=512):
    # 用于 QC 的参数色图：为节省时间，按每 4 个像素采样后插值显示也可以；这里直接计算完整 512x512。
    lq_f4 = np.zeros((n1, n2), dtype=np.float32)
    gt_f4 = np.zeros((n1, n2), dtype=np.float32)
    for iz in range(n1):
        d = iz / max(n1 - 1, 1)
        for ix in range(n2):
            x = ix / max(n2 - 1, 1)
            _, _, lm = wavelet_func(x, d)
            lq_f4[iz, ix] = lm["band_lq"][3]
            gt_f4[iz, ix] = lm["band_gt"][3]
    return lq_f4, gt_f4


def save_qc_figure_timespace_ormsby(lq, gt, rep_w_lq, rep_w_gt, rep_metas, meta, out_png, dt=0.004):
    """
    QC figure with f2/f3 parameter maps instead of f4 maps.

    Layout:
    - Row 1: LQ section / GT section / trace comparison
    - Row 2-3, left 2 columns: 2x2 frequency maps
        row 2: LQ f2, GT f2
        row 3: LQ f3, GT f3
    - Row 2-3, right column: representative f2/f3 trends
    - Row 4: representative spectra at top/middle/bottom
    - Row 5: local meta / global meta / checklist
    """
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)

    clip = np.percentile(np.abs(np.concatenate([lq.reshape(-1), gt.reshape(-1)])), 99.0)
    clip = max(float(clip), 1e-6)
    x_trace = lq.shape[0] // 2

    fig = plt.figure(figsize=(22, 18), dpi=140)
    gs = fig.add_gridspec(
        5,
        3,
        height_ratios=[1.00, 1.02, 1.02, 0.98, 1.35],
        hspace=0.50,
        wspace=0.30,
    )

    # =====================================================
    # 1) Sections + trace comparison
    # =====================================================
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.imshow(lq.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax1.set_title("LQ narrow-band, time-space-varying")

    ax2 = fig.add_subplot(gs[0, 1])
    ax2.imshow(gt.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax2.set_title("GT broadband, time-space-varying")

    ax3 = fig.add_subplot(gs[0, 2])
    ax3.plot(lq[x_trace, :], label="lq")
    ax3.plot(gt[x_trace, :], label="gt")
    ax3.set_title(f"Trace comparison x={x_trace}")
    ax3.legend(fontsize=8)
    ax3.grid(True, alpha=0.2)

    # =====================================================
    # 2) Parameter maps: f2/f3 instead of f4
    # =====================================================
    x_vals = np.linspace(0, 1, N2)
    d_vals = np.linspace(0, 1, N1)
    depth_anchors = np.asarray(meta["depth_anchors"], dtype=np.float64)
    x_anchors = np.asarray(meta["x_anchors"], dtype=np.float64)
    band_lq_grid = np.asarray(meta["band_lq_grid"], dtype=np.float64)
    band_gt_grid = np.asarray(meta["band_gt_grid"], dtype=np.float64)

    def interp_param_map(grid, param_idx):
        """Interpolate band parameter map from anchor grid.

        param_idx: 0=f1, 1=f2, 2=f3, 3=f4.
        grid shape: [depth_anchor, x_anchor, 4]
        output shape: [sample/depth, trace]
        """
        temp = np.zeros((len(depth_anchors), N2), dtype=np.float32)
        for idp in range(len(depth_anchors)):
            temp[idp, :] = np.interp(x_vals, x_anchors, grid[idp, :, param_idx])
        out = np.zeros((N1, N2), dtype=np.float32)
        for ix in range(N2):
            out[:, ix] = np.interp(d_vals, depth_anchors, temp[:, ix])
        return out

    lq_f2_map = interp_param_map(band_lq_grid, 1)
    gt_f2_map = interp_param_map(band_gt_grid, 1)
    lq_f3_map = interp_param_map(band_lq_grid, 2)
    gt_f3_map = interp_param_map(band_gt_grid, 2)

    # 第一行：f2，LQ / GT
    ax4 = fig.add_subplot(gs[1, 0])
    im4 = ax4.imshow(lq_f2_map, cmap="turbo", aspect="auto", origin="upper")
    ax4.set_title("LQ Ormsby f2 map (Hz)")
    fig.colorbar(im4, ax=ax4, shrink=0.75)

    ax5 = fig.add_subplot(gs[1, 1])
    im5 = ax5.imshow(gt_f2_map, cmap="turbo", aspect="auto", origin="upper")
    ax5.set_title("GT Ormsby f2 map (Hz)")
    fig.colorbar(im5, ax=ax5, shrink=0.75)

    # 第二行：f3，LQ / GT
    ax7 = fig.add_subplot(gs[2, 0])
    im7 = ax7.imshow(lq_f3_map, cmap="turbo", aspect="auto", origin="upper")
    ax7.set_title("LQ Ormsby f3 map (Hz)")
    fig.colorbar(im7, ax=ax7, shrink=0.75)

    ax8 = fig.add_subplot(gs[2, 1])
    im8 = ax8.imshow(gt_f3_map, cmap="turbo", aspect="auto", origin="upper")
    ax8.set_title("GT Ormsby f3 map (Hz)")
    fig.colorbar(im8, ax=ax8, shrink=0.75)

    # 右侧趋势图：只看 middle x 位置，避免过多曲线拥挤
    ax6 = fig.add_subplot(gs[1:3, 2])
    mid_x = 1
    ax6.plot(REP_DEPTHS, [rep_metas[i][mid_x]["band_lq"][1] for i in range(3)], marker="o", label="LQ f2 @ middle x")
    ax6.plot(REP_DEPTHS, [rep_metas[i][mid_x]["band_gt"][1] for i in range(3)], marker="o", label="GT f2 @ middle x")
    ax6.plot(REP_DEPTHS, [rep_metas[i][mid_x]["band_lq"][2] for i in range(3)], marker="s", label="LQ f3 @ middle x")
    ax6.plot(REP_DEPTHS, [rep_metas[i][mid_x]["band_gt"][2] for i in range(3)], marker="s", label="GT f3 @ middle x")
    ax6.set_title("Representative f2/f3 trends")
    ax6.set_xlabel("normalized depth")
    ax6.set_ylabel("Hz")
    ax6.legend(fontsize=8)
    ax6.grid(True, alpha=0.25)

    # =====================================================
    # 3) Representative spectra
    # =====================================================
    for idp, dname in enumerate(REP_D_NAMES):
        ax = fig.add_subplot(gs[3, idp])
        for ix, xname in enumerate(REP_X_NAMES):
            f_lq, a_lq = amplitude_spectrum(rep_w_lq[idp, ix], dt=dt)
            f_gt, a_gt = amplitude_spectrum(rep_w_gt[idp, ix], dt=dt)
            ax.plot(f_lq, a_lq, linestyle="--", linewidth=1.0, label=f"{xname} lq")
            ax.plot(f_gt, a_gt, linestyle="-", linewidth=1.0, label=f"{xname} gt")
        ax.set_xlim(0, 110)
        ax.set_ylim(0, 1.08)
        ax.set_title(f"Representative spectra: {dname}")
        ax.legend(fontsize=6, ncol=2)
        ax.grid(True, alpha=0.20)

    # =====================================================
    # 4) Meta + checklist
    # =====================================================
    ax10 = fig.add_subplot(gs[4, 0])
    ax10.axis("off")
    local_show = []
    for idp, dname in enumerate(REP_D_NAMES):
        for ix, xname in enumerate(REP_X_NAMES):
            m = rep_metas[idp][ix]
            local_show.append({
                "pos": f"{xname}-{dname}",
                "lq_f2": round(m["band_lq"][1], 2),
                "gt_f2": round(m["band_gt"][1], 2),
                "lq_f3": round(m["band_lq"][2], 2),
                "gt_f3": round(m["band_gt"][2], 2),
                "lq_band": [round(v, 2) for v in m["band_lq"]],
                "gt_band": [round(v, 2) for v in m["band_gt"]],
            })
    ax10.text(0, 1, json.dumps(local_show, ensure_ascii=False, indent=2), va="top", ha="left", fontsize=6.2, family="monospace")
    ax10.set_title("3x3 local f2/f3 band meta")

    ax11 = fig.add_subplot(gs[4, 1])
    ax11.axis("off")
    meta_show = dict(meta)
    for k in ["band_lq_grid", "band_gt_grid", "phase_grid"]:
        meta_show[k] = "see json/npz"
    txt = json.dumps(meta_show, ensure_ascii=False, indent=2)
    ax11.text(0, 1, txt, va="top", ha="left", fontsize=6.2, family="monospace")
    ax11.set_title("global meta")

    ax12 = fig.add_subplot(gs[4, 2])
    ax12.axis("off")
    ax12.text(
        0, 1,
        "QC checklist:\n"
        "1) GT spectra envelope LQ at 3x3 positions.\n"
        "2) f2/f3 maps show time-space-varying passband boundaries.\n"
        "3) LQ/GT f2/f3 maps are paired and physically ordered.\n"
        "4) LQ/GT sections show no obvious vertical stripes.\n"
        "5) LQ/GT sections show no obvious time-window seams.\n"
        "6) Phase/peak positions remain consistent between LQ and GT.",
        va="top", ha="left", fontsize=9,
    )

    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)

# =========================================================
# 4. 动态加载反射结构脚本
# =========================================================
def load_generator_class(script_path, module_name):
    script_path = Path(script_path)
    if not script_path.exists():
        raise FileNotFoundError(f"Source script not found: {script_path}")
    spec = importlib.util.spec_from_file_location(module_name, str(script_path))
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    if not hasattr(mod, "GeologicalSeismicData"):
        raise AttributeError(f"{script_path.name} does not contain class GeologicalSeismicData")
    return mod.GeologicalSeismicData


def generate_reflectivity(GeneratorClass, seed, n1=512, n2=512):
    gen = GeneratorClass(seed=seed)
    try:
        model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0)
    except TypeError:
        if hasattr(gen, "generate_plausible_parameters"):
            params = gen.generate_plausible_parameters(n1=n1, n2=n2)
            model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0, params=params)
        else:
            raise
    model = np.asarray(model, dtype=np.float32)
    if model.shape != (n2, n1):
        raise ValueError(f"Unexpected model shape {model.shape}, expected {(n2, n1)}")
    return model


# =========================================================
# 5. 索引、复现信息
# =========================================================
def phase_group(phase_deg, eps=1e-6):
    return "zero_phase" if abs(float(phase_deg)) <= eps else "with_phase"


def write_summary_csv(rows):
    out_csv = OUT_DIR / "sample_index.csv"
    fields = [
        "id", "structure", "family", "variation", "phase_deg", "phase_group",
        "space_profile_mode", "lq_path", "gt_path", "meta_path", "wavelet_field_path", "w_lq_path", "w_gt_path",
    ]
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})
    print(f"[SAVE] sample_index.csv: {out_csv}")

    counts = {
        "total": len(rows),
        "by_structure": dict(Counter(r["structure"] for r in rows)),
        "by_family": dict(Counter(r["family"] for r in rows)),
        "by_phase_group": dict(Counter(r["phase_group"] for r in rows)),
        "by_space_profile_mode": dict(Counter(r["space_profile_mode"] for r in rows)),
    }
    out_json = OUT_DIR / "sample_count.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(counts, f, ensure_ascii=False, indent=2)
    print(f"[SAVE] sample_count.json: {out_json}")
    print(json.dumps(counts, ensure_ascii=False, indent=2))


def copy_sources_for_reproducibility():
    if not COPY_SOURCE_SCRIPTS:
        return
    src_dir = OUT_DIR / "source_scripts"
    src_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(__file__), src_dir / Path(__file__).name)
    for item in SOURCE_SCRIPTS:
        p = SCRIPT_DIR / item["file"]
        if p.exists():
            shutil.copy2(p, src_dir / p.name)


# =========================================================
# 6. 主程序
# =========================================================
def main():
    ensure_dirs()
    copy_sources_for_reproducibility()

    idx = START_INDEX
    rows = []
    rng_global = np.random.default_rng(RANDOM_SEED)

    print(
        f"Start generating WEAKER-CHECKED Ormsby TIME-SPACE-VARYING BWE dataset: "
        f"{len(SOURCE_SCRIPTS)} structures × {NUM_PER_STRUCTURE} samples, "
        f"same-size {N2}x{N1}, no noise, x_group={X_GROUP}, time_win={TIME_WIN}, time_step={TIME_STEP}."
    )

    for s_i, item in enumerate(SOURCE_SCRIPTS):
        structure = item["name"]
        script_path = SCRIPT_DIR / item["file"]
        GeneratorClass = load_generator_class(script_path, module_name=f"gen_{structure}")
        print(f"\n[STRUCTURE] {structure} from {item['file']}")

        for j in range(NUM_PER_STRUCTURE):
            # 生成-自检-必要时重试：避免把明显错配/转置/残留问题写入数据集。
            pair_check = None
            last_status = None
            for retry in range(MAX_PAIR_RETRY + 1):
                sample_seed = int(RANDOM_SEED * 100000 + s_i * 10000 + j + retry * 1000000)
                wavelet_rng = np.random.default_rng(sample_seed + 999)

                # 1) 反射结构
                model = generate_reflectivity(GeneratorClass, seed=sample_seed, n1=N1, n2=N2)

                # 2) Ormsby 时空变子波场
                wavelet_func, meta_w = make_ormsby_timespace_wavelet_model(
                    wavelet_rng,
                    dt=DT,
                    length=WAVELET_LENGTH,
                )

                # 3) 时空变非平稳卷积
                lq, gt, local_records = convolve_time_space_varying(
                    model,
                    wavelet_func,
                    time_win=TIME_WIN,
                    time_step=TIME_STEP,
                    x_group=X_GROUP,
                )

                # 4) 共享归一化
                lq, gt, shared_scale = normalize_pair_shared(lq, gt, percentile=99.5, scale_floor=1e-6)

                pair_check = pair_alignment_self_check(lq, gt)
                last_status = pair_check["status"]
                if (not STRICT_PAIR_CHECK) or last_status == "ok":
                    break
                print(f"[PAIR-CHECK RETRY] structure={structure}, local_j={j}, retry={retry}, status={last_status}, same_corr={pair_check['same_corr']:.3f}, best={pair_check['best_orientation']}")
            else:
                raise RuntimeError(
                    f"Pair alignment self-check failed after {MAX_PAIR_RETRY} retries: "
                    f"structure={structure}, local_j={j}, last_status={last_status}, last_check={pair_check}"
                )

            # 5) 代表子波保存
            rep_w_lq, rep_w_gt, rep_metas = collect_representative_wavelets(wavelet_func)

            stem = f"{idx:04d}"
            fname = f"{stem}.dat"
            lq.astype(np.float32).tofile(LQ_DIR / fname)
            gt.astype(np.float32).tofile(GT_DIR / fname)

            # 中心位置代表子波，兼容已有 split 脚本
            center_d = len(REP_DEPTHS) // 2
            center_x = len(REP_XS) // 2
            w_lq_path = WAVELET_DIR / f"{stem}_w_lq.npy"
            w_gt_path = WAVELET_DIR / f"{stem}_w_gt.npy"
            np.save(w_lq_path, rep_w_lq[center_d, center_x].astype(np.float32))
            np.save(w_gt_path, rep_w_gt[center_d, center_x].astype(np.float32))

            wavelet_field_path = WAVELET_DIR / f"{stem}_wavelet_field.npz"
            np.savez_compressed(
                wavelet_field_path,
                rep_xs=np.asarray(REP_XS, dtype=np.float32),
                rep_depths=np.asarray(REP_DEPTHS, dtype=np.float32),
                rep_w_lq=rep_w_lq.astype(np.float32),
                rep_w_gt=rep_w_gt.astype(np.float32),
                band_lq_grid=np.asarray(meta_w["band_lq_grid"], dtype=np.float32),
                band_gt_grid=np.asarray(meta_w["band_gt_grid"], dtype=np.float32),
                phase_grid=np.asarray(meta_w["phase_grid"], dtype=np.float32),
                depth_warp=np.asarray(meta_w.get("depth_warp", []), dtype=np.float32),
                boundary_wave_x=np.asarray(meta_w.get("boundary_wave_x", []), dtype=np.float32),
                x_anchors=np.asarray(meta_w["x_anchors"], dtype=np.float32),
                depth_anchors=np.asarray(meta_w["depth_anchors"], dtype=np.float32),
            )

            meta = dict(meta_w)
            meta.update({
                "id": stem,
                "structure": structure,
                "source_script": item["file"],
                "seed": int(sample_seed),
                "n1": int(N1),
                "n2": int(N2),
                "dt": float(DT),
                "wavelet_length": float(WAVELET_LENGTH),
                "time_win": int(TIME_WIN),
                "time_step": int(TIME_STEP),
                "x_group": int(X_GROUP),
                "representative_xs": [sanitize_float(x) for x in REP_XS],
                "representative_depths": [sanitize_float(d) for d in REP_DEPTHS],
                "shared_scale": sanitize_float(shared_scale),
                "pair_alignment_check": pair_check,
                "num_local_records": int(len(local_records)),
                "local_records_preview": local_records[:12],
            })

            meta_path = META_DIR / f"{stem}.json"
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)

            # 6) QC
            should_qc = idx < START_INDEX + QC_FIRST_N or (idx - START_INDEX + 1) % QC_EVERY == 0
            if should_qc:
                qc_path = QC_DIR / f"{stem}_qc.png"
                save_qc_figure_timespace_ormsby(lq, gt, rep_w_lq, rep_w_gt, rep_metas, meta, qc_path, dt=DT)

            rows.append({
                "id": stem,
                "structure": structure,
                "family": "ormsby",
                "variation": "time_space",
                "phase_deg": sanitize_float(meta.get("phase_deg", 0.0)),
                "phase_group": phase_group(meta.get("phase_deg", 0.0)),
                "space_profile_mode": meta.get("space_profile_mode", ""),
                "lq_path": str(LQ_DIR / fname),
                "gt_path": str(GT_DIR / fname),
                "meta_path": str(meta_path),
                "wavelet_field_path": str(wavelet_field_path),
                "w_lq_path": str(w_lq_path),
                "w_gt_path": str(w_gt_path),
            })

            if (idx - START_INDEX + 1) % 10 == 0:
                print(f"[{idx - START_INDEX + 1}] done. latest structure={structure}, idx={stem}, profile={meta.get('space_profile_mode')}")

            idx += 1

    write_summary_csv(rows)
    print(f"\nAll done. Dataset saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
