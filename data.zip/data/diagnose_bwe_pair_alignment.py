# -*- coding: utf-8 -*-
"""
Diagnose whether LQ/GT .dat pairs in a BWE dataset are aligned.

Usage examples:
  python diagnose_bwe_pair_alignment.py --root D:/dateset0309/dataset_waveform_bwe_osdeltadiff_clean_v1 --split val
  python diagnose_bwe_pair_alignment.py --root D:/dateset0309/dataset_waveform_bwe_osdeltadiff_clean_v1 --split train --max_items 200

It checks each same-name LQ/GT pair and reports:
  - same-direction correlation
  - transpose / flip alternatives
  - suspicious cases where GT seems to be a different sample or a transposed/rotated version
It also saves a CSV report and optional side-by-side PNGs for suspicious pairs.
"""

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt


def norm01(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    p = np.percentile(np.abs(x), 99.5)
    p = max(float(p), 1e-6)
    x = np.clip(x / p, -1.0, 1.0)
    return x


def zcorr(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=np.float32).reshape(-1)
    b = np.asarray(b, dtype=np.float32).reshape(-1)
    a = a - float(a.mean())
    b = b - float(b.mean())
    den = float(np.sqrt(np.sum(a * a) * np.sum(b * b)))
    if den < 1e-12:
        return 0.0
    return float(np.sum(a * b) / den)


def abs_grad(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=np.float32)
    gy = np.diff(a, axis=0, append=a[-1:, :])
    gx = np.diff(a, axis=1, append=a[:, -1:])
    return np.sqrt(gx * gx + gy * gy).astype(np.float32)


def read_dat(path: Path, shape) -> np.ndarray:
    arr = np.fromfile(str(path), dtype=np.float32)
    expect = int(shape[0]) * int(shape[1])
    if arr.size != expect:
        raise ValueError(f"{path} size mismatch: got {arr.size}, expect {expect}")
    return arr.reshape(tuple(shape)).astype(np.float32)


def best_orientation_scores(lq: np.ndarray, gt: np.ndarray):
    # Use gradient magnitude to reduce spectral/amplitude differences between LQ and GT.
    lq_g = abs_grad(norm01(lq))
    candidates = {
        "same": gt,
        "transpose": gt.T,
        "flipud": np.flipud(gt),
        "fliplr": np.fliplr(gt),
        "rot90": np.rot90(gt, 1),
        "rot180": np.rot90(gt, 2),
        "rot270": np.rot90(gt, 3),
    }
    scores = {}
    for name, arr in candidates.items():
        if arr.shape != lq.shape:
            scores[name] = np.nan
        else:
            scores[name] = zcorr(lq_g, abs_grad(norm01(arr)))
    best_name = max(scores, key=lambda k: -999 if np.isnan(scores[k]) else scores[k])
    return scores, best_name, scores[best_name]


def load_meta(meta_path: Path):
    if not meta_path.exists():
        return {}
    try:
        with open(meta_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_pair_png(out_path: Path, lq: np.ndarray, gt: np.ndarray, title: str):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    v = np.percentile(np.abs(np.concatenate([lq.reshape(-1), gt.reshape(-1)])), 99.0)
    v = max(float(v), 1e-6)
    fig, axes = plt.subplots(1, 3, figsize=(12, 4), dpi=150)
    axes[0].imshow(lq.T, cmap="gray", vmin=-v, vmax=v, origin="upper", aspect="auto")
    axes[0].set_title("LQ shown as arr.T")
    axes[1].imshow(gt.T, cmap="gray", vmin=-v, vmax=v, origin="upper", aspect="auto")
    axes[1].set_title("GT shown as arr.T")
    axes[2].imshow((gt - lq).T, cmap="gray", origin="upper", aspect="auto")
    axes[2].set_title("GT - LQ, arr.T")
    for ax in axes:
        ax.set_xticks([])
        ax.set_yticks([])
    fig.suptitle(title, fontsize=10)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=str, default=r"D:\dateset0309\dataset_waveform_bwe_osdeltadiff_clean_v1")
    ap.add_argument("--split", type=str, default="val", choices=["train", "val"])
    ap.add_argument("--shape", type=int, nargs=2, default=[512, 512])
    ap.add_argument("--max_items", type=int, default=0, help="0 means all pairs")
    ap.add_argument("--save_suspicious_png", action="store_true")
    ap.add_argument("--same_corr_warn", type=float, default=0.20)
    args = ap.parse_args()

    root = Path(args.root)
    lq_dir = root / args.split / "lq"
    gt_dir = root / args.split / "gt"
    meta_dir = root / args.split / "meta"
    out_dir = root / "alignment_diagnosis"
    out_dir.mkdir(parents=True, exist_ok=True)

    lq_files = sorted(lq_dir.glob("*.dat"))
    if args.max_items and args.max_items > 0:
        lq_files = lq_files[:args.max_items]

    rows = []
    suspicious = []
    for i, lq_path in enumerate(lq_files, 1):
        gt_path = gt_dir / lq_path.name
        if not gt_path.exists():
            rows.append({"id": lq_path.stem, "status": "missing_gt"})
            suspicious.append(lq_path.stem)
            continue
        try:
            lq = read_dat(lq_path, args.shape)
            gt = read_dat(gt_path, args.shape)
            scores, best_name, best_score = best_orientation_scores(lq, gt)
            same_score = scores.get("same", np.nan)
            meta = load_meta(meta_dir / f"{lq_path.stem}.json")
            status = "ok"
            if best_name != "same" and best_score > same_score + 0.08:
                status = f"possible_orientation_issue_best_{best_name}"
            if same_score < args.same_corr_warn:
                status = "possible_wrong_pair_or_very_different" if status == "ok" else status + "|low_same_corr"
            row = {
                "id": lq_path.stem,
                "status": status,
                "same_corr": same_score,
                "best_orientation": best_name,
                "best_corr": best_score,
                "transpose_corr": scores.get("transpose", np.nan),
                "flipud_corr": scores.get("flipud", np.nan),
                "fliplr_corr": scores.get("fliplr", np.nan),
                "rot90_corr": scores.get("rot90", np.nan),
                "rot180_corr": scores.get("rot180", np.nan),
                "rot270_corr": scores.get("rot270", np.nan),
                "source_dataset": meta.get("source_dataset", ""),
                "source_id": meta.get("source_id", ""),
                "variation": meta.get("variation", ""),
                "family": meta.get("family", ""),
                "structure": meta.get("structure", ""),
                "source_lq_path": meta.get("source_lq_path", ""),
                "source_gt_path": meta.get("source_gt_path", ""),
            }
            rows.append(row)
            if status != "ok":
                suspicious.append(lq_path.stem)
                if args.save_suspicious_png and len(suspicious) <= 30:
                    save_pair_png(out_dir / f"suspicious_{lq_path.stem}.png", lq, gt, f"{lq_path.stem}: {status}")
        except Exception as e:
            rows.append({"id": lq_path.stem, "status": f"error: {e}"})
            suspicious.append(lq_path.stem)

    csv_path = out_dir / f"{args.split}_alignment_report.csv"
    fields = [
        "id", "status", "same_corr", "best_orientation", "best_corr",
        "transpose_corr", "flipud_corr", "fliplr_corr", "rot90_corr", "rot180_corr", "rot270_corr",
        "source_dataset", "source_id", "variation", "family", "structure",
        "source_lq_path", "source_gt_path",
    ]
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})

    n = len(rows)
    n_susp = len([r for r in rows if r.get("status") != "ok"])
    print(f"Checked {n} pairs in {lq_dir}")
    print(f"Suspicious pairs: {n_susp}")
    print(f"Report saved to: {csv_path}")
    if suspicious[:20]:
        print("First suspicious IDs:", ", ".join(suspicious[:20]))


if __name__ == "__main__":
    main()
