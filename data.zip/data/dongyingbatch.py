import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter, map_coordinates


class GeologicalSeismicData:

    def __init__(self, seed=31):
        self.rng = np.random.RandomState(seed)

    def seismic_and_slopes_2d(self, n1=256, n2=768, noise=0):  # 恢复 n2=768

        # 1. 创建基础反射系数
        reflectivity = self._make_reflectivity_2d(n1, n2)

        # 应用分层褶皱
        lower_params = {'a1': 0, 'b1': 0.03, 'a2': 5e-5, 'b2': 5e-5}  # 低频、高幅
        upper_params = {'a1': 0, 'b1': 0.01, 'a2': 8e-4, 'b2': 8e-4}  # 高频、低幅

        reflectivity = self._apply_sinusoidal_fold_2d_layered(
            reflectivity, n1, n2,
            boundary_i1=n1 // 3.5,
            upper_params=upper_params,
            lower_params=lower_params
        )

        i1_lift_start = 15
        i1_lift_end = 360
        #  模拟盐丘上拱
        reflectivity = self._apply_salt_dome_2d(
            reflectivity, n1, n2,
            dome_center_x2=470,
            dome_height=40.0,
            dome_width=50.0,
            i1_start_lift=i1_lift_start,
            i1_end_lift=i1_lift_end
        )

        fault_start_detph = 20
        fault_end_detph = 300


        # --- 断层 1 ---
        fault1_params = {
            'x2_ref': 0, 'dip_top': 50, 'dip_bottom': 13, 'throw': 15,
            'i1_start': fault_start_detph, 'i1_end': n1,
            'growth_factor': 1.0,
            'apply_attenuation': True,  # (新) 开关
            'zone_width': 8,  # (新) 独立参数
            'blur_sigma': 0.3,
            'attenuation_factor': 0.3
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault1_params)
        # (新) 检查开关
        if fault1_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault1_params)

        # --- 断层 2 (左侧) - 生长断层 ---
        fault2_params = {
            'x2_ref': 15, 'dip_top': 50, 'dip_bottom': 14, 'throw': 15,
            'i1_start': fault_start_detph, 'i1_end': fault_end_detph,
            'growth_factor': 1.25,
            'apply_attenuation': True,  # (新) 开关
            'zone_width': 8,
            'blur_sigma': 0.3,
            'attenuation_factor': 0.3
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault2_params)
        # (新) 检查开关
        if fault2_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault2_params)

        # --- 断层 4 ---
        fault4_params = {
            'x2_ref': 40, 'dip_top': 50, 'dip_bottom': 15, 'throw': 15,
            'i1_start': fault_start_detph, 'i1_end': fault_end_detph,
            'growth_factor': 1.2,
            'apply_attenuation': False  # (新) 开关 - 设置为 False
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault4_params)
        # (新) 检查开关
        if fault4_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault4_params)

        #小断层1
        fault5_params = {
            'x2_ref': 150, 'dip_top': 90, 'dip_bottom': 15, 'throw': 15,
            'i1_start': fault_start_detph, 'i1_end': 225,
            'growth_factor': 1.5,
            'apply_attenuation': False  # (新) 开关 - 设置为 False
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault5_params)
        # (新) 检查开关
        if fault5_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault5_params)

        #小断层2
        fault6_params = {
            'x2_ref': 200, 'dip_top': 100, 'dip_bottom': 15, 'throw': 15,
            'i1_start': 30, 'i1_end': 235,
            'growth_factor': 1.4,
            'apply_attenuation': False  # (新) 开关 - 设置为 False
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault6_params)
        # (新) 检查开关
        if fault6_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault6_params)
        fault7_params = {
            'x2_ref': 280, 'dip_top': 80, 'dip_bottom': 30, 'throw': 15,
            'i1_start': fault_start_detph, 'i1_end': 225,
            'growth_factor': 1.3,
            'apply_attenuation': False  # (新) 开关 - 设置为 False
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault7_params)
        # (新) 检查开关
        if fault7_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault7_params)
        # fault8_params = {
        #         'x2_ref': 350, 'dip_top': 100, 'dip_bottom': 15, 'throw': 15,
        #         'i1_start': fault_start_detph, 'i1_end': 250,
        #         'growth_factor': 1,
        #         'apply_attenuation': False  # (新) 开关 - 设置为 False
        #     }
        # reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault8_params)
        #     # (新) 检查开关
        # if fault8_params.get('apply_attenuation', False):
        #         reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault8_params)
        fault9_params = {
            'x2_ref': 250, 'dip_top': -100, 'dip_bottom': 15, 'throw': 15,
            'i1_start': fault_start_detph, 'i1_end': 220,
            'growth_factor': 1,
            'apply_attenuation': False  # (新) 开关 - 设置为 False
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault9_params)
        # (新) 检查开关
        if fault9_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault9_params)
        # fault10_params = {
        #     'x2_ref': 400, 'dip_top': 70, 'dip_bottom': 15, 'throw': 15,
        #     'i1_start': fault_start_detph, 'i1_end': 240,
        #     'growth_factor': 1,
        #     'apply_attenuation': True, # (新) 开关 - 设置为 False
        #     'zone_width': 5,
        #     'blur_sigma': 0.3,
        #     'attenuation_factor': 0.5
        # }
        # reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault10_params)
        # # (新) 检查开关
        # if fault10_params.get('apply_attenuation', False):
        #     reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault10_params)

        fault11_params = {
            'x2_ref': 410, 'dip_top': 80, 'dip_bottom': 15, 'throw': 15,
            'i1_start': 50, 'i1_end': 230,
            'growth_factor': 1,
            'apply_attenuation': True,  # (新) 开关 - 设置为 False
            'zone_width': 5,
            'blur_sigma': 0.3,
            'attenuation_factor': 0.5
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault11_params)
        # (新) 检查开关
        if fault11_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault11_params)

        fault12_params = {
            'x2_ref': 390, 'dip_top': 100, 'dip_bottom': 15, 'throw': 15,
            'i1_start': 50, 'i1_end': 250,
            'growth_factor': 1,
            'apply_attenuation': True,  # (新) 开关 - 设置为 False
            'zone_width': 5,
            'blur_sigma': 0.3,
            'attenuation_factor': 0.5
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault12_params)
        # (新) 检查开关
        if fault12_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault12_params)
        # fault13_params = {
        #     'x2_ref': 410, 'dip_top': 100, 'dip_bottom': 15, 'throw': 15,
        #     'i1_start': 80, 'i1_end': 250,
        #     'growth_factor': 1,
        #     'apply_attenuation': True,  # (新) 开关 - 设置为 False
        #     'zone_width': 5,
        #     'blur_sigma': 0.3,
        #     'attenuation_factor': 0.5
        # }
        # reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault13_params)
        # # (新) 检查开关
        # if fault13_params.get('apply_attenuation', False):
        #     reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault13_params)

        fault14_params = {
            'x2_ref': 290, 'dip_top': -100, 'dip_bottom': 0, 'throw': 15,
            'i1_start': 80, 'i1_end': 150,
            'growth_factor': 1,
            'apply_attenuation': False  # (新) 开关 - 设置为 False
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault14_params)
        # (新) 检查开关
        if fault14_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault14_params)

        fault15_params = {
            'x2_ref': 430, 'dip_top': 100, 'dip_bottom': 3, 'throw': 15,
            'i1_start': 50, 'i1_end': 150,
            'growth_factor': 1.25,
            'apply_attenuation': False  # (新) 开关 - 设置为 False

        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault15_params)
        # (新) 检查开关
        if fault15_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault15_params)

        fault16_params = {
            'x2_ref': 460, 'dip_top': -70, 'dip_bottom': 3, 'throw': 15,
            'i1_start': 60, 'i1_end': 120,
            'growth_factor': 1,
            'apply_attenuation': True,  # (新) 开关 - 设置为 False
            'zone_width': 8,
            'blur_sigma': 0.4,
            'attenuation_factor': 0.5
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault16_params)
        # (新) 检查开关
        if fault16_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault16_params)


        # --- 断层 3 (右侧) ---
        fault3_params = {
            'x2_ref': 600, 'dip_top': -60, 'dip_bottom': -13, 'throw': 30,
            'i1_start': fault_start_detph, 'i1_end': n1,
            'growth_factor': 1.0,
            'apply_attenuation': True,  # (新) 开关
            'zone_width': 10,
            'blur_sigma': 0.5,
            'attenuation_factor': 0.5
        }
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault3_params)
        # (新) 检查开关
        if fault3_params.get('apply_attenuation', False):
            reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault3_params)

        # ...
        reflectivity = self._apply_geometric_flexure_2d(
            reflectivity, n1, n2,
            x2_ref=fault3_params['x2_ref'],
            dip_top=fault3_params['dip_top'],
            dip_bottom=fault3_params['dip_bottom'],
            i1_start=60,
            i1_end=170,
            flexure_width=90,  # 挠曲影响的横向宽度 (比拖曳宽度大一些)
            max_flexure_depth_shift=20.0  # 在最深处和断层处产生的最大垂直位移 (像素)
        )

        reflectivity = self._apply_vertical_shear_2d(
            reflectivity, n1, n2,
        )
        # 6. 归一化和添加噪声
        image = reflectivity
        image = image / np.std(image)  # 归一化

        if noise > 0:
            noise_array = self.rng.randn(*image.shape)
            noise_array = gaussian_filter(noise_array, sigma=2.0, order=1)
            noise_array = noise_array * noise * np.std(image) / np.std(noise_array)
            image = image + noise_array

        return image

    def _make_reflectivity_2d(self, n1, n2):
        r = 2.0 * self.rng.rand(n1) - 1.0
        r = np.sign(r) * np.abs(r) ** 5
        reflectivity = np.tile(r[:, np.newaxis], (1, n2)).T
        return reflectivity

    def _apply_vertical_shear_2d(self, data, n1, n2, scale=0.02):

        from scipy.ndimage import map_coordinates

        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        coords = np.array([
            i2.astype(float),  # 横向坐标不变
            np.clip(i1 - scale * i2, 0, n1 - 1)  # 深度坐标剪切并裁剪
        ])

        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_geometric_flexure_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, i1_start, i1_end,
                                    flexure_width, max_flexure_depth_shift, **kwargs):
        """
        模拟断层下降盘的几何挠曲/垂向倾斜（逆向拖曳）。
        """
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 1. 计算断层轨迹
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        # 2. 确定下降盘
        if dip_top > 0:
            is_downthrown = (i2 > fault_x2_trace[np.newaxis, :])
            dist_to_fault = i2 - fault_x2_trace[np.newaxis, :]
            shift_direction = -1
        else:
            is_downthrown = (i2 < fault_x2_trace[np.newaxis, :])
            dist_to_fault = fault_x2_trace[np.newaxis, :] - i2
            shift_direction = -1

        # 3. 横向权重
        dist_clamped = np.clip(dist_to_fault, 0, flexure_width)
        horizontal_weight = (flexure_width - dist_clamped) / flexure_width

        # 4. 纵向权重
        i1_norm = np.clip((i1 - i1_start) / (i1_end - i1_start + 1e-6), 0, 1)
        depth_weight = i1_norm

        # 5. 计算最终垂直位移场
        flexure_shift = (
                max_flexure_depth_shift * horizontal_weight * depth_weight * shift_direction
        )

        # 6. 最终位移遮罩
        flexure_mask = is_downthrown & (dist_to_fault > 0) & (dist_to_fault < flexure_width) & (i1 >= i1_start) & (
                i1 < i1_end)

        # 7. 应用位移
        src_i1 = i1.astype(float)
        src_i2 = i2.astype(float)

        src_i1[flexure_mask] = np.clip(src_i1[flexure_mask] + flexure_shift[flexure_mask], 0, n1 - 1)

        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_stratigraphic_wedge_2d(self, data, n1, n2, i1_start, i1_end, x2_start, x2_end, direction='left'):
        """
        模拟地层尖灭或沉积楔。
        """
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        # 1. 定义深度遮罩
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)

        # 2. 定义尖灭区间和横向距离
        x2_min = min(x2_start, x2_end)
        x2_max = max(x2_start, x2_end)
        x2_width = x2_max - x2_min

        if x2_width <= 0:
            return data

        # 3. 计算横向衰减因子
        x2_active = np.clip(i2, x2_min, x2_max)

        if direction == 'left':
            attenuation_factor = (x2_active - x2_min) / x2_width
        elif direction == 'right':
            attenuation_factor = 1.0 - (x2_active - x2_min) / x2_width
        else:
            return data

        # 4. 组合遮罩和应用衰减
        wedge_mask = depth_mask & (i2 >= x2_min) & (i2 < x2_max)

        # 仅在遮罩区域应用衰减
        data[wedge_mask] *= attenuation_factor[wedge_mask]

        return data

    def _apply_sinusoidal_fold_2d_layered(self, data, n1, n2, boundary_i1, upper_params, lower_params):
        """
        应用分层褶皱
        """
        i1_range, i2_range = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        shift = np.zeros_like(i1_range, dtype=float)

        # 上层遮罩
        mask_upper = (i1_range < boundary_i1)
        up = upper_params
        shift[mask_upper] = (up['a1'] + up['b1'] * i1_range[mask_upper]) * \
                            np.sin((up['a2'] + up['b2'] * i2_range[mask_upper]) * i2_range[mask_upper])

        # 下层遮罩
        mask_lower = (i1_range >= boundary_i1)
        low = lower_params
        shift[mask_lower] = (low['a1'] + low['b1'] * i1_range[mask_lower]) * \
                            np.sin((low['a2'] + low['b2'] * i2_range[mask_lower]) * i2_range[mask_lower])

        # 应用位移
        x1_new = i1_range - shift

        coords = np.zeros((2, n2, n1))
        coords[0, :, :] = i2_range
        coords[1, :, :] = np.clip(x1_new, 0, n1 - 1)

        return map_coordinates(data, coords.reshape(2, n2, n1), order=3, mode='nearest')

    def _apply_salt_dome_2d(self, data, n1, n2, dome_center_x2, dome_height, dome_width, i1_start_lift=0,
                            i1_end_lift=None):
        """
        模拟盐丘的上拱 (Drape)
        """
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        if i1_end_lift is None:
            i1_end_lift = n1

        n1_effective = i1_end_lift - i1_start_lift
        if n1_effective <= 0:
            return data

        i1_offset = np.maximum(0, i1 - i1_start_lift)
        i1_norm_raw = i1_offset / n1_effective
        i1_norm_clamped = np.clip(i1_norm_raw, 0, 1)
        uplift_scale = 4 * i1_norm_clamped * (1 - i1_norm_clamped)

        shift = dome_height * np.exp(-((i2 - dome_center_x2) ** 2) / (2 * dome_width ** 2)) * uplift_scale

        src_i1 = np.clip(i1 + shift, 0, n1 - 1)
        src_i2 = i2.astype(float)
        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_curved_normal_fault_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, throw, i1_start, i1_end,
                                      growth_factor=1.0, **kwargs):  # <-- 在这里添加 **kwargs
        """
        模拟弯曲的正断层 (铲状断层)，新增对下降盘的生长效应。
        :param growth_factor: 下降盘的垂直拉伸因子 (1.0 = 无生长, 1.1 = 10% 额外拉伸)。
        """
        # (函数内部的所有代码保持不变)
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([i2.astype(float), i1.astype(float)])

        # 1. 计算断层轨迹 (保持不变)
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        # 2. 侧向遮罩 (Side Mask) - 确定下降盘
        if dip_top > 0:
            # 倾角为正 (>0) 意味着断层向右倾斜，右侧是下降盘
            downthrown_mask = (i2 > fault_x2_trace[np.newaxis, :])
            # 上升盘在左侧
        else:
            # 倾角为负 (<0) 意味着断层向左倾斜，左侧是下降盘
            downthrown_mask = (i2 < fault_x2_trace[np.newaxis, :])
            # 上升盘在右侧

        # 3. 深度遮罩 (Depth Mask) - 确定活动/生长地层范围
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)

        # 4. 最终位移遮罩
        fault_mask = downthrown_mask & depth_mask

        # 5. 应用位移和生长效应

        # 使用基于 i1_start 的拉伸位移
        i1_offset_from_start = coords[1][fault_mask] - i1_start

        # 生长引起的额外位移 (拉伸)
        growth_displacement = i1_offset_from_start * (growth_factor - 1.0)

        # 总位移：(断层落差) + (生长拉伸)
        total_displacement = throw + growth_displacement

        src_i1 = coords[1][fault_mask] - total_displacement

        coords[1][fault_mask] = np.clip(src_i1, 0, n1 - 1)

        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_fault_zone_attenuation_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom,
                                         zone_width, blur_sigma, attenuation_factor, i1_start, i1_end, **kwargs):
        """
        在断层路径周围应用模糊和振幅衰减
        """
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')

        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)

        fault_x2_trace_grid = fault_x2_trace[np.newaxis, :]
        dist_to_fault = np.abs(i2 - fault_x2_trace_grid)
        zone_mask_proximity = (dist_to_fault <= zone_width / 2.0)

        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        zone_mask = zone_mask_proximity & depth_mask

        if np.any(zone_mask):
            blurred_data = gaussian_filter(data, sigma=blur_sigma)
            data[zone_mask] = blurred_data[zone_mask]
            data[zone_mask] *= attenuation_factor
        return data

from scipy.ndimage import gaussian_filter, map_coordinates, zoom

def downsample_x2(img):
    # 可选：轻微低通，减少混叠
    img_lp = gaussian_filter(img, sigma=0.5)
    return zoom(img_lp, zoom=(0.5, 0.5), order=1).astype(np.float32)

def ricker_wavelet(f0=60.0, dt=0.004, length=0.128):
    """零相位 Ricker 子波"""
    t = np.arange(-length/2, length/2 + dt, dt, dtype=np.float32)
    a = (np.pi * f0) ** 2
    w = (1.0 - 2.0 * a * t**2) * np.exp(-a * t**2)
    return w.astype(np.float32)

def convolve_along_depth(img, wavelet):
    """
    沿“深度/时间轴”卷积。
    这里默认深度在 axis=1（与你代码里 img.shape=(n2,n1) 一致）
    """
    n2, n1 = img.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))

    IMG = np.fft.rfft(img, n=nfft, axis=1)
    W = np.fft.rfft(wavelet, n=nfft)
    Y = IMG * W[None, :]

    y = np.fft.irfft(Y, n=nfft, axis=1)
    start = (nw - 1) // 2
    return y[:, start:start + n1].astype(np.float32)

def add_offset_noise(
    img,
    rng,
    snr_db=12.0,
    offset_exp=1.8,
    min_scale=0.35,
    max_scale=1.00,
    bandlimit=True,
    fmin=0.02,
    fmax=0.18,
):
    """
    偏移相关噪声（沿 axis=0 构造偏移权重；沿 axis=1 做带限）
    img: (n2, n1)
    """
    n2, n1 = img.shape
    x = img.astype(np.float32)

    sig_rms = np.sqrt(np.mean(x**2) + 1e-12)
    noise_rms = sig_rms / (10.0 ** (snr_db / 20.0))

    i2 = np.arange(n2, dtype=np.float32)
    center = (n2 - 1) / 2.0
    off = np.abs(i2 - center) / (center + 1e-12)
    w = min_scale + (max_scale - min_scale) * (off ** offset_exp)

    noise = rng.standard_normal((n2, n1)).astype(np.float32)
    noise *= (noise_rms * w)[:, None]

    if bandlimit:
        F = np.fft.rfft(noise, axis=1)
        freqs = np.fft.rfftfreq(n1, d=1.0)  # 归一化频率 0..0.5
        win = np.zeros_like(freqs, dtype=np.float32)
        win[(freqs >= fmin) & (freqs <= fmax)] = 1.0
        F *= win[None, :]
        noise = np.fft.irfft(F, n=n1, axis=1).astype(np.float32)

    return x + noise

# --- 绘图函数 (保持不变) ---
def plot_2d_result(image):
    """(原代码) 绘图函数"""
    fig, axes = plt.subplots(1, 1, figsize=(14, 5))
    axes.imshow(image.T, cmap='gray', aspect='auto', origin='upper')
    axes.set_title('Seismic Image (Geological Model - No Convolution)')
    axes.set_xlabel('X2')
    axes.set_ylabel('X1 (Depth)')
    plt.tight_layout()
    plt.show()
def batch_generate_dat_pairs(
    clean_dir="dataset/clean",
    noisy_dir="dataset/noisy",
    num_models=100,
    n1=512,
    n2=512,
    start_index=1,
    dt=0.004,
    wlen=0.128,
    snr_db=12.0,
):
    os.makedirs(clean_dir, exist_ok=True)
    os.makedirs(noisy_dir, exist_ok=True)

    w30 = ricker_wavelet(f0=30.0, dt=dt, length=wlen)  # clean
    w20 = ricker_wavelet(f0=20.0, dt=dt, length=wlen)  # noisy base

    idx = start_index

    for i in range(num_models):
        seed = 31 + i
        gen = GeologicalSeismicData(seed=seed)

        # 1) 生成 512x512 反射系数模型
        model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0)

        # 2) clean：30Hz 卷积，无噪，尺寸 512x512
        clean = convolve_along_depth(model, w30)
        clean = clean - np.mean(clean)
        clean = clean / (np.std(clean) + 1e-12)

        # 3) noisy：20Hz 卷积 + 噪声（先在 512 上做），再降采样到 256
        base = convolve_along_depth(model, w20)
        base = base - np.mean(base)
        base = base / (np.std(base) + 1e-12)

        noisy512 = add_offset_noise(
            base,
            rng=np.random.default_rng(seed * 100000 + idx),
            snr_db=snr_db,
            offset_exp=1.8,
            min_scale=0.35,
            max_scale=1.00,
            bandlimit=True
        ).astype(np.float32)

        noisy256 = downsample_x2(noisy512)

        # 4) 保存：clean(512) 与 noisy(256) 同名一一对应
        fname = f"{idx:04d}.dat"
        clean.astype(np.float32).tofile(os.path.join(clean_dir, fname))
        noisy256.astype(np.float32).tofile(os.path.join(noisy_dir, fname))
        idx += 1

        if (i + 1) % 10 == 0:
            print(f"[{i+1}/{num_models}] done, total pairs: {idx - start_index}")

def batch_generate(
        out_dir="outputs",
        num_samples=10,
        n1=512,
        n2=512,
        save_numpy=False
):
    """
    批量生成 2D 未卷积反射界面图
    """
    os.makedirs(out_dir, exist_ok=True)

    for i in range(num_samples):
        seed = 31 + i   # 每张图生成不同构造
        gen = GeologicalSeismicData(seed=seed)

        img = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0)

        # 保存图片
        plt.figure(figsize=(14, 5))
        plt.imshow(img.T, cmap="gray", aspect="auto", origin="upper")
        plt.title(f"sample_{i:03d}, seed={seed}")
        plt.xlabel("X2")
        plt.ylabel("Depth")
        plt.tight_layout()

        out_path = os.path.join(out_dir, f"reflectivity_{i:03d}.png")
        plt.savefig(out_path, dpi=150)
        plt.close()

        # 保存 .npy 数据
        if save_numpy:
            np.save(os.path.join(out_dir, f"reflectivity_{i:03d}.npy"), img)

        print(f"[OK] Saved {out_path}")

    print(f"\nAll {num_samples} samples saved to folder: {out_dir}")


if __name__ == "__main__":
    batch_generate_dat_pairs(
        clean_dir="dataset3301-30hz/clean",
        noisy_dir="dataset3301-20hz/noisy",
        num_models=900,
        n1=512,
        n2=512,
        start_index=3301,
        dt=0.004,
        wlen=0.128,
        snr_db=8.0
    )

