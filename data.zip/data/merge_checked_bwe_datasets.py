# -*- coding: utf-8 -*-
r"""
Merge four CHECKED waveform-preserving BWE datasets into one OS-DeltaDiff-ready dataset.

Default input datasets:
  D:\dateset0309\dataset_waveform_bwe_multistruct_spacevarying_v2_stronger_checked
  D:\dateset0309\dataset_waveform_bwe_multistruct_stationary_v2_stronger_ok_checked
  D:\dateset0309\dataset_waveform_bwe_multistruct_timespace_ormsby_v6_weaker_checked
  D:\dateset0309\dataset_waveform_bwe_multistruct_timevarying_v1_checked

Default output dataset:
  D:\dateset0309\dataset_waveform_bwe_osdeltadiff_clean_checked_v1

Output layout:
  OUT_ROOT/
    train/lq/*.dat
    train/gt/*.dat
    train/meta/*.json
    train/wavelets/*
    train/qc/*                  # only samples with existing QC figures are copied
    val/lq/*.dat
    val/gt/*.dat
    val/meta/*.json
    val/wavelets/*
    val/qc/*
    sample_index.csv
    train_index.csv
    val_index.csv
    sample_count.json

Usage:
  D:\python\python.exe D:\dateset0309\merge_checked_bwe_datasets.py

Optional:
  D:\python\python.exe D:\dateset0309\merge_checked_bwe_datasets.py --out_root D:\dateset0309\dataset_waveform_bwe_osdeltadiff_clean_checked_v1 --overwrite

Notes:
  1) This script renames every sample to a unique global ID, so 0001.dat from different source datasets will not collide.
  2) Train/val split is stratified by source_dataset + variation + family + structure + phase_group.
  3) If pair self-check info exists in meta, samples whose status is not "ok" are skipped by default.
  4) It uses hard links by default when possible, so merging is fast and does not duplicate disk space. If hard link fails, it falls back to copying.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import random
import shutil
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


# =========================================================
# 0. Configuration
# =========================================================
BASE_DIR = Path(r"D:\dateset0309")

DATASETS = [
    {
        "name": "spacevarying",
        "variation": "space",
        "root": BASE_DIR / "dataset_waveform_bwe_multistruct_spacevarying_v2_stronger_checked",
    },
    {
        "name": "stationary",
        "variation": "stationary",
        "root": BASE_DIR / "dataset_waveform_bwe_multistruct_stationary_v2_stronger_ok_checked",
    },
    {
        "name": "timespace_ormsby",
        "variation": "time_space",
        "root": BASE_DIR / "dataset_waveform_bwe_multistruct_timespace_ormsby_v6_weaker_checked",
    },
    {
        "name": "timevarying",
        "variation": "time",
        "root": BASE_DIR / "dataset_waveform_bwe_multistruct_timevarying_v1_checked",
    },
]

OUT_ROOT = BASE_DIR / "dataset_waveform_bwe_osdeltadiff_clean_checked_v1"
VAL_RATIO = 0.10
RANDOM_SEED = 2026

# If one source dataset is too large, set a number here.
# Example: {"timespace_ormsby": 600}. None means use all samples.
MAX_SAMPLES_PER_DATASET: Dict[str, Optional[int]] = {
    "spacevarying": None,
    "stationary": None,
    "timespace_ormsby": None,
    "timevarying": None,
}

# Expected .dat size check. Shape is [trace, sample] = [N2, N1].
N1 = 512
N2 = 512
EXPECTED_DAT_BYTES = N1 * N2 * 4  # float32

# Safety switches.
OVERWRITE_OUT_ROOT = True
USE_HARDLINK_WHEN_POSSIBLE = True
REQUIRE_PAIR_SELF_CHECK_OK = True
ALLOW_MISSING_PAIR_SELF_CHECK = True
COPY_QC_IF_EXISTS = True
COPY_SOURCE_INDEX_FILES = True


# =========================================================
# 1. Helpers
# =========================================================
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Merge checked BWE datasets for OS-DeltaDiff training.")
    parser.add_argument("--out_root", type=str, default=str(OUT_ROOT), help="Output merged dataset root.")
    parser.add_argument("--val_ratio", type=float, default=VAL_RATIO, help="Validation ratio, default 0.10.")
    parser.add_argument("--seed", type=int, default=RANDOM_SEED, help="Random seed for stratified split.")
    parser.add_argument("--overwrite", action="store_true", default=OVERWRITE_OUT_ROOT, help="Overwrite output root if exists.")
    parser.add_argument("--copy", action="store_true", help="Use physical copy instead of hard links.")
    parser.add_argument("--keep_bad_pair_check", action="store_true", help="Do not skip meta samples whose pair-check status is not ok.")
    return parser.parse_args()


def reset_and_make_dirs(out_root: Path, overwrite: bool) -> None:
    if out_root.exists() and overwrite:
        print(f"[RESET] Removing old output directory: {out_root}")
        shutil.rmtree(out_root)
    elif out_root.exists() and any(out_root.iterdir()):
        raise FileExistsError(
            f"Output directory already exists and is not empty: {out_root}\n"
            f"Use --overwrite or change OUT_ROOT."
        )

    for split in ["train", "val"]:
        for sub in ["lq", "gt", "meta", "wavelets", "qc"]:
            (out_root / split / sub).mkdir(parents=True, exist_ok=True)
    if COPY_SOURCE_INDEX_FILES:
        (out_root / "source_indices").mkdir(parents=True, exist_ok=True)


def phase_group(phase_deg: Any, eps: float = 1e-6) -> str:
    try:
        v = float(phase_deg)
    except Exception:
        v = 0.0
    return "zero_phase" if abs(v) <= eps else "with_phase"


def read_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def safe_link_or_copy(src: Path, dst: Path, use_hardlink: bool = True) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()
    if use_hardlink:
        try:
            os.link(src, dst)
            return
        except Exception:
            pass
    shutil.copy2(src, dst)


def dat_size_ok(path: Path) -> bool:
    try:
        return path.stat().st_size == EXPECTED_DAT_BYTES
    except Exception:
        return False


def get_pair_check(meta: Dict[str, Any]) -> Tuple[Optional[str], Dict[str, Any]]:
    """Return (status, check_dict) from possible pair-check keys."""
    candidate_keys = [
        "pair_alignment_check",
        "pair_self_check",
        "pair_check",
        "pair_selfcheck",
        "pair_alignment",
    ]
    for k in candidate_keys:
        v = meta.get(k)
        if isinstance(v, dict):
            status = v.get("status") or v.get("pair_status") or v.get("result")
            return (str(status) if status is not None else None), v
    return None, {}


def source_index_backup(root: Path, out_root: Path, ds_name: str) -> None:
    if not COPY_SOURCE_INDEX_FILES:
        return
    for name in ["sample_index.csv", "sample_count.json"]:
        p = root / name
        if p.exists():
            dst = out_root / "source_indices" / f"{ds_name}_{name}"
            shutil.copy2(p, dst)


def load_source_rows(ds: Dict[str, Any], rng: random.Random, keep_bad_pair_check: bool) -> List[Dict[str, Any]]:
    root = Path(ds["root"])
    lq_dir = root / "lq"
    gt_dir = root / "gt"
    meta_dir = root / "meta"
    wavelet_dir = root / "wavelets"
    qc_dir = root / "qc"

    if not root.exists():
        raise FileNotFoundError(f"Dataset root not found: {root}")
    if not lq_dir.exists() or not gt_dir.exists():
        raise FileNotFoundError(f"Missing lq/gt folder under: {root}")

    gt_map = {p.stem: p for p in gt_dir.glob("*.dat")}
    lq_files = sorted(lq_dir.glob("*.dat"))

    rows: List[Dict[str, Any]] = []
    skip_counts = Counter()

    for lq_path in lq_files:
        source_id = lq_path.stem
        gt_path = gt_map.get(source_id)
        if gt_path is None:
            skip_counts["missing_gt"] += 1
            continue

        if not dat_size_ok(lq_path) or not dat_size_ok(gt_path):
            skip_counts["bad_dat_size"] += 1
            print(f"[SKIP] bad dat size: {lq_path.name}")
            continue

        meta_path = meta_dir / f"{source_id}.json"
        meta = read_json(meta_path)

        check_status, check_info = get_pair_check(meta)
        if REQUIRE_PAIR_SELF_CHECK_OK and check_status is not None and check_status != "ok" and not keep_bad_pair_check:
            skip_counts[f"pair_check_{check_status}"] += 1
            print(f"[SKIP] pair self-check not ok: {ds['name']} {source_id} status={check_status}")
            continue
        if REQUIRE_PAIR_SELF_CHECK_OK and check_status is None and not ALLOW_MISSING_PAIR_SELF_CHECK and not keep_bad_pair_check:
            skip_counts["missing_pair_check"] += 1
            print(f"[SKIP] missing pair self-check: {ds['name']} {source_id}")
            continue

        family = str(meta.get("family", "unknown"))
        variation = str(meta.get("variation", ds.get("variation", "unknown")))
        structure = str(meta.get("structure", "unknown"))
        phase_deg = meta.get("phase_deg", 0.0)
        ph_group = str(meta.get("phase_group", phase_group(phase_deg)))

        qc_path = qc_dir / f"{source_id}_qc.png"
        if not qc_path.exists():
            qc_path = None

        rows.append({
            "source_dataset": ds["name"],
            "source_root": str(root),
            "source_id": source_id,
            "source_lq_path": lq_path,
            "source_gt_path": gt_path,
            "source_meta_path": meta_path if meta_path.exists() else None,
            "source_wavelet_dir": wavelet_dir if wavelet_dir.exists() else None,
            "source_qc_path": qc_path,
            "variation": variation,
            "family": family,
            "structure": structure,
            "phase_deg": phase_deg,
            "phase_group": ph_group,
            "pair_check_status": check_status or "missing",
            "pair_check_same_corr": check_info.get("same_corr", check_info.get("same_env_corr", "")),
            "pair_check_best_orientation": check_info.get("best_orientation", check_info.get("best", "")),
            "meta": meta,
        })

    # Optional per-dataset cap, stratified-ish by shuffle after loading.
    max_n = MAX_SAMPLES_PER_DATASET.get(ds["name"])
    if max_n is not None and len(rows) > int(max_n):
        rng.shuffle(rows)
        rows = rows[:int(max_n)]
        rows = sorted(rows, key=lambda x: x["source_id"])
        print(f"[CAP] {ds['name']}: capped to {len(rows)} samples")

    print(f"[LOAD] {ds['name']}: kept={len(rows)} from {root}")
    if skip_counts:
        print(f"       skipped={dict(skip_counts)}")
    return rows


def stratified_split(rows: List[Dict[str, Any]], val_ratio: float, seed: int) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    rng = random.Random(seed)
    groups: Dict[Tuple[str, str, str, str, str], List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        key = (
            r.get("source_dataset", ""),
            r.get("variation", ""),
            r.get("family", ""),
            r.get("structure", ""),
            r.get("phase_group", ""),
        )
        groups[key].append(r)

    train_rows: List[Dict[str, Any]] = []
    val_rows: List[Dict[str, Any]] = []

    for key, items in sorted(groups.items(), key=lambda kv: str(kv[0])):
        items = list(items)
        rng.shuffle(items)
        n = len(items)
        if n <= 1:
            n_val = 0
        elif n < 5:
            n_val = 1
        else:
            n_val = max(1, int(round(n * val_ratio)))
            n_val = min(n_val, n - 1)
        val_rows.extend(items[:n_val])
        train_rows.extend(items[n_val:])

    rng.shuffle(train_rows)
    rng.shuffle(val_rows)
    return train_rows, val_rows


def copy_wavelet_files(src_wavelet_dir: Optional[Path], source_id: str, dst_wavelet_dir: Path, new_id: str, use_hardlink: bool) -> str:
    if src_wavelet_dir is None or not src_wavelet_dir.exists():
        return ""
    copied: List[str] = []
    for src in sorted(src_wavelet_dir.glob(f"{source_id}*")):
        if not src.is_file():
            continue
        dst_name = src.name.replace(source_id, new_id, 1)
        dst = dst_wavelet_dir / dst_name
        safe_link_or_copy(src, dst, use_hardlink=use_hardlink)
        copied.append(str(dst))
    return ";".join(copied)


def write_csv(path: Path, rows: Iterable[Dict[str, Any]], fields: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})


def copy_one_split(split: str, rows: List[Dict[str, Any]], out_root: Path, start_idx: int, use_hardlink: bool) -> Tuple[List[Dict[str, Any]], int]:
    final_rows: List[Dict[str, Any]] = []
    idx = start_idx

    for r in rows:
        new_id = f"{idx:06d}"
        fname = f"{new_id}.dat"

        dst_lq = out_root / split / "lq" / fname
        dst_gt = out_root / split / "gt" / fname
        dst_meta = out_root / split / "meta" / f"{new_id}.json"
        dst_wavelet_dir = out_root / split / "wavelets"

        safe_link_or_copy(Path(r["source_lq_path"]), dst_lq, use_hardlink=use_hardlink)
        safe_link_or_copy(Path(r["source_gt_path"]), dst_gt, use_hardlink=use_hardlink)

        wavelet_paths = copy_wavelet_files(
            r.get("source_wavelet_dir"),
            str(r["source_id"]),
            dst_wavelet_dir,
            new_id,
            use_hardlink=use_hardlink,
        )

        qc_path_out = ""
        if COPY_QC_IF_EXISTS and r.get("source_qc_path") is not None:
            src_qc = Path(r["source_qc_path"])
            if src_qc.exists():
                dst_qc = out_root / split / "qc" / f"{new_id}_qc.png"
                safe_link_or_copy(src_qc, dst_qc, use_hardlink=use_hardlink)
                qc_path_out = str(dst_qc)

        meta = dict(r.get("meta", {}))
        meta.update({
            "id": new_id,
            "split": split,
            "merged_dataset": out_root.name,
            "source_dataset": r["source_dataset"],
            "source_root": r["source_root"],
            "source_id": r["source_id"],
            "source_lq_path": str(r["source_lq_path"]),
            "source_gt_path": str(r["source_gt_path"]),
            "merged_lq_path": str(dst_lq),
            "merged_gt_path": str(dst_gt),
            "n1": int(meta.get("n1", N1)),
            "n2": int(meta.get("n2", N2)),
            "merge_pair_check_status": r.get("pair_check_status", ""),
            "merge_pair_check_same_corr": r.get("pair_check_same_corr", ""),
            "merge_pair_check_best_orientation": r.get("pair_check_best_orientation", ""),
        })
        write_json(dst_meta, meta)

        final_row = {
            "id": new_id,
            "split": split,
            "source_dataset": r["source_dataset"],
            "source_id": r["source_id"],
            "variation": r.get("variation", ""),
            "family": r.get("family", ""),
            "structure": r.get("structure", ""),
            "phase_deg": r.get("phase_deg", 0.0),
            "phase_group": r.get("phase_group", ""),
            "pair_check_status": r.get("pair_check_status", ""),
            "pair_check_same_corr": r.get("pair_check_same_corr", ""),
            "pair_check_best_orientation": r.get("pair_check_best_orientation", ""),
            "lq_path": str(dst_lq),
            "gt_path": str(dst_gt),
            "meta_path": str(dst_meta),
            "wavelet_paths": wavelet_paths,
            "qc_path": qc_path_out,
        }
        final_rows.append(final_row)
        idx += 1

    return final_rows, idx


def main() -> None:
    args = parse_args()
    out_root = Path(args.out_root)
    use_hardlink = USE_HARDLINK_WHEN_POSSIBLE and not args.copy
    keep_bad_pair_check = bool(args.keep_bad_pair_check)

    reset_and_make_dirs(out_root, overwrite=bool(args.overwrite))

    rng = random.Random(int(args.seed))
    all_rows: List[Dict[str, Any]] = []

    for ds in DATASETS:
        root = Path(ds["root"])
        source_index_backup(root, out_root, ds["name"])
        rows = load_source_rows(ds, rng=rng, keep_bad_pair_check=keep_bad_pair_check)
        all_rows.extend(rows)

    if not all_rows:
        raise RuntimeError("No usable samples found. Check dataset paths and pair-check statuses.")

    train_rows, val_rows = stratified_split(all_rows, val_ratio=float(args.val_ratio), seed=int(args.seed))
    print(f"[SPLIT] train={len(train_rows)}, val={len(val_rows)}, total={len(all_rows)}")

    final_rows: List[Dict[str, Any]] = []
    next_id = 1
    copied_train, next_id = copy_one_split("train", train_rows, out_root, next_id, use_hardlink=use_hardlink)
    copied_val, next_id = copy_one_split("val", val_rows, out_root, next_id, use_hardlink=use_hardlink)
    final_rows.extend(copied_train)
    final_rows.extend(copied_val)

    fields = [
        "id", "split", "source_dataset", "source_id", "variation", "family", "structure",
        "phase_deg", "phase_group", "pair_check_status", "pair_check_same_corr",
        "pair_check_best_orientation", "lq_path", "gt_path", "meta_path", "wavelet_paths", "qc_path",
    ]
    write_csv(out_root / "sample_index.csv", final_rows, fields)
    write_csv(out_root / "train_index.csv", [r for r in final_rows if r["split"] == "train"], fields)
    write_csv(out_root / "val_index.csv", [r for r in final_rows if r["split"] == "val"], fields)

    counts = {
        "total": len(final_rows),
        "train": sum(1 for r in final_rows if r["split"] == "train"),
        "val": sum(1 for r in final_rows if r["split"] == "val"),
        "by_split_source_dataset": dict(Counter(f"{r['split']}|{r['source_dataset']}" for r in final_rows)),
        "by_split_variation": dict(Counter(f"{r['split']}|{r['variation']}" for r in final_rows)),
        "by_split_family": dict(Counter(f"{r['split']}|{r['family']}" for r in final_rows)),
        "by_split_structure": dict(Counter(f"{r['split']}|{r['structure']}" for r in final_rows)),
        "by_split_phase": dict(Counter(f"{r['split']}|{r['phase_group']}" for r in final_rows)),
        "pair_check_status": dict(Counter(r.get("pair_check_status", "") for r in final_rows)),
        "settings": {
            "val_ratio": float(args.val_ratio),
            "seed": int(args.seed),
            "use_hardlink": bool(use_hardlink),
            "require_pair_self_check_ok": bool(REQUIRE_PAIR_SELF_CHECK_OK),
            "allow_missing_pair_self_check": bool(ALLOW_MISSING_PAIR_SELF_CHECK),
            "max_samples_per_dataset": MAX_SAMPLES_PER_DATASET,
            "expected_dat_shape": [N2, N1],
            "expected_dat_dtype": "float32",
        },
        "source_roots": {ds["name"]: str(ds["root"]) for ds in DATASETS},
    }
    write_json(out_root / "sample_count.json", counts)

    print("\n[DONE] Merged dataset saved to:")
    print(f"  {out_root}")
    print("\nUse these folders in your YAML:")
    print(f"  train lr_dir: {out_root / 'train' / 'lq'}")
    print(f"  train hr_dir: {out_root / 'train' / 'gt'}")
    print(f"  val   lr_dir: {out_root / 'val' / 'lq'}")
    print(f"  val   hr_dir: {out_root / 'val' / 'gt'}")
    print("\nCounts:")
    print(json.dumps(counts, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
