# -*- coding: utf-8 -*-
"""
Multi-structure time-varying wavelet waveform-preserving bandwidth-extension dataset generator.

目标：
- 多结构 + 三子波（ricker / ormsby / klauder）
- time-varying wavelet: 子波只随深度/时间变化，不随横向变化
- 无噪声、同尺寸 LQ/GT（512x512 -> 512x512）
- LQ/GT 同源：同一深度位置的 GT 子波平滑包络 LQ 子波

使用方式：
把本脚本放到和以下构造生成脚本同一个文件夹：
  dongyingbatch.py
  helanjinhaiyanpendi.py
  huazhuang.py
  malinbatch_noise_dat.py
  malinbatchnewfold&noise&q.py
  tixingyanqiubatch_noise_dat.py

运行：
  python multi_structure_timevarying_bwe_v1.py

输出：
  dataset_waveform_bwe_multistruct_timevarying_v1/
    lq/*.dat
    gt/*.dat
    meta/*.json
    wavelets/*_w_lq.npy            # 中部代表子波，兼容原 split 脚本
    wavelets/*_w_gt.npy            # 中部代表子波，兼容原 split 脚本
    wavelets/*_wavelet_field.npz   # top/mid/bottom 代表子波与深度位置
    qc/*.png
"""

import csv
import json
import math
import shutil
import importlib.util
from pathlib import Path
from collections import Counter

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert


# =========================================================
# 0. 配置区：主要改这里
# =========================================================
SCRIPT_DIR = Path(__file__).resolve().parent

SOURCE_SCRIPTS = [
    {"name": "dongying",        "file": "dongyingbatch.py"},
    {"name": "helan_basin",     "file": "helanjinhaiyanpendi.py"},
    {"name": "huazhuang",       "file": "huazhuang.py"},
    {"name": "malin",           "file": "malinbatch_noise_dat.py"},
    {"name": "malin_newfold",   "file": "malinbatchnewfold&noise&q.py"},
    {"name": "tixing_salt",     "file": "tixingyanqiubatch_noise_dat.py"},
]

# 每种反射结构生成多少个样本。先小规模 QC，满意后再改大。
NUM_PER_STRUCTURE = 20

# 输出尺寸
N1 = 512
N2 = 512

DT = 0.004
WAVELET_LENGTH = 0.256

# 非平稳卷积窗口：win 越大变化越平滑，step 越小越平滑但更慢
TV_WIN = 128
TV_STEP = 32

OUT_DIR = SCRIPT_DIR / "dataset_waveform_bwe_multistruct_timevarying_v1"
LQ_DIR = OUT_DIR / "lq"
GT_DIR = OUT_DIR / "gt"
META_DIR = OUT_DIR / "meta"
WAVELET_DIR = OUT_DIR / "wavelets"
QC_DIR = OUT_DIR / "qc"

START_INDEX = 1
FAMILY_RATIO = {"ricker": 0.40, "ormsby": 0.40, "klauder": 0.20}

# 相位：这里允许常相位 + 很弱的深度漂移；LQ/GT 在同一深度使用完全相同相位。
PHASE_PROB = 0.50
PHASE_RANGE = (-30.0, 30.0)
PHASE_DRIFT_RANGE = (-8.0, 8.0)

QC_FIRST_N = 5
QC_EVERY = 50
RANDOM_SEED = 2026
COPY_SOURCE_SCRIPTS = True

# QC 中展示 top/mid/bottom 三个深度位置的局部子波
REP_DEPTHS = [0.15, 0.50, 0.85]
REP_NAMES = ["top", "middle", "bottom"]


# =========================================================
# 1. 基础工具函数
# =========================================================
def ensure_dirs():
    for d in [LQ_DIR, GT_DIR, META_DIR, WAVELET_DIR, QC_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def sanitize_float(x):
    return float(np.asarray(x).item())


def time_axis(dt=0.004, length=0.256):
    return np.arange(-length / 2.0, length / 2.0 + 0.5 * dt, dt, dtype=np.float32)


def normalize_wavelet(w):
    w = np.asarray(w, dtype=np.float64)
    w = w - np.mean(w)
    m = np.max(np.abs(w))
    if m > 1e-12:
        w = w / m
    return w.astype(np.float32)


def phase_rotate(w, phase_deg=0.0):
    w = np.asarray(w, dtype=np.float64)
    if abs(float(phase_deg)) < 1e-12:
        return normalize_wavelet(w)
    wh = np.imag(hilbert(w))
    phi = np.deg2rad(float(phase_deg))
    wp = np.cos(phi) * w - np.sin(phi) * wh
    return normalize_wavelet(wp)


def centered_wavelet_from_amp(amp, n_wavelet, nfft):
    amp = np.asarray(amp, dtype=np.float64)
    amp = np.maximum(amp, 0.0)
    amp[0] = 0.0
    w_full = np.fft.irfft(amp.astype(np.complex128), n=nfft)
    w_full = np.fft.fftshift(w_full)
    center = nfft // 2
    half = n_wavelet // 2
    start = center - half
    w = w_full[start:start + n_wavelet]
    return normalize_wavelet(w)


def high_frequency_taper(freqs, f_start=100.0, f_end=124.0):
    taper = np.ones_like(freqs, dtype=np.float64)
    taper[freqs >= f_end] = 0.0
    m = (freqs > f_start) & (freqs < f_end)
    if np.any(m):
        x = (freqs[m] - f_start) / (f_end - f_start + 1e-12)
        taper[m] = 0.5 + 0.5 * np.cos(np.pi * x)
    return taper


def smooth_max(a, b, p=8.0):
    a = np.maximum(np.asarray(a, dtype=np.float64), 0.0)
    b = np.maximum(np.asarray(b, dtype=np.float64), 0.0)
    return (a ** p + b ** p) ** (1.0 / p)


def ricker_amp_spectrum(freqs, f0):
    freqs = np.asarray(freqs, dtype=np.float64)
    x = freqs / (float(f0) + 1e-12)
    amp = (x ** 2) * np.exp(-(x ** 2))
    amp[0] = 0.0
    amp = amp / (np.max(amp) + 1e-12)
    return amp


def generalized_ricker_amp_spectrum(freqs, f0, alpha=1.15, power=1.30):
    freqs = np.asarray(freqs, dtype=np.float64)
    x = np.maximum(freqs / (float(f0) + 1e-12), 0.0)
    alpha = float(alpha)
    power = float(power)
    amp = (x ** alpha) * np.exp((alpha / (power + 1e-12)) * (1.0 - x ** power))
    amp[0] = 0.0
    amp = amp / (np.max(amp) + 1e-12)
    return amp


def trapezoid_amp(freqs, f1, f2, f3, f4):
    freqs = np.asarray(freqs, dtype=np.float64)
    amp = np.zeros_like(freqs, dtype=np.float64)
    m = (freqs >= f1) & (freqs < f2)
    if np.any(m):
        amp[m] = (freqs[m] - f1) / (f2 - f1 + 1e-12)
    amp[(freqs >= f2) & (freqs <= f3)] = 1.0
    m = (freqs > f3) & (freqs <= f4)
    if np.any(m):
        amp[m] = 1.0 - (freqs[m] - f3) / (f4 - f3 + 1e-12)
    return np.clip(amp, 0.0, 1.0)


def sweep_band_amp(freqs, f_start, f_end, taper=4.0):
    freqs = np.asarray(freqs, dtype=np.float64)
    f_start = float(f_start)
    f_end = float(f_end)
    taper = float(taper)
    if f_end <= f_start:
        raise ValueError(f"Invalid sweep band: {f_start}, {f_end}")
    taper = max(0.5, min(taper, 0.45 * (f_end - f_start)))
    amp = np.zeros_like(freqs, dtype=np.float64)

    f1 = max(0.0, f_start - taper)
    f2 = f_start + taper
    m = (freqs >= f1) & (freqs < f2)
    if np.any(m):
        x = (freqs[m] - f1) / (f2 - f1 + 1e-12)
        amp[m] = 0.5 - 0.5 * np.cos(np.pi * x)

    m = (freqs >= f2) & (freqs <= f_end - taper)
    amp[m] = 1.0

    m_mid = (freqs >= f_start) & (freqs <= f_end)
    amp[m_mid] = np.maximum(amp[m_mid], 0.85)

    f3 = f_end - taper
    f4 = f_end + taper
    m = (freqs > f3) & (freqs <= f4)
    if np.any(m):
        x = (freqs[m] - f3) / (f4 - f3 + 1e-12)
        amp[m] = np.maximum(amp[m], 0.5 + 0.5 * np.cos(np.pi * x))

    amp[freqs <= 0.0] = 0.0
    return np.clip(amp, 0.0, 1.0)


def amplitude_spectrum(w, dt=0.004, nfft=4096):
    w = np.asarray(w, dtype=np.float32)
    W = np.fft.rfft(w, n=nfft)
    amp = np.abs(W)
    amp = amp / (np.max(amp) + 1e-12)
    f = np.fft.rfftfreq(nfft, d=dt)
    return f, amp


def interp1(depth_norm, anchors, values):
    return float(np.interp(float(depth_norm), anchors, values))


def interp_vec(depth_norm, anchors, values_2d):
    values_2d = np.asarray(values_2d, dtype=np.float64)
    return np.array([np.interp(float(depth_norm), anchors, values_2d[:, k]) for k in range(values_2d.shape[1])], dtype=np.float64)


def smooth_random_curve(rng, start, end, anchors, jitter=0.0, enforce_desc=False, enforce_asc=False):
    vals = np.linspace(float(start), float(end), len(anchors))
    if jitter > 0:
        vals += rng.normal(0.0, jitter, size=len(anchors))
        vals[0] = float(start)
        vals[-1] = float(end)
    if enforce_desc:
        vals = np.maximum.accumulate(vals[::-1])[::-1]
    if enforce_asc:
        vals = np.maximum.accumulate(vals)
    return vals.astype(np.float64)


# =========================================================
# 2. 局部子波生成：给定局部参数 -> w_lq / w_gt
# =========================================================
def ricker_pair_from_params(f0_lq, alpha_gt, power_gt, gamma, phase_deg, dt=0.004, length=0.256):
    n = len(time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)

    A_lq = ricker_amp_spectrum(freqs, f0_lq)
    A_wide = generalized_ricker_amp_spectrum(freqs, f0=f0_lq, alpha=alpha_gt, power=power_gt)
    A_wide = A_wide ** gamma
    A_wide[0] = 0.0
    A_gt = smooth_max(A_wide, A_lq, p=8.0)
    A_gt *= high_frequency_taper(freqs, f_start=105.0, f_end=124.0)
    A_gt = A_gt / (np.max(A_gt) + 1e-12)

    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)
    return phase_rotate(w_lq0, phase_deg), phase_rotate(w_gt0, phase_deg)


def ormsby_pair_from_bands(band_lq, band_gt, phase_deg, dt=0.004, length=0.256):
    n = len(time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)
    A_lq = trapezoid_amp(freqs, *band_lq)
    A_gt_raw = trapezoid_amp(freqs, *band_gt)
    A_gt = smooth_max(A_gt_raw, A_lq, p=10.0)
    A_gt *= high_frequency_taper(freqs, f_start=108.0, f_end=124.0)
    A_gt[0] = 0.0
    A_gt = A_gt / (np.max(A_gt) + 1e-12)
    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)
    return phase_rotate(w_lq0, phase_deg), phase_rotate(w_gt0, phase_deg)


def klauder_pair_from_sweep(sweep_lq, sweep_gt, taper_lq, taper_gt, phase_deg, dt=0.004, length=0.256):
    n = len(time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)
    A_lq = sweep_band_amp(freqs, sweep_lq[0], sweep_lq[1], taper=taper_lq)
    A_gt_raw = sweep_band_amp(freqs, sweep_gt[0], sweep_gt[1], taper=taper_gt)
    A_gt = smooth_max(A_gt_raw, A_lq, p=10.0)
    A_gt *= high_frequency_taper(freqs, f_start=100.0, f_end=124.0)
    A_gt[0] = 0.0
    A_gt = A_gt / (np.max(A_gt) + 1e-12)
    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)
    return phase_rotate(w_lq0, phase_deg), phase_rotate(w_gt0, phase_deg)


def make_phase_curve(rng, anchors):
    if rng.random() >= PHASE_PROB:
        return np.zeros(len(anchors), dtype=np.float64), 0.0
    base = float(rng.uniform(PHASE_RANGE[0], PHASE_RANGE[1]))
    if abs(base) < 3.0:
        base = 3.0 if base >= 0 else -3.0
    drift = float(rng.uniform(PHASE_DRIFT_RANGE[0], PHASE_DRIFT_RANGE[1]))
    curve = np.linspace(base - 0.5 * drift, base + 0.5 * drift, len(anchors))
    return curve.astype(np.float64), base


# =========================================================
# 3. time-varying 子波场工厂
# =========================================================
def make_timevarying_wavelet_model(rng, forced_family=None, dt=0.004, length=0.256):
    """
    返回：
      wavelet_func(depth_norm) -> w_lq, w_gt, local_meta
      meta_global
    """
    if forced_family is None:
        families = list(FAMILY_RATIO.keys())
        probs = np.array([FAMILY_RATIO[k] for k in families], dtype=np.float64)
        probs = probs / probs.sum()
        family = str(rng.choice(families, p=probs))
    else:
        family = str(forced_family)

    anchors = np.array([0.0, 0.33, 0.66, 1.0], dtype=np.float64)
    phase_curve, phase_base = make_phase_curve(rng, anchors)

    if family == "ricker":
        # 浅层主频高，深层主频低。GT 仍在每个深度处包络 LQ。
        f0_top = float(rng.uniform(22.0, 28.0))
        f0_bottom = float(rng.uniform(13.0, 18.0))
        f0_curve = smooth_random_curve(rng, f0_top, f0_bottom, anchors, jitter=0.8, enforce_desc=True)
        alpha_curve = smooth_random_curve(rng, rng.uniform(1.00, 1.20), rng.uniform(1.10, 1.35), anchors, jitter=0.04)
        power_curve = smooth_random_curve(rng, rng.uniform(1.10, 1.35), rng.uniform(1.25, 1.55), anchors, jitter=0.04)
        gamma_curve = smooth_random_curve(rng, rng.uniform(0.68, 0.84), rng.uniform(0.72, 0.90), anchors, jitter=0.03)

        def wavelet_func(depth_norm):
            f0 = interp1(depth_norm, anchors, f0_curve)
            alpha = interp1(depth_norm, anchors, alpha_curve)
            power = interp1(depth_norm, anchors, power_curve)
            gamma = interp1(depth_norm, anchors, gamma_curve)
            phase = interp1(depth_norm, anchors, phase_curve)
            w_lq, w_gt = ricker_pair_from_params(f0, alpha, power, gamma, phase, dt=dt, length=length)
            return w_lq, w_gt, {
                "depth_norm": sanitize_float(depth_norm),
                "f0_lq": sanitize_float(f0),
                "alpha_gt": sanitize_float(alpha),
                "power_gt": sanitize_float(power),
                "gamma": sanitize_float(gamma),
                "phase_deg": sanitize_float(phase),
            }

        meta = {
            "family": "ricker",
            "variation": "time",
            "stationary": False,
            "time_varying": True,
            "space_varying": False,
            "noise": False,
            "same_size": True,
            "phase_deg": sanitize_float(phase_base),
            "depth_anchors": [sanitize_float(x) for x in anchors],
            "f0_lq_curve": [sanitize_float(x) for x in f0_curve],
            "alpha_gt_curve": [sanitize_float(x) for x in alpha_curve],
            "power_gt_curve": [sanitize_float(x) for x in power_curve],
            "gamma_curve": [sanitize_float(x) for x in gamma_curve],
            "phase_curve": [sanitize_float(x) for x in phase_curve],
            "tv_rule": "Ricker-derived time-varying: f0 decreases with depth; GT uses generalized smooth broadband envelope at each depth.",
        }
        return wavelet_func, meta

    if family == "ormsby":
        # 浅层频带更高更宽，深层高频上限下降；GT 始终比 LQ 更宽。
        lq_top = np.array([
            rng.uniform(8.0, 12.0),
            rng.uniform(14.0, 20.0),
            rng.uniform(32.0, 40.0),
            rng.uniform(46.0, 56.0),
        ], dtype=np.float64)
        lq_bottom = np.array([
            rng.uniform(4.0, 8.0),
            rng.uniform(9.0, 14.0),
            rng.uniform(20.0, 27.0),
            rng.uniform(31.0, 39.0),
        ], dtype=np.float64)
        gt_top = np.array([
            rng.uniform(2.0, 4.5),
            rng.uniform(6.0, 10.0),
            rng.uniform(62.0, 76.0),
            rng.uniform(90.0, 106.0),
        ], dtype=np.float64)
        gt_bottom = np.array([
            rng.uniform(2.0, 4.5),
            rng.uniform(5.0, 9.0),
            rng.uniform(48.0, 62.0),
            rng.uniform(72.0, 90.0),
        ], dtype=np.float64)
        band_lq_curve = np.stack([np.linspace(lq_top[k], lq_bottom[k], len(anchors)) for k in range(4)], axis=1)
        band_gt_curve = np.stack([np.linspace(gt_top[k], gt_bottom[k], len(anchors)) for k in range(4)], axis=1)
        band_lq_curve += rng.normal(0.0, [0.3, 0.4, 0.7, 0.8], size=band_lq_curve.shape)
        band_gt_curve += rng.normal(0.0, [0.2, 0.3, 1.0, 1.2], size=band_gt_curve.shape)

        def fix_band_lq(b):
            f1, f2, f3, f4 = [float(x) for x in b]
            f2 = max(f2, f1 + 4.0)
            f3 = max(f3, f2 + 8.0)
            f4 = max(f4, f3 + 6.0)
            return np.array([f1, f2, f3, f4], dtype=np.float64)

        def fix_band_gt(b, lq_b):
            f1, f2, f3, f4 = [float(x) for x in b]
            f1 = max(1.5, f1)
            f2 = max(f2, f1 + 3.0)
            f3 = max(f3, float(lq_b[2]) + 14.0)
            f4 = max(f4, f3 + 12.0)
            f4 = min(f4, 112.0)
            return np.array([f1, f2, f3, f4], dtype=np.float64)

        for i in range(len(anchors)):
            band_lq_curve[i] = fix_band_lq(band_lq_curve[i])
            band_gt_curve[i] = fix_band_gt(band_gt_curve[i], band_lq_curve[i])

        def wavelet_func(depth_norm):
            b_lq = fix_band_lq(interp_vec(depth_norm, anchors, band_lq_curve))
            b_gt = fix_band_gt(interp_vec(depth_norm, anchors, band_gt_curve), b_lq)
            phase = interp1(depth_norm, anchors, phase_curve)
            w_lq, w_gt = ormsby_pair_from_bands(b_lq, b_gt, phase, dt=dt, length=length)
            return w_lq, w_gt, {
                "depth_norm": sanitize_float(depth_norm),
                "band_lq": [sanitize_float(x) for x in b_lq],
                "band_gt": [sanitize_float(x) for x in b_gt],
                "phase_deg": sanitize_float(phase),
            }

        meta = {
            "family": "ormsby",
            "variation": "time",
            "stationary": False,
            "time_varying": True,
            "space_varying": False,
            "noise": False,
            "same_size": True,
            "phase_deg": sanitize_float(phase_base),
            "depth_anchors": [sanitize_float(x) for x in anchors],
            "band_lq_curve": [[sanitize_float(x) for x in row] for row in band_lq_curve],
            "band_gt_curve": [[sanitize_float(x) for x in row] for row in band_gt_curve],
            "phase_curve": [sanitize_float(x) for x in phase_curve],
            "tv_rule": "Time-varying Ormsby: high-frequency corner decreases with depth; GT band expands and envelopes LQ at each depth.",
        }
        return wavelet_func, meta

    if family == "klauder":
        lq_top = np.array([rng.uniform(13.0, 18.0), rng.uniform(36.0, 44.0)], dtype=np.float64)
        lq_bottom = np.array([rng.uniform(10.0, 16.0), rng.uniform(26.0, 34.0)], dtype=np.float64)
        gt_top = np.array([rng.uniform(3.0, 7.0), rng.uniform(78.0, 96.0)], dtype=np.float64)
        gt_bottom = np.array([rng.uniform(3.0, 7.0), rng.uniform(56.0, 76.0)], dtype=np.float64)

        sweep_lq_curve = np.stack([np.linspace(lq_top[k], lq_bottom[k], len(anchors)) for k in range(2)], axis=1)
        sweep_gt_curve = np.stack([np.linspace(gt_top[k], gt_bottom[k], len(anchors)) for k in range(2)], axis=1)
        sweep_lq_curve += rng.normal(0.0, [0.4, 0.8], size=sweep_lq_curve.shape)
        sweep_gt_curve += rng.normal(0.0, [0.3, 1.2], size=sweep_gt_curve.shape)

        taper_lq = float(rng.uniform(2.0, 3.2))
        taper_gt = float(rng.uniform(5.0, 8.0))

        def fix_sweeps(s_lq, s_gt):
            f1, f2 = [float(x) for x in s_lq]
            f2 = max(f2, f1 + 14.0)
            lq = np.array([f1, f2], dtype=np.float64)
            f1g, f2g = [float(x) for x in s_gt]
            f1g = max(2.0, f1g)
            f2g = max(f2g, f2 + 22.0)
            f2g = min(f2g, 104.0)
            gt = np.array([f1g, f2g], dtype=np.float64)
            return lq, gt

        for i in range(len(anchors)):
            sweep_lq_curve[i], sweep_gt_curve[i] = fix_sweeps(sweep_lq_curve[i], sweep_gt_curve[i])

        def wavelet_func(depth_norm):
            s_lq, s_gt = fix_sweeps(
                interp_vec(depth_norm, anchors, sweep_lq_curve),
                interp_vec(depth_norm, anchors, sweep_gt_curve),
            )
            phase = interp1(depth_norm, anchors, phase_curve)
            w_lq, w_gt = klauder_pair_from_sweep(s_lq, s_gt, taper_lq, taper_gt, phase, dt=dt, length=length)
            return w_lq, w_gt, {
                "depth_norm": sanitize_float(depth_norm),
                "sweep_lq": [sanitize_float(x) for x in s_lq],
                "sweep_gt": [sanitize_float(x) for x in s_gt],
                "taper_lq": sanitize_float(taper_lq),
                "taper_gt": sanitize_float(taper_gt),
                "phase_deg": sanitize_float(phase),
            }

        meta = {
            "family": "klauder",
            "variation": "time",
            "stationary": False,
            "time_varying": True,
            "space_varying": False,
            "noise": False,
            "same_size": True,
            "phase_deg": sanitize_float(phase_base),
            "depth_anchors": [sanitize_float(x) for x in anchors],
            "sweep_lq_curve": [[sanitize_float(x) for x in row] for row in sweep_lq_curve],
            "sweep_gt_curve": [[sanitize_float(x) for x in row] for row in sweep_gt_curve],
            "taper_lq": sanitize_float(taper_lq),
            "taper_gt": sanitize_float(taper_gt),
            "phase_curve": [sanitize_float(x) for x in phase_curve],
            "tv_rule": "Time-varying Klauder-like: sweep high end decreases with depth; GT sweep range expands and envelopes LQ at each depth.",
        }
        return wavelet_func, meta

    raise ValueError(f"Unknown family: {family}")


def make_family_plan(n, rng):
    n_r = int(round(n * FAMILY_RATIO.get("ricker", 0.4)))
    n_o = int(round(n * FAMILY_RATIO.get("ormsby", 0.4)))
    n_k = n - n_r - n_o
    plan = ["ricker"] * n_r + ["ormsby"] * n_o + ["klauder"] * n_k
    rng.shuffle(plan)
    return plan


# =========================================================
# 4. 卷积、归一化、QC
# =========================================================
def convolve_along_depth(img, wavelet):
    img = np.asarray(img, dtype=np.float32)
    wavelet = np.asarray(wavelet, dtype=np.float32)
    n2, n1 = img.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))
    IMG = np.fft.rfft(img, n=nfft, axis=1)
    W = np.fft.rfft(wavelet, n=nfft)
    y = np.fft.irfft(IMG * W[None, :], n=nfft, axis=1)
    start = (nw - 1) // 2
    return y[:, start:start + n1].astype(np.float32)


def make_window_starts(n, win, step):
    if n <= win:
        return [0]
    starts = list(range(0, n - win + 1, step))
    if starts[-1] != n - win:
        starts.append(n - win)
    return sorted(set(starts))


def convolve_time_varying(img, wavelet_func, win=128, step=32):
    """
    时变非平稳卷积：
    - 沿深度方向分窗；
    - 每个窗口中心深度生成一对局部子波；
    - 使用该局部子波对整幅模型做 stationary convolution；
    - 只取该窗口区域，Hann overlap-add 融合。

    这样比只卷积局部窗口更稳定，因为保留了窗口外反射对子波响应的贡献。
    """
    img = np.asarray(img, dtype=np.float32)
    n2, n1 = img.shape
    starts = make_window_starts(n1, win, step)
    weight = 0.05 + 0.95 * np.hanning(win).astype(np.float32)  # 避免边界权重为 0

    out_lq = np.zeros_like(img, dtype=np.float32)
    out_gt = np.zeros_like(img, dtype=np.float32)
    wsum = np.zeros_like(img, dtype=np.float32)
    window_records = []

    for s in starts:
        e = s + win
        depth_norm = np.clip((s + 0.5 * win) / max(n1 - 1, 1), 0.0, 1.0)
        w_lq, w_gt, local_meta = wavelet_func(depth_norm)

        conv_lq = convolve_along_depth(img, w_lq)
        conv_gt = convolve_along_depth(img, w_gt)

        out_lq[:, s:e] += conv_lq[:, s:e] * weight[None, :]
        out_gt[:, s:e] += conv_gt[:, s:e] * weight[None, :]
        wsum[:, s:e] += weight[None, :]

        rec = dict(local_meta)
        rec.update({"window_start": int(s), "window_end": int(e)})
        window_records.append(rec)

    out_lq = out_lq / np.maximum(wsum, 1e-6)
    out_gt = out_gt / np.maximum(wsum, 1e-6)
    return out_lq.astype(np.float32), out_gt.astype(np.float32), window_records


def normalize_pair_shared(lq, gt, percentile=99.5, scale_floor=1e-6):
    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)
    vals = np.concatenate([np.abs(lq).reshape(-1), np.abs(gt).reshape(-1)])
    scale = float(np.percentile(vals, percentile))
    scale = max(scale, float(scale_floor))
    lq_n = np.clip(lq / scale, -1.0, 1.0).astype(np.float32)
    gt_n = np.clip(gt / scale, -1.0, 1.0).astype(np.float32)
    return lq_n, gt_n, scale


def collect_representative_wavelets(wavelet_func):
    w_lqs, w_gts, metas = [], [], []
    for d in REP_DEPTHS:
        w_lq, w_gt, lm = wavelet_func(d)
        w_lqs.append(w_lq)
        w_gts.append(w_gt)
        metas.append(lm)
    return np.stack(w_lqs), np.stack(w_gts), metas


def save_qc_figure_timevarying(lq, gt, rep_w_lq, rep_w_gt, rep_metas, meta, out_png, dt=0.004):
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)
    clip = np.percentile(np.abs(np.concatenate([lq.reshape(-1), gt.reshape(-1)])), 99.0)
    clip = max(float(clip), 1e-6)
    x_trace = lq.shape[0] // 2
    t = time_axis(dt, WAVELET_LENGTH)

    fig = plt.figure(figsize=(20, 12), dpi=150)

    ax1 = plt.subplot(3, 3, 1)
    ax1.imshow(lq.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax1.set_title("LQ narrow-band, time-varying")

    ax2 = plt.subplot(3, 3, 2)
    ax2.imshow(gt.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax2.set_title("GT broadband, time-varying")

    ax3 = plt.subplot(3, 3, 3)
    ax3.plot(lq[x_trace, :], label="lq")
    ax3.plot(gt[x_trace, :], label="gt")
    ax3.set_title(f"Trace comparison x={x_trace}")
    ax3.legend(fontsize=8)

    ax4 = plt.subplot(3, 3, 4)
    for i, name in enumerate(REP_NAMES):
        ax4.plot(t[:rep_w_lq.shape[1]], rep_w_lq[i], linestyle="--", label=f"{name} lq")
        ax4.plot(t[:rep_w_gt.shape[1]], rep_w_gt[i], linestyle="-", label=f"{name} gt")
    ax4.set_title("Representative wavelets")
    ax4.legend(fontsize=7, ncol=2)

    ax5 = plt.subplot(3, 3, 5)
    for i, name in enumerate(REP_NAMES):
        f_lq, a_lq = amplitude_spectrum(rep_w_lq[i], dt=dt)
        f_gt, a_gt = amplitude_spectrum(rep_w_gt[i], dt=dt)
        ax5.plot(f_lq, a_lq, linestyle="--", label=f"{name} lq")
        ax5.plot(f_gt, a_gt, linestyle="-", label=f"{name} gt")
    ax5.set_xlim(0, 120)
    ax5.set_ylim(0, 1.08)
    ax5.set_title("Representative spectra")
    ax5.legend(fontsize=7, ncol=2)

    ax6 = plt.subplot(3, 3, 6)
    depths = [m["depth_norm"] for m in rep_metas]
    family = meta.get("family", "")
    if family == "ricker":
        ax6.plot(depths, [m["f0_lq"] for m in rep_metas], marker="o", label="f0_lq")
        ax6.plot(depths, [m["gamma"] for m in rep_metas], marker="o", label="gamma")
        ax6.set_ylabel("Hz / gamma")
    elif family == "ormsby":
        ax6.plot(depths, [m["band_lq"][2] for m in rep_metas], marker="o", label="LQ f3")
        ax6.plot(depths, [m["band_gt"][2] for m in rep_metas], marker="o", label="GT f3")
        ax6.plot(depths, [m["band_gt"][3] for m in rep_metas], marker="o", label="GT f4")
        ax6.set_ylabel("Hz")
    elif family == "klauder":
        ax6.plot(depths, [m["sweep_lq"][1] for m in rep_metas], marker="o", label="LQ f_end")
        ax6.plot(depths, [m["sweep_gt"][1] for m in rep_metas], marker="o", label="GT f_end")
        ax6.set_ylabel("Hz")
    ax6.set_xlabel("depth_norm")
    ax6.set_title("Representative parameter trend")
    ax6.legend(fontsize=8)

    ax7 = plt.subplot(3, 3, 7)
    ax7.axis("off")
    local_txt = json.dumps(rep_metas, ensure_ascii=False, indent=2)
    ax7.text(0, 1, local_txt, va="top", ha="left", fontsize=7, family="monospace")
    ax7.set_title("top/mid/bottom local meta")

    ax8 = plt.subplot(3, 3, 8)
    ax8.axis("off")
    meta_show = dict(meta)
    for long_key in ["band_lq_curve", "band_gt_curve", "sweep_lq_curve", "sweep_gt_curve"]:
        if long_key in meta_show:
            meta_show[long_key] = "see json/npz"
    txt = json.dumps(meta_show, ensure_ascii=False, indent=2)
    ax8.text(0, 1, txt, va="top", ha="left", fontsize=7, family="monospace")
    ax8.set_title("global meta")

    ax9 = plt.subplot(3, 3, 9)
    ax9.axis("off")
    ax9.text(
        0, 1,
        "QC checklist:\n"
        "1) GT spectra envelope LQ at top/mid/bottom.\n"
        "2) Frequency high end decreases smoothly with depth.\n"
        "3) No abrupt time-window seams in LQ/GT sections.\n"
        "4) Phase/peak positions remain consistent between LQ and GT.",
        va="top", ha="left", fontsize=9,
    )

    plt.tight_layout()
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)


# =========================================================
# 5. 动态加载反射结构脚本
# =========================================================
def load_generator_class(script_path, module_name):
    script_path = Path(script_path)
    if not script_path.exists():
        raise FileNotFoundError(f"Source script not found: {script_path}")
    spec = importlib.util.spec_from_file_location(module_name, str(script_path))
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    if not hasattr(mod, "GeologicalSeismicData"):
        raise AttributeError(f"{script_path.name} does not contain class GeologicalSeismicData")
    return mod.GeologicalSeismicData


def generate_reflectivity(GeneratorClass, seed, n1=512, n2=512):
    gen = GeneratorClass(seed=seed)
    try:
        model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0)
    except TypeError:
        if hasattr(gen, "generate_plausible_parameters"):
            params = gen.generate_plausible_parameters(n1=n1, n2=n2)
            model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0, params=params)
        else:
            raise
    model = np.asarray(model, dtype=np.float32)
    if model.shape != (n2, n1):
        raise ValueError(f"Unexpected model shape {model.shape}, expected {(n2, n1)}")
    return model


# =========================================================
# 6. 索引、复现信息
# =========================================================
def phase_group(phase_deg, eps=1e-6):
    return "zero_phase" if abs(float(phase_deg)) <= eps else "with_phase"


def write_summary_csv(rows):
    out_csv = OUT_DIR / "sample_index.csv"
    fields = [
        "id", "structure", "family", "variation", "phase_deg", "phase_group",
        "lq_path", "gt_path", "meta_path", "wavelet_field_path", "w_lq_path", "w_gt_path",
    ]
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})
    print(f"[SAVE] sample_index.csv: {out_csv}")

    counts = {
        "total": len(rows),
        "by_structure": dict(Counter(r["structure"] for r in rows)),
        "by_family": dict(Counter(r["family"] for r in rows)),
        "by_phase_group": dict(Counter(r["phase_group"] for r in rows)),
        "by_structure_family": dict(Counter(f"{r['structure']}_{r['family']}" for r in rows)),
    }
    out_json = OUT_DIR / "sample_count.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(counts, f, ensure_ascii=False, indent=2)
    print(f"[SAVE] sample_count.json: {out_json}")
    print(json.dumps(counts, ensure_ascii=False, indent=2))


def copy_sources_for_reproducibility():
    if not COPY_SOURCE_SCRIPTS:
        return
    src_dir = OUT_DIR / "source_scripts"
    src_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(__file__), src_dir / Path(__file__).name)
    for item in SOURCE_SCRIPTS:
        p = SCRIPT_DIR / item["file"]
        if p.exists():
            shutil.copy2(p, src_dir / p.name)


# =========================================================
# 7. 主程序
# =========================================================
def main():
    ensure_dirs()
    copy_sources_for_reproducibility()

    rng_global = np.random.default_rng(RANDOM_SEED)
    idx = START_INDEX
    rows = []
    qc_seen_structure_family = set()

    print(
        f"Start generating multi-structure TIME-VARYING BWE dataset: "
        f"{len(SOURCE_SCRIPTS)} structures × {NUM_PER_STRUCTURE} samples, "
        f"same-size {N2}x{N1}, no noise, win={TV_WIN}, step={TV_STEP}."
    )

    for s_i, item in enumerate(SOURCE_SCRIPTS):
        structure = item["name"]
        script_path = SCRIPT_DIR / item["file"]
        GeneratorClass = load_generator_class(script_path, module_name=f"gen_{structure}")
        family_plan = make_family_plan(NUM_PER_STRUCTURE, rng_global)
        print(f"\n[STRUCTURE] {structure} from {item['file']} | plan={dict(Counter(family_plan))}")

        for j in range(NUM_PER_STRUCTURE):
            sample_seed = int(RANDOM_SEED * 100000 + s_i * 10000 + j)
            wavelet_rng = np.random.default_rng(sample_seed + 777)

            # 1) 反射结构
            model = generate_reflectivity(GeneratorClass, seed=sample_seed, n1=N1, n2=N2)

            # 2) 时变子波场
            forced_family = family_plan[j]
            wavelet_func, meta_w = make_timevarying_wavelet_model(
                wavelet_rng,
                forced_family=forced_family,
                dt=DT,
                length=WAVELET_LENGTH,
            )

            # 3) 时变非平稳卷积
            lq, gt, window_records = convolve_time_varying(
                model,
                wavelet_func,
                win=TV_WIN,
                step=TV_STEP,
            )

            # 4) 共享归一化
            lq, gt, shared_scale = normalize_pair_shared(lq, gt, percentile=99.5, scale_floor=1e-6)

            # 5) 代表子波保存，用于 QC 和 split 兼容
            rep_w_lq, rep_w_gt, rep_metas = collect_representative_wavelets(wavelet_func)

            stem = f"{idx:04d}"
            fname = f"{stem}.dat"
            lq.astype(np.float32).tofile(LQ_DIR / fname)
            gt.astype(np.float32).tofile(GT_DIR / fname)

            # 保存中部代表子波，兼容原 make_split_index_multistruct.py
            np.save(WAVELET_DIR / f"{stem}_w_lq.npy", rep_w_lq[1].astype(np.float32))
            np.save(WAVELET_DIR / f"{stem}_w_gt.npy", rep_w_gt[1].astype(np.float32))
            wavelet_field_path = WAVELET_DIR / f"{stem}_wavelet_field.npz"
            np.savez(
                wavelet_field_path,
                rep_depths=np.array(REP_DEPTHS, dtype=np.float32),
                rep_names=np.array(REP_NAMES),
                w_lq=rep_w_lq.astype(np.float32),
                w_gt=rep_w_gt.astype(np.float32),
                window_records=np.array(json.dumps(window_records, ensure_ascii=False)),
            )

            meta = dict(meta_w)
            meta.update({
                "id": stem,
                "structure": structure,
                "source_script": item["file"],
                "seed": sample_seed,
                "n1": N1,
                "n2": N2,
                "dt": DT,
                "wavelet_length": WAVELET_LENGTH,
                "tv_win": TV_WIN,
                "tv_step": TV_STEP,
                "representative_depths": [sanitize_float(x) for x in REP_DEPTHS],
                "shared_scale": sanitize_float(shared_scale),
            })
            meta_path = META_DIR / f"{stem}.json"
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)

            need_qc = (
                (idx - START_INDEX) < QC_FIRST_N
                or ((idx - START_INDEX + 1) % QC_EVERY == 0)
                or ((structure, meta["family"]) not in qc_seen_structure_family)
            )
            if need_qc:
                save_qc_figure_timevarying(
                    lq,
                    gt,
                    rep_w_lq,
                    rep_w_gt,
                    rep_metas,
                    meta,
                    QC_DIR / f"{stem}_qc.png",
                    dt=DT,
                )
                qc_seen_structure_family.add((structure, meta["family"]))

            row = {
                "id": stem,
                "structure": structure,
                "family": meta["family"],
                "variation": "time",
                "phase_deg": meta["phase_deg"],
                "phase_group": phase_group(meta["phase_deg"]),
                "lq_path": str(LQ_DIR / fname),
                "gt_path": str(GT_DIR / fname),
                "meta_path": str(meta_path),
                "wavelet_field_path": str(wavelet_field_path),
                "w_lq_path": str(WAVELET_DIR / f"{stem}_w_lq.npy"),
                "w_gt_path": str(WAVELET_DIR / f"{stem}_w_gt.npy"),
            }
            rows.append(row)

            if (j + 1) % 10 == 0 or (j + 1) == NUM_PER_STRUCTURE:
                print(
                    f"  [{j + 1:04d}/{NUM_PER_STRUCTURE}] latest id={stem}, "
                    f"family={meta['family']}, phase={meta['phase_deg']:.2f}"
                )
            idx += 1

    write_summary_csv(rows)
    print(f"\nAll done. Dataset saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
