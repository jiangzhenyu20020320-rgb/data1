# -*- coding: utf-8 -*-
"""
Multi-structure stationary wavelet waveform-preserving bandwidth-extension dataset generator.

Checked version: add LQ/GT pair self-check before saving.

用法：
1) 把本脚本放到和以下构造生成脚本同一个文件夹：
   dongyingbatch.py
   helanjinhaiyanpendi.py
   huazhuang.py
   malinbatch_noise_dat.py
   malinbatchnewfold&noise&q.py
   tixingyanqiubatch_noise_dat.py

2) 运行：
   python multi_structure_stationary_bwe.py

输出：
  dataset_waveform_bwe_multistruct_stationary_v2_stronger_ok_checked/
    lq/*.dat       窄带输入，同尺寸，无噪声
    gt/*.dat       宽带标签，同尺寸，无噪声
    meta/*.json    子波类型、相位、构造来源等元信息
    wavelets/*.npy 输入/标签子波
    qc/*.png       质控图

核心逻辑：
- 只替换“子波卷积与保存”逻辑，不改变各脚本内部反射结构生成函数。
- 三类 stationary 子波：ricker / ormsby / klauder。
- LQ/GT 使用同源窄带-宽带配对。
- 保留相位：LQ 和 GT 使用同一个 phase_deg。
- Ricker 使用 v3 的 power broadening 单峰包络拓频，避免简单提高主频。
- 第一阶段不加噪声、不下采样。
"""

import csv
import json
import math
import shutil
import importlib.util
from pathlib import Path
from collections import Counter, defaultdict

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert, chirp


# =========================================================
# 0. 配置区：主要改这里
# =========================================================
SCRIPT_DIR = Path(__file__).resolve().parent

SOURCE_SCRIPTS = [
    {"name": "dongying",        "file": "dongyingbatch.py"},
    {"name": "helan_basin",     "file": "helanjinhaiyanpendi.py"},
    {"name": "huazhuang",       "file": "huazhuang.py"},
    {"name": "malin",           "file": "malinbatch_noise_dat.py"},
    {"name": "malin_newfold",   "file": "malinbatchnewfold&noise&q.py"},
    {"name": "tixing_salt",     "file": "tixingyanqiubatch_noise_dat.py"},
]

# 每种反射结构生成多少个样本。先小规模 QC，满意后再改大。
NUM_PER_STRUCTURE = 20  # light stationary training set: 6 structures × 80 = 480 samples

# 输出尺寸：所有脚本都按同尺寸 512 x 512 生成。
N1 = 512
N2 = 512

DT = 0.004
WAVELET_LENGTH = 0.256

# 输出目录
OUT_DIR = SCRIPT_DIR / "dataset_waveform_bwe_multistruct_stationary_sf1_light_fixed"
LQ_DIR = OUT_DIR / "lq"
GT_DIR = OUT_DIR / "gt"
META_DIR = OUT_DIR / "meta"
WAVELET_DIR = OUT_DIR / "wavelets"
QC_DIR = OUT_DIR / "qc"
FAILED_PAIR_DIR = OUT_DIR / "failed_pair_checks"

# 运行前默认清空输出目录，避免旧 .dat / meta / qc 残留造成后续 merge 错配。
OVERWRITE_OUT_DIR = True

# 生成阶段的 LQ/GT 配对自检。该检查只用于发现明显错配/转置/方向异常，
# 不替代最终 merge 后的 diagnose_bwe_pair_alignment.py 全量检查。
ENABLE_PAIR_SELF_CHECK = True
MAX_PAIR_RETRY = 8
PAIR_CHECK_SAVE_FAILED = True
PAIR_CHECK_MIN_ENV_CORR = 0.14
PAIR_CHECK_MIN_RAW_CORR = -0.05
PAIR_CHECK_ORIENTATION_MARGIN = 0.08
PAIR_CHECK_DOWNSAMPLE = 4

# 文件编号起点。若要接着旧数据编号，可改为 0501、1001 等。
START_INDEX = 1

# 子波比例。建议第一阶段固定比例，避免某类子波过少。
FAMILY_RATIO = {"ricker": 0.40, "ormsby": 0.40, "klauder": 0.20}

# 相位设置：phase_prob 表示非零相位样本概率。
PHASE_PROB = 0.50
PHASE_RANGE = (-30.0, 30.0)

# QC 保存：前几个样本 + 每隔 qc_every + 每种 structure/family 首次出现。
QC_FIRST_N = 5
QC_EVERY = 50
RANDOM_SEED = 2026

# 是否复制源脚本到输出目录，方便复现实验。
COPY_SOURCE_SCRIPTS = True

# =========================================================
# 0.1 当前 sf=1 stationary BWE 数据约定
# =========================================================
# 内部构造脚本统一返回 (n2, n1) = [trace, depth]，卷积也沿 axis=1(depth) 完成。
# 为避免训练/展示时把同相轴画成竖条纹，最终 .dat 统一保存为 [depth, trace]。
INTERNAL_LAYOUT = "trace_depth"
SAVE_LAYOUT = "depth_trace"

# 生成阶段不再做 99.5 percentile clip。
# 默认保存为 [-0.98, 0.98] 内的 shared maxabs 归一化数据，但没有截幅削顶。
# 若你想保存 raw float32，可改 SAVE_MODE="raw"，并在训练/QC 中不要用 clip_ratio=0.999 判断截幅。
SAVE_MODE = "shared_maxabs_no_clip"  # "shared_maxabs_no_clip" / "raw" / "shared_percentile_clip"
SAVE_TARGET_MAXABS = 0.98
NORMALIZE_PERCENTILE = 99.95

# 子波不再用 max(abs(w)) 作为唯一归一化。energy 归一化能缓解 LQ RMS 系统性大于 GT。
WAVELET_NORM_MODE = "energy"  # "energy" / "peak"

# GT 子波必须在 LQ 有效频带上包络 LQ；并且若卷积后 GT RMS 小于 LQ，则只增强 GT，不压低 LQ。
ENFORCE_GT_WAVELET_ENVELOPE = True
ENVELOPE_FREQ_MAX = 110.0
ENVELOPE_ACTIVE_THRESHOLD = 0.02
MATCH_GT_RMS_IF_WEAKER = True
GT_RMS_TARGET_RATIO = 1.03  # 若 gt_rms < lq_rms*1.03，则放大 gt 至该比例
MAX_GT_RMS_GAIN = 3.0

# 质控阈值，只用于 meta/warning，不直接拒绝样本，避免轻量生成时频繁失败。
WARN_CLIP_RATIO = 1e-3
WARN_LQ_GT_RMS_RATIO = 1.30
WARN_RESIDUAL_RATIO = 1.00



# =========================================================
# 1. 基础工具函数
# =========================================================
def reset_output_dir():
    if OVERWRITE_OUT_DIR and OUT_DIR.exists():
        print(f"[RESET] remove old output directory: {OUT_DIR}")
        shutil.rmtree(OUT_DIR)


def ensure_dirs():
    for d in [LQ_DIR, GT_DIR, META_DIR, WAVELET_DIR, QC_DIR, FAILED_PAIR_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def sanitize_float(x):
    return float(np.asarray(x).item())


def time_axis(dt=0.004, length=0.256):
    # 0.256 / 0.004 = 64，包含端点后为 65 点，中心点恰为 0。
    return np.arange(-length / 2.0, length / 2.0 + 0.5 * dt, dt, dtype=np.float32)


def normalize_wavelet(w, mode=None):
    """
    子波归一化。

    旧版本使用 peak/maxabs 归一化，容易导致不同频带子波卷积后 RMS 不一致，
    进而出现 LQ RMS 系统性大于 GT。当前默认使用 energy 归一化。
    """
    w = np.asarray(w, dtype=np.float64)
    w = w - np.mean(w)
    mode = WAVELET_NORM_MODE if mode is None else str(mode).lower()

    if mode == "energy":
        s = float(np.sqrt(np.sum(w ** 2)))
    elif mode in ("peak", "maxabs"):
        s = float(np.max(np.abs(w)))
    else:
        raise ValueError(f"Unknown WAVELET_NORM_MODE: {mode}")

    if s > 1e-12:
        w = w / s
    return w.astype(np.float32)


def phase_rotate(w, phase_deg=0.0):
    """常相位旋转：LQ 和 GT 必须使用同一个 phase_deg。"""
    w = np.asarray(w, dtype=np.float64)
    if abs(float(phase_deg)) < 1e-12:
        return normalize_wavelet(w)
    wh = np.imag(hilbert(w))
    phi = np.deg2rad(float(phase_deg))
    # 与之前代码保持一致：cos*w - sin*Hilbert(w)
    wp = np.cos(phi) * w - np.sin(phi) * wh
    return normalize_wavelet(wp)


def centered_wavelet_from_amp(amp, n_wavelet, nfft):
    """
    根据零相位振幅谱构造中心化时间域子波。

    注意：这里先在 nfft 长度上合成零相位序列，再 fftshift 到中心截取。
    不要对短子波做 ifftshift 后再补零，否则频谱 QC 会出现人为梳状振荡。
    """
    amp = np.asarray(amp, dtype=np.float64)
    amp = np.maximum(amp, 0.0)
    amp[0] = 0.0  # 避免 DC 分量破坏零均值子波

    w_full = np.fft.irfft(amp.astype(np.complex128), n=nfft)
    w_full = np.fft.fftshift(w_full)

    center = nfft // 2
    half = n_wavelet // 2
    start = center - half
    w = w_full[start:start + n_wavelet]
    return normalize_wavelet(w)


def high_frequency_taper(freqs, f_start=90.0, f_end=120.0):
    """高频余弦衰减，避免由谱幂变换造成最高频端硬截断。"""
    taper = np.ones_like(freqs, dtype=np.float64)
    taper[freqs >= f_end] = 0.0
    m = (freqs > f_start) & (freqs < f_end)
    if np.any(m):
        x = (freqs[m] - f_start) / (f_end - f_start + 1e-12)
        taper[m] = 0.5 + 0.5 * np.cos(np.pi * x)
    return taper


def smooth_max(a, b, p=6.0):
    """平滑包络，避免硬 max 造成尖锐拼接。"""
    a = np.maximum(np.asarray(a, dtype=np.float64), 0.0)
    b = np.maximum(np.asarray(b, dtype=np.float64), 0.0)
    return (a ** p + b ** p) ** (1.0 / p)


def rms(arr):
    arr = np.asarray(arr, dtype=np.float64)
    return float(np.sqrt(np.mean(arr ** 2) + 1e-12))


def safe_ratio(a, b, eps=1e-12):
    return float(a / (b + eps))


def to_saved_layout(arr):
    """内部 [trace, depth] -> 保存/训练 [depth, trace]。"""
    arr = np.asarray(arr, dtype=np.float32)
    if INTERNAL_LAYOUT == SAVE_LAYOUT:
        return arr.astype(np.float32)
    if INTERNAL_LAYOUT == "trace_depth" and SAVE_LAYOUT == "depth_trace":
        return arr.T.astype(np.float32)
    if INTERNAL_LAYOUT == "depth_trace" and SAVE_LAYOUT == "trace_depth":
        return arr.T.astype(np.float32)
    raise ValueError(f"Unsupported layout transform: {INTERNAL_LAYOUT} -> {SAVE_LAYOUT}")


def wavelet_envelope_gain(w_lq, w_gt, dt=0.004, fmax=110.0, active_threshold=0.02):
    """计算让 GT 子波振幅谱包络 LQ 子波所需的全局增益。"""
    f_lq, a_lq = amplitude_spectrum(w_lq, dt=dt)
    f_gt, a_gt = amplitude_spectrum(w_gt, dt=dt)
    # amplitude_spectrum 内部各自归一化到峰值 1，用于检查包络形状。
    # 真正增益仍作用在时域 w_gt 上，防止 GT 在 LQ 有效频带内低于 LQ。
    m = (f_lq > 0.0) & (f_lq <= float(fmax)) & (a_lq >= float(active_threshold))
    if not np.any(m):
        return 1.0, 0.0
    min_margin = float(np.min(a_gt[m] - a_lq[m]))
    # 因 amplitude_spectrum 归一化，不能直接由这里的 ratio 确定绝对增益；
    # 对于已做 smooth_max 的 pair，通常 margin >= 0。若有轻微低于，给一个温和增益。
    if min_margin >= -1e-4:
        return 1.0, min_margin
    ratio = np.max(a_lq[m] / np.maximum(a_gt[m], 1e-6))
    gain = float(np.clip(ratio, 1.0, 2.0))
    return gain, min_margin


def enforce_gt_wavelet_envelope(w_lq, w_gt, dt=0.004):
    if not ENFORCE_GT_WAVELET_ENVELOPE:
        return w_lq.astype(np.float32), w_gt.astype(np.float32), {"enabled": False}
    gain, min_margin_before = wavelet_envelope_gain(
        w_lq, w_gt, dt=dt, fmax=ENVELOPE_FREQ_MAX, active_threshold=ENVELOPE_ACTIVE_THRESHOLD
    )
    w_gt2 = (np.asarray(w_gt, dtype=np.float32) * gain).astype(np.float32)
    _, min_margin_after = wavelet_envelope_gain(
        w_lq, w_gt2, dt=dt, fmax=ENVELOPE_FREQ_MAX, active_threshold=ENVELOPE_ACTIVE_THRESHOLD
    )
    info = {
        "enabled": True,
        "gain": sanitize_float(gain),
        "min_norm_amp_margin_before": sanitize_float(min_margin_before),
        "min_norm_amp_margin_after": sanitize_float(min_margin_after),
        "freq_max": sanitize_float(ENVELOPE_FREQ_MAX),
        "active_threshold": sanitize_float(ENVELOPE_ACTIVE_THRESHOLD),
    }
    return w_lq.astype(np.float32), w_gt2.astype(np.float32), info


def ricker_amp_spectrum(freqs, f0):
    """Ricker 子波理论振幅谱包络，归一化到峰值 1。"""
    freqs = np.asarray(freqs, dtype=np.float64)
    x = freqs / (float(f0) + 1e-12)
    amp = (x ** 2) * np.exp(-(x ** 2))
    amp[0] = 0.0
    amp = amp / (np.max(amp) + 1e-12)
    return amp


def generalized_ricker_amp_spectrum(freqs, f0, alpha=1.25, power=1.35):
    """
    广义 Ricker-derived 单峰振幅谱。

    标准 Ricker 近似为 alpha=2, power=2。
    alpha 变小：低频端抬升，左侧更宽；
    power 变小：高频端衰减更慢，右侧更宽。

    A(x) = x^alpha * exp((alpha/power) * (1 - x^power)), x=f/f0
    该形式保证峰值仍在 x=1 附近，且保持平滑单峰。
    """
    freqs = np.asarray(freqs, dtype=np.float64)
    x = np.maximum(freqs / (float(f0) + 1e-12), 0.0)
    alpha = float(alpha)
    power = float(power)

    amp = (x ** alpha) * np.exp((alpha / (power + 1e-12)) * (1.0 - x ** power))
    amp[0] = 0.0
    amp = amp / (np.max(amp) + 1e-12)
    return amp


# =========================================================
# 2. stationary 子波工厂
# =========================================================
def ricker_wavelet_zero(f0=25.0, dt=0.004, length=0.256):
    t = time_axis(dt, length)
    a = (np.pi * float(f0)) ** 2
    w = (1.0 - 2.0 * a * t ** 2) * np.exp(-a * t ** 2)
    return normalize_wavelet(w)


def ricker_power_broaden_pair(rng, dt=0.004, length=0.256, phase_deg=0.0):
    """
    strong-smooth Ricker-derived 保波形拓频版本。

    LQ:
        标准 Ricker 理论谱，主频较低，作为窄带输入。

    GT:
        使用广义 Ricker-derived 单峰谱，而不是简单 A_lq**gamma。
        这样可以同时明显拓展低频端和高频端，并尽量保持平滑单峰，
        避免 gamma 过小造成的振铃/谱线波动。
    """
    # 蓝线主频：适当低一些，保证 LQ 窄带感更明显
    f0_lq = float(rng.uniform(17.0, 24.0))

    # 广义谱参数：越小越宽，但过小会让时间域旁瓣变强
    # alpha 控制左侧低频端，power 控制右侧高频尾部
    alpha_gt = float(rng.uniform(1.05, 1.30))
    power_gt = float(rng.uniform(1.00, 1.15))

    # gamma 只做轻微整体加宽，不再使用 0.3 这种过激值
    gamma = float(rng.uniform(0.65, 0.78))

    w_ref = ricker_wavelet_zero(f0_lq, dt=dt, length=length)
    n = len(w_ref)
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)

    # LQ：标准 Ricker 单峰谱
    A_lq = ricker_amp_spectrum(freqs, f0_lq)

    # GT：广义 Ricker-derived 宽单峰谱，形状更接近绿色包络
    A_wide = generalized_ricker_amp_spectrum(
        freqs,
        f0=f0_lq,
        alpha=alpha_gt,
        power=power_gt,
    )

    A_wide = A_wide ** gamma
    A_wide[0] = 0.0

    # 强制 GT 平滑包络 LQ，避免局部低于蓝线
    A_gt = smooth_max(A_wide, A_lq, p=8.0)

    # 只在很高频端做柔和衰减，避免硬截断
    A_gt *= high_frequency_taper(freqs, f_start=105.0, f_end=124.0)
    A_gt = A_gt / (np.max(A_gt) + 1e-12)

    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)

    w_lq = phase_rotate(w_lq0, phase_deg)
    w_gt = phase_rotate(w_gt0, phase_deg)

    meta = {
        "family": "ricker",
        "phase_deg": sanitize_float(phase_deg),
        "stationary": True,
        "noise": False,
        "same_size": True,
        "f0_lq": sanitize_float(f0_lq),
        "ricker_gt_mode": "generalized_ricker_smooth_broadband_envelope",
        "ricker_broadening_rule": "GT uses generalized single-peak Ricker-derived envelope: alpha controls low-frequency broadening, power controls high-frequency tail; enforce A_gt>=A_lq.",
        "alpha_gt": sanitize_float(alpha_gt),
        "power_gt": sanitize_float(power_gt),
        "gamma": sanitize_float(gamma),
        "note": "GT is Ricker-derived / Ricker-like smooth broadband, not a strict single-parameter Ricker.",
    }
    return w_lq, w_gt, meta

def trapezoid_amp(freqs, f1, f2, f3, f4):
    """Ormsby / 梯形带通振幅谱。"""
    freqs = np.asarray(freqs, dtype=np.float64)
    amp = np.zeros_like(freqs, dtype=np.float64)

    # rise
    m = (freqs >= f1) & (freqs < f2)
    if np.any(m):
        amp[m] = (freqs[m] - f1) / (f2 - f1 + 1e-12)

    # plateau
    amp[(freqs >= f2) & (freqs <= f3)] = 1.0

    # fall
    m = (freqs > f3) & (freqs <= f4)
    if np.any(m):
        amp[m] = 1.0 - (freqs[m] - f3) / (f4 - f3 + 1e-12)

    return np.clip(amp, 0.0, 1.0)


def ormsby_wavelet_from_band(band, dt=0.004, length=0.256, nfft=4096):
    n = len(time_axis(dt, length))
    freqs = np.fft.rfftfreq(nfft, d=dt)
    amp = trapezoid_amp(freqs, *band)
    return centered_wavelet_from_amp(amp, n, nfft)


def ormsby_pair(rng, dt=0.004, length=0.256, phase_deg=0.0):
    """
    Stronger Ormsby waveform-preserving BWE pair.

    目标：
    - LQ 蓝线更窄：收缩有效带宽，提高低频截止、降低高频截止；
    - GT 黄线更宽：低频下探、高频上拓，并显式包络 LQ；
    - 仍保持 Ormsby / trapezoid bandpass 的工程子波形态。
    """
    n = len(time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)

    # -------- LQ: 更窄的 Ormsby 梯形窗 --------
    # 原先大约 [5~8, 10~15, 38~48, 55~65]，蓝线偏宽。
    # 现在提高低频端、降低高频端，让蓝线更集中。
    f1 = float(rng.uniform(8.0, 12.0))
    f2 = float(rng.uniform(14.0, 20.0))
    f3 = float(rng.uniform(30.0, 38.0))
    f4 = float(rng.uniform(42.0, 52.0))

    # 安全约束，避免随机时交叉
    f2 = max(f2, f1 + 4.0)
    f3 = max(f3, f2 + 8.0)
    f4 = max(f4, f3 + 6.0)

    # -------- GT: 更强的低频下探 + 高频上拓 --------
    # 低频端明显向左扩；高频端明显向右扩；高频滚降留宽一点以保持平滑。
    f1g = float(rng.uniform(2.0, 4.5))
    f2g = float(rng.uniform(6.0, 10.0))
    f3g = float(rng.uniform(58.0, 72.0))
    f4g = float(rng.uniform(88.0, 105.0))

    f2g = max(f2g, f1g + 3.0)
    f3g = max(f3g, f3 + 15.0)
    f4g = max(f4g, f3g + 12.0)
    f4g = min(f4g, 110.0)

    band_lq = [f1, f2, f3, f4]
    band_gt = [f1g, f2g, f3g, f4g]

    A_lq = trapezoid_amp(freqs, *band_lq)
    A_gt_raw = trapezoid_amp(freqs, *band_gt)

    # 显式包络约束：避免某些过渡带处 GT 低于 LQ。
    # smooth_max 比 np.maximum 更平滑，频谱边界不容易产生硬折角。
    A_gt = smooth_max(A_gt_raw, A_lq, p=10.0)
    A_gt *= high_frequency_taper(freqs, f_start=108.0, f_end=124.0)
    A_gt[0] = 0.0
    A_gt = A_gt / (np.max(A_gt) + 1e-12)

    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)

    w_lq = phase_rotate(w_lq0, phase_deg)
    w_gt = phase_rotate(w_gt0, phase_deg)

    meta = {
        "family": "ormsby",
        "phase_deg": sanitize_float(phase_deg),
        "stationary": True,
        "noise": False,
        "same_size": True,
        "band_lq": [sanitize_float(x) for x in band_lq],
        "band_gt": [sanitize_float(x) for x in band_gt],
        "ormsby_gt_mode": "stronger_wider_trapezoid_band_envelope",
        "note": "LQ Ormsby band is narrowed; GT Ormsby band expands to lower and higher frequencies and smoothly envelopes LQ.",
    }
    return w_lq, w_gt, meta


def sweep_band_amp(freqs, f_start, f_end, taper=4.0):
    """
    Klauder 扫频自相关子波的近似振幅谱。

    对线性扫频信号而言，其自相关子波的振幅谱近似等于扫频信号振幅谱的平方，
    在 sweep band 内应呈较宽、较平的带通包络，而不是 Ricker 式单峰谱。
    这里用带余弦滚降的矩形扫频带来表示 Klauder 的 sweep-band 特征。
    """
    freqs = np.asarray(freqs, dtype=np.float64)
    f_start = float(f_start)
    f_end = float(f_end)
    taper = float(taper)

    if f_end <= f_start:
        raise ValueError(f"Invalid sweep band: {f_start}, {f_end}")

    # taper 不能超过带宽的一半
    taper = max(0.5, min(taper, 0.45 * (f_end - f_start)))

    amp = np.zeros_like(freqs, dtype=np.float64)

    # 上升段
    f1 = max(0.0, f_start - taper)
    f2 = f_start + taper
    m = (freqs >= f1) & (freqs < f2)
    if np.any(m):
        x = (freqs[m] - f1) / (f2 - f1 + 1e-12)
        amp[m] = 0.5 - 0.5 * np.cos(np.pi * x)

    # 平坦扫频段
    m = (freqs >= f2) & (freqs <= f_end - taper)
    amp[m] = 1.0

    # 如果扫频带很窄，上面的 plateau 可能为空，这时保证中部仍有能量
    m_mid = (freqs >= f_start) & (freqs <= f_end)
    amp[m_mid] = np.maximum(amp[m_mid], 0.85)

    # 下降段
    f3 = f_end - taper
    f4 = f_end + taper
    m = (freqs > f3) & (freqs <= f4)
    if np.any(m):
        x = (freqs[m] - f3) / (f4 - f3 + 1e-12)
        amp[m] = np.maximum(amp[m], 0.5 + 0.5 * np.cos(np.pi * x))

    amp[freqs <= 0.0] = 0.0
    return np.clip(amp, 0.0, 1.0)


def klauder_wavelet_from_sweep_band(f1, f2, dt=0.004, length=0.256, nfft=4096, taper=4.0):
    """
    由 sweep band 振幅谱合成零相位 Klauder-like 子波。

    这样得到的是“扫频自相关等效子波”：
    - 时间域：中心主峰 + 振荡旁瓣，类似 Klauder 自相关子波；
    - 频率域：在 sweep band 内为宽平带通，而不是 Ricker 单峰谱；
    - 适合作为 stationary wavelet 的可控窄带/宽带配对。
    """
    n = len(time_axis(dt, length))
    freqs = np.fft.rfftfreq(nfft, d=dt)
    amp = sweep_band_amp(freqs, f1, f2, taper=taper)
    return centered_wavelet_from_amp(amp, n, nfft)


def klauder_pair(rng, dt=0.004, length=0.256, phase_deg=0.0):
    """
    Stronger Klauder-like waveform-preserving BWE pair.

    目标：
    - LQ sweep band 更窄：蓝线频带范围缩小；
    - GT sweep band 更宽：低频下探、高频上拓；
    - 保持 Klauder-like sweep-band / autocorrelation-equivalent 特征。
    """
    # -------- LQ: 更窄的 sweep band --------
    # 原先 f1=8~14, f2=36~50，蓝线偏宽。
    # 现在提高起始频率、降低终止频率，使 LQ sweep 范围更窄。
    f1 = float(rng.uniform(9.0, 15.0))
    f2 = float(rng.uniform(36.0, 47.0))
    f2 = max(f2, f1 + 14.0)

    # -------- GT: 更强的 sweep range 扩展 --------
    f1g = float(rng.uniform(3.0, 6.0))
    f2g = float(rng.uniform(50.0, 72.0))
    f2g = max(f2g, f2 + 25.0)
    f2g = min(f2g, 100.0)

    # LQ taper 不宜过大，否则蓝线看起来不够窄；
    # GT taper 适当更大，使宽带边界更平滑，减少时间域振铃。
    taper_lq = float(rng.uniform(2.0, 3.2))
    taper_gt = float(rng.uniform(5.0, 8.0))

    n = len(time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)

    A_lq = sweep_band_amp(freqs, f1, f2, taper=taper_lq)
    A_gt_raw = sweep_band_amp(freqs, f1g, f2g, taper=taper_gt)

    # 平滑包络约束。对于 sweep-band，直接 max 容易在边界产生硬拐点，
    # smooth_max 能更自然地覆盖 LQ。
    A_gt = smooth_max(A_gt_raw, A_lq, p=10.0)
    A_gt *= high_frequency_taper(freqs, f_start=100.0, f_end=124.0)
    A_gt[0] = 0.0
    A_gt = A_gt / (np.max(A_gt) + 1e-12)

    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)

    w_lq = phase_rotate(w_lq0, phase_deg)
    w_gt = phase_rotate(w_gt0, phase_deg)

    meta = {
        "family": "klauder",
        "phase_deg": sanitize_float(phase_deg),
        "stationary": True,
        "noise": False,
        "same_size": True,
        "sweep_lq": [sanitize_float(f1), sanitize_float(f2)],
        "sweep_gt": [sanitize_float(f1g), sanitize_float(f2g)],
        "taper_lq": sanitize_float(taper_lq),
        "taper_gt": sanitize_float(taper_gt),
        "klauder_gt_mode": "stronger_wider_sweep_band_envelope_zero_phase_autocorrelation_equivalent",
        "note": "LQ Klauder-like sweep band is narrowed; GT expands sweep range and smoothly envelopes LQ.",
    }
    return w_lq, w_gt, meta


def make_phase(rng):
    if rng.random() < PHASE_PROB:
        ph = float(rng.uniform(PHASE_RANGE[0], PHASE_RANGE[1]))
        # 避免抽到过小相位，造成分类不清楚。
        if abs(ph) < 3.0:
            ph = 3.0 if ph >= 0 else -3.0
        return ph
    return 0.0


def make_stationary_wavelet_pair(rng, forced_family=None, dt=0.004, length=0.256):
    if forced_family is None:
        families = list(FAMILY_RATIO.keys())
        probs = np.array([FAMILY_RATIO[k] for k in families], dtype=np.float64)
        probs = probs / probs.sum()
        family = str(rng.choice(families, p=probs))
    else:
        family = str(forced_family)

    phase_deg = make_phase(rng)

    if family == "ricker":
        w_lq, w_gt, meta = ricker_power_broaden_pair(rng, dt=dt, length=length, phase_deg=phase_deg)
    elif family == "ormsby":
        w_lq, w_gt, meta = ormsby_pair(rng, dt=dt, length=length, phase_deg=phase_deg)
    elif family == "klauder":
        w_lq, w_gt, meta = klauder_pair(rng, dt=dt, length=length, phase_deg=phase_deg)
    else:
        raise ValueError(f"Unknown family: {family}")

    # 最后统一一次能量归一化，并检查/修正 GT 子波包络。
    w_lq = normalize_wavelet(w_lq)
    w_gt = normalize_wavelet(w_gt)
    w_lq, w_gt, env_info = enforce_gt_wavelet_envelope(w_lq, w_gt, dt=dt)
    meta["wavelet_norm_mode"] = WAVELET_NORM_MODE
    meta["gt_wavelet_envelope_check"] = env_info
    return w_lq, w_gt, meta


def make_family_plan(n, rng):
    n_r = int(round(n * FAMILY_RATIO.get("ricker", 0.4)))
    n_o = int(round(n * FAMILY_RATIO.get("ormsby", 0.4)))
    n_k = n - n_r - n_o
    plan = ["ricker"] * n_r + ["ormsby"] * n_o + ["klauder"] * n_k
    rng.shuffle(plan)
    return plan


# =========================================================
# 3. 卷积、归一化、QC
# =========================================================
def convolve_along_depth(img, wavelet):
    """
    沿深度/时间轴卷积。
    约定各脚本输出 image shape = (n2, n1)，深度/时间轴为 axis=1。
    """
    img = np.asarray(img, dtype=np.float32)
    wavelet = np.asarray(wavelet, dtype=np.float32)
    n2, n1 = img.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))

    IMG = np.fft.rfft(img, n=nfft, axis=1)
    W = np.fft.rfft(wavelet, n=nfft)
    Y = IMG * W[None, :]
    y = np.fft.irfft(Y, n=nfft, axis=1)

    start = (nw - 1) // 2
    return y[:, start:start + n1].astype(np.float32)


def scale_pair_for_save(lq, gt, scale_floor=1e-6):
    """
    生成阶段的 pair 处理。

    关键变化：
    1) 不再使用 99.5 percentile clip，避免 LQ 削顶；
    2) 默认 shared maxabs no-clip，保存值位于约 [-0.98, 0.98]；
    3) 若 GT RMS 弱于 LQ，则只增强 GT，使 LQ 不再系统性强于 GT；
    4) 保存前转为 [depth, trace]。
    """
    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)

    stats_pre = pair_stats(lq, gt, prefix="pre")

    gt_gain = 1.0
    if MATCH_GT_RMS_IF_WEAKER:
        lq_r = rms(lq)
        gt_r = rms(gt)
        target_gt_r = lq_r * float(GT_RMS_TARGET_RATIO)
        if gt_r < target_gt_r:
            gt_gain = float(np.clip(target_gt_r / (gt_r + 1e-12), 1.0, MAX_GT_RMS_GAIN))
            gt = (gt * gt_gain).astype(np.float32)

    stats_after_gain = pair_stats(lq, gt, prefix="after_gt_gain")

    if SAVE_MODE == "raw":
        scale = 1.0
        lq_out = lq.astype(np.float32)
        gt_out = gt.astype(np.float32)
    elif SAVE_MODE == "shared_maxabs_no_clip":
        maxabs = float(max(np.max(np.abs(lq)), np.max(np.abs(gt))))
        scale = max(maxabs / float(SAVE_TARGET_MAXABS), float(scale_floor))
        lq_out = (lq / scale).astype(np.float32)
        gt_out = (gt / scale).astype(np.float32)
        # 数值保护：正常情况下不会触发；若触发，说明 scale 计算有问题。
        lq_out = np.clip(lq_out, -1.0, 1.0).astype(np.float32)
        gt_out = np.clip(gt_out, -1.0, 1.0).astype(np.float32)
    elif SAVE_MODE == "shared_percentile_clip":
        vals = np.concatenate([np.abs(lq).reshape(-1), np.abs(gt).reshape(-1)])
        scale = float(np.percentile(vals, NORMALIZE_PERCENTILE))
        scale = max(scale, float(scale_floor))
        lq_out = np.clip(lq / scale, -1.0, 1.0).astype(np.float32)
        gt_out = np.clip(gt / scale, -1.0, 1.0).astype(np.float32)
    else:
        raise ValueError(f"Unknown SAVE_MODE: {SAVE_MODE}")

    stats_saved_internal = pair_stats(lq_out, gt_out, prefix="saved_internal")
    lq_save = to_saved_layout(lq_out)
    gt_save = to_saved_layout(gt_out)
    stats_saved_layout = pair_stats(lq_save, gt_save, prefix="saved_layout")

    info = {}
    info.update(stats_pre)
    info.update(stats_after_gain)
    info.update(stats_saved_internal)
    info.update(stats_saved_layout)
    info.update({
        "save_mode": SAVE_MODE,
        "save_target_maxabs": sanitize_float(SAVE_TARGET_MAXABS),
        "normalization_percentile": sanitize_float(NORMALIZE_PERCENTILE),
        "shared_scale": sanitize_float(scale),
        "gt_post_gain": sanitize_float(gt_gain),
        "internal_layout": INTERNAL_LAYOUT,
        "saved_layout": SAVE_LAYOUT,
        "saved_shape": list(lq_save.shape),
    })
    info["warnings"] = make_pair_warnings(info)
    return lq_out, gt_out, lq_save, gt_save, info


def pair_stats(lq, gt, prefix=""):
    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)
    p = f"{prefix}_" if prefix else ""
    lq_r = rms(lq)
    gt_r = rms(gt)
    res_r = rms(gt - lq)
    out = {
        f"{p}rms_lq": sanitize_float(lq_r),
        f"{p}rms_gt": sanitize_float(gt_r),
        f"{p}rms_lq_gt_ratio": sanitize_float(safe_ratio(lq_r, gt_r)),
        f"{p}rms_gt_lq_ratio": sanitize_float(safe_ratio(gt_r, lq_r)),
        f"{p}rms_residual": sanitize_float(res_r),
        f"{p}residual_ratio_to_gt": sanitize_float(safe_ratio(res_r, gt_r)),
        f"{p}corrcoef": sanitize_float(_safe_corr(lq, gt)),
        f"{p}maxabs_lq": sanitize_float(np.max(np.abs(lq))),
        f"{p}maxabs_gt": sanitize_float(np.max(np.abs(gt))),
        f"{p}clip_ratio_lq_0999": sanitize_float(np.mean(np.abs(lq) >= 0.999)),
        f"{p}clip_ratio_gt_0999": sanitize_float(np.mean(np.abs(gt) >= 0.999)),
    }
    out.update(band_energy_stats(lq, gt, prefix=p))
    return out


def band_energy_stats(lq, gt, prefix=""):
    """沿深度/time 轴(axis=1 for internal trace_depth)统计低/中/高频能量。"""
    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)
    # 若输入是 saved layout [depth,trace]，深度轴为 axis=0；否则为 axis=1。
    # 这里根据形状无法区分方阵，因此由 prefix 约定：saved_layout 用 axis=0，其余 internal 用 axis=1。
    axis = 0 if prefix.startswith("saved_layout") else 1
    L = np.abs(np.fft.rfft(lq, axis=axis)) ** 2
    G = np.abs(np.fft.rfft(gt, axis=axis)) ** 2
    nfreq = L.shape[axis]
    freqs = np.linspace(0.0, 0.5, nfreq, dtype=np.float64)
    bands = {"low": (0.00, 0.08), "mid": (0.08, 0.25), "high": (0.25, 0.50)}
    out = {}
    for name, (f0, f1) in bands.items():
        m = (freqs >= f0) & (freqs < f1 if f1 < 0.5 else freqs <= f1)
        if axis == 0:
            e_lq = float(np.mean(L[m, :]))
            e_gt = float(np.mean(G[m, :]))
        else:
            e_lq = float(np.mean(L[:, m]))
            e_gt = float(np.mean(G[:, m]))
        out[f"{prefix}vertical_{name}_energy_lq"] = sanitize_float(e_lq)
        out[f"{prefix}vertical_{name}_energy_gt"] = sanitize_float(e_gt)
        out[f"{prefix}vertical_{name}_energy_gt_lq_ratio"] = sanitize_float(safe_ratio(e_gt, e_lq))
    return out


def make_pair_warnings(info):
    warnings = []
    if info.get("saved_internal_clip_ratio_lq_0999", 0.0) > WARN_CLIP_RATIO:
        warnings.append("LQ clip ratio after save-scale is high; check SAVE_MODE/scale.")
    if info.get("saved_internal_rms_lq_gt_ratio", 0.0) > WARN_LQ_GT_RMS_RATIO:
        warnings.append("LQ RMS is much larger than GT RMS after save-scale.")
    if info.get("saved_internal_residual_ratio_to_gt", 0.0) > WARN_RESIDUAL_RATIO:
        warnings.append("Residual ratio is high; pair may be too difficult for lightweight training.")
    high_ratio = info.get("saved_internal_vertical_high_energy_gt_lq_ratio", 0.0)
    if high_ratio < 1.05:
        warnings.append("GT high-frequency energy is not clearly greater than LQ.")
    return warnings



def _block_mean_downsample(arr, factor=4):
    arr = np.asarray(arr, dtype=np.float32)
    factor = max(1, int(factor))
    if factor <= 1:
        return arr
    n2, n1 = arr.shape
    n2c = (n2 // factor) * factor
    n1c = (n1 // factor) * factor
    if n2c <= 0 or n1c <= 0:
        return arr
    arr = arr[:n2c, :n1c]
    return arr.reshape(n2c // factor, factor, n1c // factor, factor).mean(axis=(1, 3))


def _standardize_for_corr(arr):
    arr = np.asarray(arr, dtype=np.float64)
    arr = arr - np.nanmean(arr)
    std = float(np.nanstd(arr))
    if not np.isfinite(std) or std < 1e-12:
        return np.zeros_like(arr, dtype=np.float64)
    return arr / std


def _safe_corr(a, b):
    a = np.asarray(a, dtype=np.float64).reshape(-1)
    b = np.asarray(b, dtype=np.float64).reshape(-1)
    if a.size != b.size or a.size == 0:
        return -1.0
    a = a - np.mean(a)
    b = b - np.mean(b)
    den = float(np.linalg.norm(a) * np.linalg.norm(b))
    if den < 1e-12:
        return -1.0
    return float(np.dot(a, b) / den)


def _envelope_for_pair_check(arr):
    """Trace-wise Hilbert envelope + log compression for robust structure comparison."""
    arr = np.asarray(arr, dtype=np.float32)
    env = np.abs(hilbert(arr, axis=1)).astype(np.float32)
    env = np.log1p(env / (np.percentile(env, 95.0) + 1e-6))
    env = _block_mean_downsample(env, factor=PAIR_CHECK_DOWNSAMPLE)
    return _standardize_for_corr(env)


def diagnose_pair_self_alignment(lq, gt):
    """Return a conservative LQ/GT pair-check diagnosis.

    Stationary BWE pairs are produced by convolving the same reflectivity model
    with two paired wavelets. Their envelope structures should therefore remain
    consistent. This check catches gross mistakes such as stale files,
    transposition, flips, NaN/Inf, or unrelated pairs. It is intentionally
    conservative to avoid rejecting valid strong bandwidth-extension samples.
    """
    info = {
        "ok": True,
        "status": "ok",
        "reason": "",
        "same_env_corr": None,
        "same_raw_corr": None,
        "best_orientation": "same",
        "best_orientation_corr": None,
    }

    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)
    if lq.shape != (N2, N1) or gt.shape != (N2, N1):
        info.update(ok=False, status="bad_shape", reason=f"bad_shape lq={lq.shape}, gt={gt.shape}")
        return info
    if (not np.all(np.isfinite(lq))) or (not np.all(np.isfinite(gt))):
        info.update(ok=False, status="nonfinite", reason="non-finite value found")
        return info
    if float(np.std(lq)) < 1e-7 or float(np.std(gt)) < 1e-7:
        info.update(ok=False, status="near_constant", reason="near-constant lq or gt")
        return info

    lq_env = _envelope_for_pair_check(lq)
    gt_env = _envelope_for_pair_check(gt)
    same_env_corr = _safe_corr(lq_env, gt_env)

    lq_raw = _standardize_for_corr(_block_mean_downsample(lq, factor=PAIR_CHECK_DOWNSAMPLE))
    gt_raw = _standardize_for_corr(_block_mean_downsample(gt, factor=PAIR_CHECK_DOWNSAMPLE))
    same_raw_corr = _safe_corr(lq_raw, gt_raw)

    candidates = {"same": same_env_corr}
    # Since images are square, a transposed/rotated stale pair can otherwise look plausible.
    candidates["gt_transpose"] = _safe_corr(lq_env, gt_env.T)
    candidates["gt_flip_x"] = _safe_corr(lq_env, gt_env[::-1, :])
    candidates["gt_flip_t"] = _safe_corr(lq_env, gt_env[:, ::-1])
    best_orientation = max(candidates, key=candidates.get)
    best_corr = float(candidates[best_orientation])

    info.update(
        same_env_corr=float(same_env_corr),
        same_raw_corr=float(same_raw_corr),
        best_orientation=best_orientation,
        best_orientation_corr=best_corr,
    )

    fail_reasons = []
    if same_env_corr < PAIR_CHECK_MIN_ENV_CORR:
        fail_reasons.append(f"low_env_corr={same_env_corr:.4f}")
    if same_raw_corr < PAIR_CHECK_MIN_RAW_CORR and same_env_corr < (PAIR_CHECK_MIN_ENV_CORR + 0.08):
        fail_reasons.append(f"low_raw_corr={same_raw_corr:.4f}")
    if best_orientation != "same" and best_corr > same_env_corr + PAIR_CHECK_ORIENTATION_MARGIN:
        fail_reasons.append(f"orientation_suspicious: best={best_orientation}, best_corr={best_corr:.4f}, same={same_env_corr:.4f}")

    if fail_reasons:
        info.update(ok=False, status="suspicious", reason="; ".join(fail_reasons))
    return info


def save_failed_pair_check_png(lq, gt, diag, out_png):
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)
    clip = np.percentile(np.abs(np.concatenate([lq.reshape(-1), gt.reshape(-1)])), 99.0)
    clip = max(float(clip), 1e-6)
    fig, axes = plt.subplots(1, 2, figsize=(9, 4), dpi=140)
    axes[0].imshow(lq.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    axes[0].set_title("candidate LQ")
    axes[1].imshow(gt.T, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    axes[1].set_title("candidate GT")
    txt = (
        f"status={diag.get('status')}\n"
        f"reason={diag.get('reason')}\n"
        f"same_env_corr={diag.get('same_env_corr')}\n"
        f"same_raw_corr={diag.get('same_raw_corr')}\n"
        f"best={diag.get('best_orientation')} / {diag.get('best_orientation_corr')}"
    )
    fig.suptitle(txt, fontsize=8)
    plt.tight_layout()
    fig.savefig(out_png, bbox_inches="tight")
    plt.close(fig)


def amplitude_spectrum(w, dt=0.004, nfft=4096):
    """
    QC 用振幅谱。
    重要：不要对短子波使用 ifftshift 后再补零做 FFT。
    这样会把中心化子波拆到数组首尾，补零后形成两段脉冲，导致人为梳状振荡。
    """
    w = np.asarray(w, dtype=np.float32)
    W = np.fft.rfft(w, n=nfft)
    amp = np.abs(W)
    amp = amp / (np.max(amp) + 1e-12)
    f = np.fft.rfftfreq(nfft, d=dt)
    return f, amp


def save_qc_figure(lq_saved, gt_saved, w_lq, w_gt, meta, out_png, dt=0.004):
    """QC 图显示保存/训练方向：lq_saved/gt_saved shape = [depth, trace]。"""
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)

    clip = np.percentile(np.abs(np.concatenate([lq_saved.reshape(-1), gt_saved.reshape(-1)])), 99.0)
    clip = max(float(clip), 1e-6)

    x_trace = lq_saved.shape[1] // 2
    t = time_axis(dt, WAVELET_LENGTH)
    f_lq, a_lq = amplitude_spectrum(w_lq, dt=dt)
    f_gt, a_gt = amplitude_spectrum(w_gt, dt=dt)

    fig = plt.figure(figsize=(20, 10), dpi=150)

    ax1 = plt.subplot(2, 3, 1)
    ax1.imshow(lq_saved, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax1.set_title("LQ narrow-band [depth, trace]")
    ax1.set_xlabel("trace / lateral")
    ax1.set_ylabel("depth / time")

    ax2 = plt.subplot(2, 3, 2)
    ax2.imshow(gt_saved, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax2.set_title("GT broadband [depth, trace]")
    ax2.set_xlabel("trace / lateral")
    ax2.set_ylabel("depth / time")

    ax3 = plt.subplot(2, 3, 3)
    ax3.plot(lq_saved[:, x_trace], label="lq")
    ax3.plot(gt_saved[:, x_trace], label="gt")
    ax3.set_title(f"Middle trace comparison trace={x_trace}")
    ax3.set_xlabel("depth / time sample")
    ax3.legend(fontsize=8)

    ax4 = plt.subplot(2, 3, 4)
    ax4.plot(t[:len(w_lq)], w_lq, label="w_lq")
    ax4.plot(t[:len(w_gt)], w_gt, label="w_gt")
    ax4.set_title("Wavelet time domain")
    ax4.legend(fontsize=8)

    ax5 = plt.subplot(2, 3, 5)
    ax5.plot(f_lq, a_lq, label="lq")
    ax5.plot(f_gt, a_gt, label="gt")
    ax5.set_xlim(0, 120)
    ax5.set_ylim(0, 1.08)
    ax5.set_title("Wavelet amplitude spectrum")
    ax5.legend(fontsize=8)

    ax6 = plt.subplot(2, 3, 6)
    ax6.axis("off")
    keys = [
        "id", "structure", "family", "phase_deg", "save_mode",
        "internal_layout", "saved_layout", "shared_scale", "gt_post_gain",
        "saved_internal_rms_lq_gt_ratio", "saved_internal_residual_ratio_to_gt",
        "saved_internal_clip_ratio_lq_0999", "saved_internal_clip_ratio_gt_0999",
        "saved_internal_vertical_low_energy_gt_lq_ratio",
        "saved_internal_vertical_mid_energy_gt_lq_ratio",
        "saved_internal_vertical_high_energy_gt_lq_ratio",
        "warnings",
    ]
    meta_show = {k: meta.get(k) for k in keys if k in meta}
    txt = json.dumps(meta_show, ensure_ascii=False, indent=2)
    ax6.text(0, 1, txt, va="top", ha="left", fontsize=7, family="monospace")

    plt.tight_layout(pad=1.0)
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)


# =========================================================
# 4. 动态加载各反射结构脚本
# =========================================================
def load_generator_class(script_path, module_name):
    script_path = Path(script_path)
    if not script_path.exists():
        raise FileNotFoundError(f"Source script not found: {script_path}")

    spec = importlib.util.spec_from_file_location(module_name, str(script_path))
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)

    if not hasattr(mod, "GeologicalSeismicData"):
        raise AttributeError(f"{script_path.name} does not contain class GeologicalSeismicData")
    return mod.GeologicalSeismicData


def generate_reflectivity(GeneratorClass, seed, n1=512, n2=512):
    gen = GeneratorClass(seed=seed)

    # 大多数脚本支持 seismic_and_slopes_2d(n1,n2,noise=0)。
    # 若含 params 可选参数，默认 None 时内部会随机生成。
    try:
        model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0)
    except TypeError:
        # 兜底：部分脚本可能需要显式 params。
        if hasattr(gen, "generate_plausible_parameters"):
            params = gen.generate_plausible_parameters(n1=n1, n2=n2)
            model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0, params=params)
        else:
            raise

    model = np.asarray(model, dtype=np.float32)
    if model.shape != (n2, n1):
        raise ValueError(f"Unexpected model shape {model.shape}, expected {(n2, n1)}")
    return model


# =========================================================
# 5. 可选：划分 train/val 的索引脚本逻辑
# =========================================================
def phase_group(phase_deg, eps=1e-6):
    return "zero_phase" if abs(float(phase_deg)) <= eps else "with_phase"


def write_summary_csv(rows):
    out_csv = OUT_DIR / "sample_index.csv"
    fields = [
        "id", "structure", "family", "variation", "phase_deg", "phase_group",
        "lq_path", "gt_path", "meta_path", "w_lq_path", "w_gt_path",
    ]
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})
    print(f"[SAVE] sample_index.csv: {out_csv}")

    counts = {
        "total": len(rows),
        "by_structure": dict(Counter(r["structure"] for r in rows)),
        "by_family": dict(Counter(r["family"] for r in rows)),
        "by_phase_group": dict(Counter(r["phase_group"] for r in rows)),
        "by_structure_family": dict(Counter(f"{r['structure']}_{r['family']}" for r in rows)),
    }
    out_json = OUT_DIR / "sample_count.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(counts, f, ensure_ascii=False, indent=2)
    print(f"[SAVE] sample_count.json: {out_json}")
    print(json.dumps(counts, ensure_ascii=False, indent=2))


def copy_sources_for_reproducibility():
    if not COPY_SOURCE_SCRIPTS:
        return
    src_dir = OUT_DIR / "source_scripts"
    src_dir.mkdir(parents=True, exist_ok=True)
    # 复制本脚本
    shutil.copy2(Path(__file__), src_dir / Path(__file__).name)
    # 复制构造脚本
    for item in SOURCE_SCRIPTS:
        p = SCRIPT_DIR / item["file"]
        if p.exists():
            shutil.copy2(p, src_dir / p.name)


# =========================================================
# 6. 主程序
# =========================================================
def main():
    reset_output_dir()
    ensure_dirs()
    copy_sources_for_reproducibility()

    rng_global = np.random.default_rng(RANDOM_SEED)
    idx = START_INDEX
    rows = []

    qc_seen_structure_family = set()

    print(
        f"Start generating multi-structure stationary BWE dataset: "
        f"{len(SOURCE_SCRIPTS)} structures × {NUM_PER_STRUCTURE} samples, "
        f"same-size {N2}x{N1}, no noise."
    )

    for s_i, item in enumerate(SOURCE_SCRIPTS):
        structure = item["name"]
        script_path = SCRIPT_DIR / item["file"]
        if not script_path.exists():
            print(f"[SKIP] source script not found: {script_path}")
            continue
        GeneratorClass = load_generator_class(script_path, module_name=f"gen_{structure}")

        family_plan = make_family_plan(NUM_PER_STRUCTURE, rng_global)
        print(f"\n[STRUCTURE] {structure} from {item['file']} | plan={dict(Counter(family_plan))}")

        for j in range(NUM_PER_STRUCTURE):
            forced_family = family_plan[j]
            base_seed = int(RANDOM_SEED * 100000 + s_i * 10000 + j)
            last_diag = None

            for retry in range(MAX_PAIR_RETRY if ENABLE_PAIR_SELF_CHECK else 1):
                sample_seed = int(base_seed + retry * 1000000)
                wavelet_rng = np.random.default_rng(sample_seed + 777)

                # 1) 生成反射系数结构
                model = generate_reflectivity(GeneratorClass, seed=sample_seed, n1=N1, n2=N2)

                # 2) 生成同源 stationary 窄带/宽带子波
                w_lq, w_gt, meta_w = make_stationary_wavelet_pair(
                    wavelet_rng,
                    forced_family=forced_family,
                    dt=DT,
                    length=WAVELET_LENGTH,
                )

                # 3) 同一反射系数模型分别卷积
                lq = convolve_along_depth(model, w_lq)
                gt = convolve_along_depth(model, w_gt)

                # 4) 生成阶段 pair 处理：GT RMS 补偿 + shared maxabs no-clip + 保存方向转换
                lq_internal, gt_internal, lq_save, gt_save, scale_info = scale_pair_for_save(lq, gt, scale_floor=1e-6)

                if ENABLE_PAIR_SELF_CHECK:
                    # 配对检查在内部 [trace, depth] 方向上做，避免方阵转置造成误判。
                    last_diag = diagnose_pair_self_alignment(lq_internal, gt_internal)
                    if last_diag["ok"]:
                        break
                    if PAIR_CHECK_SAVE_FAILED:
                        fail_name = f"candidate_{idx:04d}_retry{retry}_{structure}_{forced_family}.png"
                        save_failed_pair_check_png(lq_internal, gt_internal, last_diag, FAILED_PAIR_DIR / fail_name)
                    print(
                        f"  [PAIR-CHECK RETRY] id={idx:04d}, structure={structure}, "
                        f"family={forced_family}, retry={retry + 1}/{MAX_PAIR_RETRY}, "
                        f"reason={last_diag.get('reason')}"
                    )
                else:
                    last_diag = {"ok": True, "status": "disabled", "reason": "pair self-check disabled"}
                    break
            else:
                raise RuntimeError(
                    f"Pair self-check failed after {MAX_PAIR_RETRY} retries: "
                    f"idx={idx:04d}, structure={structure}, family={forced_family}, "
                    f"last_diag={last_diag}"
                )

            stem = f"{idx:04d}"
            fname = f"{stem}.dat"

            # 保存为 [depth, trace]，与训练张量 [B,C,H,W] 中 H=depth/time, W=trace/lateral 一致。
            lq_save.astype(np.float32).tofile(LQ_DIR / fname)
            gt_save.astype(np.float32).tofile(GT_DIR / fname)
            np.save(WAVELET_DIR / f"{stem}_w_lq.npy", w_lq.astype(np.float32))
            np.save(WAVELET_DIR / f"{stem}_w_gt.npy", w_gt.astype(np.float32))

            meta = dict(meta_w)
            meta.update({
                "id": stem,
                "structure": structure,
                "source_script": item["file"],
                "seed": sample_seed,
                "n1": N1,
                "n2": N2,
                "dt": DT,
                "wavelet_length": WAVELET_LENGTH,
                **scale_info,
                "pair_self_check": last_diag,
                "pair_self_check_retry": int(retry),
                "pair_self_check_enabled": bool(ENABLE_PAIR_SELF_CHECK),
            })

            meta_path = META_DIR / f"{stem}.json"
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)

            need_qc = (
                (idx - START_INDEX) < QC_FIRST_N
                or ((idx - START_INDEX + 1) % QC_EVERY == 0)
                or ((structure, meta["family"]) not in qc_seen_structure_family)
            )
            if need_qc:
                save_qc_figure(lq_save, gt_save, w_lq, w_gt, meta, QC_DIR / f"{stem}_qc.png", dt=DT)
                qc_seen_structure_family.add((structure, meta["family"]))

            row = {
                "id": stem,
                "structure": structure,
                "family": meta["family"],
                "variation": "stationary",
                "phase_deg": meta["phase_deg"],
                "phase_group": phase_group(meta["phase_deg"]),
                "lq_path": str(LQ_DIR / fname),
                "gt_path": str(GT_DIR / fname),
                "meta_path": str(meta_path),
                "w_lq_path": str(WAVELET_DIR / f"{stem}_w_lq.npy"),
                "w_gt_path": str(WAVELET_DIR / f"{stem}_w_gt.npy"),
            }
            rows.append(row)

            if (j + 1) % 20 == 0 or (j + 1) == NUM_PER_STRUCTURE:
                check_corr = meta.get("pair_self_check", {}).get("same_env_corr", None)
                corr_txt = "" if check_corr is None else f", env_corr={check_corr:.3f}"
                print(
                    f"  [{j + 1:04d}/{NUM_PER_STRUCTURE}] latest id={stem}, "
                    f"family={meta['family']}, phase={meta['phase_deg']:.2f}, retry={retry}{corr_txt}"
                )

            idx += 1

    write_summary_csv(rows)
    print(f"\nAll done. Dataset saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
