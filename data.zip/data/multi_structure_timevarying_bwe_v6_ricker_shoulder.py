# -*- coding: utf-8 -*-
"""
Multi-structure time-varying wavelet waveform-preserving bandwidth-extension dataset generator.

目标：
- 多结构 + 三子波（ricker / ormsby / klauder）
- time-varying wavelet: 子波只随深度/时间变化，不随横向变化
- 无噪声、同尺寸 LQ/GT（512x512 -> 512x512）
- LQ/GT 同源：同一深度位置的 GT 子波平滑包络 LQ 子波

使用方式：
把本脚本放到和以下构造生成脚本同一个文件夹：
  dongyingbatch.py
  helanjinhaiyanpendi.py
  huazhuang.py
  malinbatch_noise_dat.py
  malinbatchnewfold&noise&q.py
  tixingyanqiubatch_noise_dat.py

运行：
  python multi_structure_timevarying_bwe_v6_ricker_shoulder.py

输出：
  dataset_waveform_bwe_multistruct_timevarying_v6_ricker_shoulder/
    lq/*.dat
    gt/*.dat
    meta/*.json
    wavelets/*_w_lq.npy            # 中部代表子波，兼容原 split 脚本
    wavelets/*_w_gt.npy            # 中部代表子波，兼容原 split 脚本
    wavelets/*_wavelet_field.npz   # top/mid/bottom 代表子波与深度位置
    qc/*.png
"""

import csv
import json
import math
import shutil
import importlib.util
from pathlib import Path
from collections import Counter

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert


# =========================================================
# 0. 配置区：主要改这里
# =========================================================
SCRIPT_DIR = Path(__file__).resolve().parent

SOURCE_SCRIPTS = [
    {"name": "dongying",        "file": "dongyingbatch.py"},
    {"name": "helan_basin",     "file": "helanjinhaiyanpendi.py"},
    {"name": "huazhuang",       "file": "huazhuang.py"},
    {"name": "malin",           "file": "malinbatch_noise_dat.py"},
    {"name": "malin_newfold",   "file": "malinbatchnewfold&noise&q.py"},
    {"name": "tixing_salt",     "file": "tixingyanqiubatch_noise_dat.py"},
]

# 每种反射结构生成多少个样本。先小规模 QC，满意后再改大。
NUM_PER_STRUCTURE = 100

# 输出尺寸
N1 = 512
N2 = 512

DT = 0.004
WAVELET_LENGTH = 0.256

# 非平稳卷积窗口：win 越大变化越平滑，step 越小越平滑但更慢
TV_WIN = 128
TV_STEP = 32

OUT_DIR = SCRIPT_DIR / "dataset_waveform_bwe_multistruct_timevarying_v6_ricker_shoulder"
LQ_DIR = OUT_DIR / "lq"
GT_DIR = OUT_DIR / "gt"
META_DIR = OUT_DIR / "meta"
WAVELET_DIR = OUT_DIR / "wavelets"
QC_DIR = OUT_DIR / "qc"

START_INDEX = 1
FAMILY_RATIO = {"ricker": 0.40, "ormsby": 0.40, "klauder": 0.20}

# 相位：这里允许常相位 + 很弱的深度漂移；LQ/GT 在同一深度使用完全相同相位。
PHASE_PROB = 0.50
PHASE_RANGE = (-30.0, 30.0)
PHASE_DRIFT_RANGE = (-8.0, 8.0)

QC_FIRST_N = 5
QC_EVERY = 50
RANDOM_SEED = 2026
COPY_SOURCE_SCRIPTS = True

# =========================================================
# 0.2 与 stationary residual-compressed 版本一致的质量控制策略
# =========================================================
# 内部构造脚本统一返回 (n2, n1) = [trace, depth]；卷积沿 axis=1(depth)。
# 最终 .dat 统一保存为 [depth, trace]，与训练 data_layout=depth_trace 对齐，避免方向错误。
INTERNAL_LAYOUT = "trace_depth"
SAVE_LAYOUT = "depth_trace"

# 运行前默认清空输出目录，避免旧文件残留造成 QC / split 错配。
OVERWRITE_OUT_DIR = True

# 保存时不再使用 percentile clip。使用 shared maxabs no-clip 缩放到 [-0.98,0.98]，避免 LQ 截幅。
SAVE_MODE = "shared_maxabs_no_clip"  # "shared_maxabs_no_clip" / "raw" / "shared_percentile_clip"
SAVE_TARGET_MAXABS = 0.98
NORMALIZE_PERCENTILE = 99.95

# 子波采用能量归一化，避免 LQ 子波因带宽窄而峰值大、卷积后 RMS 系统性大于 GT。
WAVELET_NORM_MODE = "energy"  # "energy" / "peak"

# GT 子波和数据能量控制：若 GT RMS 弱于 LQ，则只增强 GT，不压低 LQ。
ENFORCE_GT_WAVELET_ENVELOPE = True
ENVELOPE_FREQ_MAX = 110.0
ENVELOPE_ACTIVE_THRESHOLD = 0.02
MATCH_GT_RMS_IF_WEAKER = True
GT_RMS_TARGET_RATIO = 1.03
MAX_GT_RMS_GAIN = 3.0

# 生成阶段候选筛选：避免残差比例过大或方向/配对异常。
ENABLE_PAIR_SELF_CHECK = True
MAX_PAIR_RETRY = 16
PAIR_CHECK_MIN_ENV_CORR = 0.14
PAIR_CHECK_MIN_RAW_CORR = -0.05
PAIR_CHECK_ORIENTATION_MARGIN = 0.08
PAIR_CHECK_DOWNSAMPLE = 4

ENABLE_RESIDUAL_RATIO_FILTER = True
RESIDUAL_RATIO_ACCEPT_MIN = 0.30
RESIDUAL_RATIO_ACCEPT_MAX = 0.70
RESIDUAL_RATIO_FALLBACK_MAX = 0.82
# Ricker 拓频将比其余两类子波更激进，因此允许更宽的残差接受上限；
# 其他家族继续沿用旧阈值，避免无谓改变已满意的数据分布。
RESIDUAL_RATIO_ACCEPT_MAX_BY_FAMILY = {"ricker": 0.86}
RESIDUAL_RATIO_FALLBACK_MAX_BY_FAMILY = {"ricker": 0.98}
RESIDUAL_SELECTION_KEY = "saved_internal_residual_ratio_to_gt"

# 仅写入 meta warning，不直接拒绝。
WARN_CLIP_RATIO = 1e-3
WARN_LQ_GT_RMS_RATIO = 1.30
WARN_RESIDUAL_RATIO = 0.82

# QC 中展示 top/mid/bottom 三个深度位置的局部子波
REP_DEPTHS = [0.15, 0.50, 0.85]
REP_NAMES = ["top", "middle", "bottom"]

# =========================================================
# 0.1 底层频率降低：增强时变，但尽量不动顶部/中部锚点
# =========================================================
# 说明：只改 depth_anchors 最后一个锚点 depth=1.0，对 top/mid 的锚点不直接改动。
# 这样 QC 中 top/middle 的代表子波基本保持原设定，bottom 更低频，时变更明显。
BOTTOM_ONLY_STRONGER_TIME_VARIATION = True

# Ricker：v6 专门增强 Ricker 家族的“峰后肩部拓频”。
# 目标：
# 1) 继续降低 LQ 主频，使 LQ 在峰后更早下滑；
# 2) GT 不只拉高 70Hz 以后的尾部，而是在 25~85Hz 形成宽肩部；
# 3) 允许 Ricker 样本残差适度增大，但 Ormsby / Klauder 逻辑不变。
RICKER_TOP_F0_RANGE = (16.0, 22.0)
RICKER_BOTTOM_F0_BASE_RANGE = (7.0, 11.0)
RICKER_BOTTOM_F0_RANGE = (3.5, 6.5)
RICKER_ALPHA_TOP_RANGE = (1.24, 1.42)
RICKER_ALPHA_BOTTOM_RANGE = (1.40, 1.70)
RICKER_POWER_TOP_RANGE = (1.60, 1.90)
RICKER_POWER_BOTTOM_RANGE = (1.85, 2.25)
RICKER_GAMMA_TOP_RANGE = (0.46, 0.62)
RICKER_GAMMA_BOTTOM_RANGE = (0.50, 0.68)
# GT 高频参考分量：相对 LQ 参考频率再抬高一档，用于形成高频端延展。
RICKER_HF_FACTOR_TOP_RANGE = (2.10, 2.45)
RICKER_HF_FACTOR_BOTTOM_RANGE = (2.35, 2.85)
RICKER_HF_BLEND_TOP_RANGE = (0.55, 0.78)
RICKER_HF_BLEND_BOTTOM_RANGE = (0.70, 0.95)
# GT 峰后肩部增强：重点让 GT 在 LQ 波峰下滑后，即约 25~85Hz，尽量高于 LQ。
RICKER_SHOULDER_FLOOR_TOP_RANGE = (0.34, 0.48)
RICKER_SHOULDER_FLOOR_BOTTOM_RANGE = (0.42, 0.60)
RICKER_SHOULDER_GAIN_TOP_RANGE = (1.35, 1.70)
RICKER_SHOULDER_GAIN_BOTTOM_RANGE = (1.55, 2.00)
RICKER_SHOULDER_KNOT_FREQS = [0.0, 12.0, 20.0, 30.0, 45.0, 65.0, 85.0, 110.0, 124.0]
RICKER_SHOULDER_KNOT_GAINS = [1.0, 1.0, 1.12, 1.45, 1.75, 1.70, 1.42, 1.10, 1.0]

# Ormsby：降低底层 LQ/GT 的 Ormsby 四角点，重点降低 f3/f4。
ORMSBY_LQ_BOTTOM_F1_RANGE = (1.0, 2.5)
ORMSBY_LQ_BOTTOM_F2_RANGE = (3.0, 5.5)
ORMSBY_LQ_BOTTOM_F3_RANGE = (8.0, 12.0)
ORMSBY_LQ_BOTTOM_F4_RANGE = (16.0, 21.0)

ORMSBY_GT_BOTTOM_F1_RANGE = (0.5, 2.5)
ORMSBY_GT_BOTTOM_F2_RANGE = (3.0, 6.0)
ORMSBY_GT_BOTTOM_F3_RANGE = (18.0, 28.0)
ORMSBY_GT_BOTTOM_F4_RANGE = (32.0, 46.0)

# Klauder：降低底层扫频高端 f_end；低端只做温和降低。
KLAUDER_LQ_BOTTOM_START_RANGE = (8.0, 12.0)
KLAUDER_LQ_BOTTOM_END_RANGE = (22.0, 30.0)
KLAUDER_GT_BOTTOM_START_RANGE = (2.5, 6.0)
KLAUDER_GT_BOTTOM_END_RANGE = (34.0, 46.0)


# =========================================================
# 1. 基础工具函数
# =========================================================
def reset_output_dir():
    if OVERWRITE_OUT_DIR and OUT_DIR.exists():
        print(f"[RESET] remove old output directory: {OUT_DIR}")
        shutil.rmtree(OUT_DIR)


def ensure_dirs():
    for d in [LQ_DIR, GT_DIR, META_DIR, WAVELET_DIR, QC_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def sanitize_float(x):
    return float(np.asarray(x).item())


def time_axis(dt=0.004, length=0.256):
    return np.arange(-length / 2.0, length / 2.0 + 0.5 * dt, dt, dtype=np.float32)


def normalize_wavelet(w, mode=None):
    """
    子波归一化。

    默认 energy 归一化，而不是 peak 归一化。这样可以缓解旧版本中
    窄带 LQ 子波峰值归一化后卷积能量偏大的问题。
    """
    w = np.asarray(w, dtype=np.float64)
    w = w - np.mean(w)
    mode = WAVELET_NORM_MODE if mode is None else str(mode).lower()
    if mode == "energy":
        s = float(np.sqrt(np.sum(w ** 2)))
    elif mode in ("peak", "maxabs"):
        s = float(np.max(np.abs(w)))
    else:
        raise ValueError(f"Unknown WAVELET_NORM_MODE: {mode}")
    if s > 1e-12:
        w = w / s
    return w.astype(np.float32)


def phase_rotate(w, phase_deg=0.0):
    w = np.asarray(w, dtype=np.float64)
    if abs(float(phase_deg)) < 1e-12:
        return normalize_wavelet(w)
    wh = np.imag(hilbert(w))
    phi = np.deg2rad(float(phase_deg))
    wp = np.cos(phi) * w - np.sin(phi) * wh
    return normalize_wavelet(wp)


def centered_wavelet_from_amp(amp, n_wavelet, nfft):
    amp = np.asarray(amp, dtype=np.float64)
    amp = np.maximum(amp, 0.0)
    amp[0] = 0.0
    w_full = np.fft.irfft(amp.astype(np.complex128), n=nfft)
    w_full = np.fft.fftshift(w_full)
    center = nfft // 2
    half = n_wavelet // 2
    start = center - half
    w = w_full[start:start + n_wavelet]
    return normalize_wavelet(w)


def high_frequency_taper(freqs, f_start=100.0, f_end=124.0):
    taper = np.ones_like(freqs, dtype=np.float64)
    taper[freqs >= f_end] = 0.0
    m = (freqs > f_start) & (freqs < f_end)
    if np.any(m):
        x = (freqs[m] - f_start) / (f_end - f_start + 1e-12)
        taper[m] = 0.5 + 0.5 * np.cos(np.pi * x)
    return taper


def ricker_shoulder_gain_curve(freqs, shoulder_gain=1.0):
    """Ricker 专用中高频肩部增益。返回一个平滑插值的频域乘子。"""
    freqs = np.asarray(freqs, dtype=np.float64)
    knot_f = np.asarray(RICKER_SHOULDER_KNOT_FREQS, dtype=np.float64)
    knot_g_base = np.asarray(RICKER_SHOULDER_KNOT_GAINS, dtype=np.float64)
    # shoulder_gain 只放大相对 1.0 的增益部分，避免低频被整体抬高。
    knot_g = 1.0 + float(shoulder_gain) * (knot_g_base - 1.0)
    return np.interp(freqs, knot_f, knot_g, left=knot_g[0], right=knot_g[-1]).astype(np.float64)


def ricker_shoulder_floor_curve(freqs, shoulder_floor=0.45):
    """Ricker 专用宽肩部频谱下限，用于保证 GT 在峰后下滑段不过早坍塌。"""
    freqs = np.asarray(freqs, dtype=np.float64)
    # 从约 18~30Hz 平滑抬升，在 30~85Hz 保持肩部，85~118Hz 平滑回落。
    floor = trapezoid_amp(freqs, 18.0, 30.0, 85.0, 118.0)
    return float(shoulder_floor) * floor


def smooth_max(a, b, p=8.0):
    a = np.maximum(np.asarray(a, dtype=np.float64), 0.0)
    b = np.maximum(np.asarray(b, dtype=np.float64), 0.0)
    return (a ** p + b ** p) ** (1.0 / p)


def ricker_amp_spectrum(freqs, f0):
    freqs = np.asarray(freqs, dtype=np.float64)
    x = freqs / (float(f0) + 1e-12)
    amp = (x ** 2) * np.exp(-(x ** 2))
    amp[0] = 0.0
    amp = amp / (np.max(amp) + 1e-12)
    return amp


def generalized_ricker_amp_spectrum(freqs, f0, alpha=1.15, power=1.30):
    freqs = np.asarray(freqs, dtype=np.float64)
    x = np.maximum(freqs / (float(f0) + 1e-12), 0.0)
    alpha = float(alpha)
    power = float(power)
    amp = (x ** alpha) * np.exp((alpha / (power + 1e-12)) * (1.0 - x ** power))
    amp[0] = 0.0
    amp = amp / (np.max(amp) + 1e-12)
    return amp


def trapezoid_amp(freqs, f1, f2, f3, f4):
    freqs = np.asarray(freqs, dtype=np.float64)
    amp = np.zeros_like(freqs, dtype=np.float64)
    m = (freqs >= f1) & (freqs < f2)
    if np.any(m):
        amp[m] = (freqs[m] - f1) / (f2 - f1 + 1e-12)
    amp[(freqs >= f2) & (freqs <= f3)] = 1.0
    m = (freqs > f3) & (freqs <= f4)
    if np.any(m):
        amp[m] = 1.0 - (freqs[m] - f3) / (f4 - f3 + 1e-12)
    return np.clip(amp, 0.0, 1.0)


def sweep_band_amp(freqs, f_start, f_end, taper=4.0):
    freqs = np.asarray(freqs, dtype=np.float64)
    f_start = float(f_start)
    f_end = float(f_end)
    taper = float(taper)
    if f_end <= f_start:
        raise ValueError(f"Invalid sweep band: {f_start}, {f_end}")
    taper = max(0.5, min(taper, 0.45 * (f_end - f_start)))
    amp = np.zeros_like(freqs, dtype=np.float64)

    f1 = max(0.0, f_start - taper)
    f2 = f_start + taper
    m = (freqs >= f1) & (freqs < f2)
    if np.any(m):
        x = (freqs[m] - f1) / (f2 - f1 + 1e-12)
        amp[m] = 0.5 - 0.5 * np.cos(np.pi * x)

    m = (freqs >= f2) & (freqs <= f_end - taper)
    amp[m] = 1.0

    m_mid = (freqs >= f_start) & (freqs <= f_end)
    amp[m_mid] = np.maximum(amp[m_mid], 0.85)

    f3 = f_end - taper
    f4 = f_end + taper
    m = (freqs > f3) & (freqs <= f4)
    if np.any(m):
        x = (freqs[m] - f3) / (f4 - f3 + 1e-12)
        amp[m] = np.maximum(amp[m], 0.5 + 0.5 * np.cos(np.pi * x))

    amp[freqs <= 0.0] = 0.0
    return np.clip(amp, 0.0, 1.0)


def amplitude_spectrum(w, dt=0.004, nfft=4096):
    w = np.asarray(w, dtype=np.float32)
    W = np.fft.rfft(w, n=nfft)
    amp = np.abs(W)
    amp = amp / (np.max(amp) + 1e-12)
    f = np.fft.rfftfreq(nfft, d=dt)
    return f, amp


def interp1(depth_norm, anchors, values):
    return float(np.interp(float(depth_norm), anchors, values))


def interp_vec(depth_norm, anchors, values_2d):
    values_2d = np.asarray(values_2d, dtype=np.float64)
    return np.array([np.interp(float(depth_norm), anchors, values_2d[:, k]) for k in range(values_2d.shape[1])], dtype=np.float64)


def smooth_random_curve(rng, start, end, anchors, jitter=0.0, enforce_desc=False, enforce_asc=False):
    vals = np.linspace(float(start), float(end), len(anchors))
    if jitter > 0:
        vals += rng.normal(0.0, jitter, size=len(anchors))
        vals[0] = float(start)
        vals[-1] = float(end)
    if enforce_desc:
        vals = np.maximum.accumulate(vals[::-1])[::-1]
    if enforce_asc:
        vals = np.maximum.accumulate(vals)
    return vals.astype(np.float64)



def rms(arr):
    arr = np.asarray(arr, dtype=np.float64)
    return float(np.sqrt(np.mean(arr ** 2) + 1e-12))


def safe_ratio(a, b, eps=1e-12):
    return float(a / (b + eps))


def to_saved_layout(arr):
    """内部 [trace, depth] -> 保存/训练 [depth, trace]。"""
    arr = np.asarray(arr, dtype=np.float32)
    if INTERNAL_LAYOUT == SAVE_LAYOUT:
        return arr.astype(np.float32)
    if INTERNAL_LAYOUT == "trace_depth" and SAVE_LAYOUT == "depth_trace":
        return arr.T.astype(np.float32)
    if INTERNAL_LAYOUT == "depth_trace" and SAVE_LAYOUT == "trace_depth":
        return arr.T.astype(np.float32)
    raise ValueError(f"Unsupported layout transform: {INTERNAL_LAYOUT} -> {SAVE_LAYOUT}")


def wavelet_envelope_gain(w_lq, w_gt, dt=0.004, fmax=110.0, active_threshold=0.02):
    """检查 GT 子波振幅谱在 LQ 有效频带内是否包络 LQ。"""
    f_lq, a_lq = amplitude_spectrum(w_lq, dt=dt)
    f_gt, a_gt = amplitude_spectrum(w_gt, dt=dt)
    m = (f_lq > 0.0) & (f_lq <= float(fmax)) & (a_lq >= float(active_threshold))
    if not np.any(m):
        return 1.0, 0.0
    min_margin = float(np.min(a_gt[m] - a_lq[m]))
    if min_margin >= -1e-4:
        return 1.0, min_margin
    ratio = np.max(a_lq[m] / np.maximum(a_gt[m], 1e-6))
    gain = float(np.clip(ratio, 1.0, 2.0))
    return gain, min_margin


def enforce_gt_wavelet_envelope(w_lq, w_gt, dt=0.004):
    if not ENFORCE_GT_WAVELET_ENVELOPE:
        return w_lq.astype(np.float32), w_gt.astype(np.float32), {"enabled": False}
    gain, min_margin_before = wavelet_envelope_gain(
        w_lq, w_gt, dt=dt, fmax=ENVELOPE_FREQ_MAX, active_threshold=ENVELOPE_ACTIVE_THRESHOLD
    )
    w_gt2 = (np.asarray(w_gt, dtype=np.float32) * gain).astype(np.float32)
    _, min_margin_after = wavelet_envelope_gain(
        w_lq, w_gt2, dt=dt, fmax=ENVELOPE_FREQ_MAX, active_threshold=ENVELOPE_ACTIVE_THRESHOLD
    )
    return w_lq.astype(np.float32), w_gt2.astype(np.float32), {
        "enabled": True,
        "gain": sanitize_float(gain),
        "min_norm_amp_margin_before": sanitize_float(min_margin_before),
        "min_norm_amp_margin_after": sanitize_float(min_margin_after),
        "freq_max": sanitize_float(ENVELOPE_FREQ_MAX),
        "active_threshold": sanitize_float(ENVELOPE_ACTIVE_THRESHOLD),
    }

# =========================================================
# 2. 局部子波生成：给定局部参数 -> w_lq / w_gt
# =========================================================
def ricker_pair_from_params(f0_lq, alpha_gt, power_gt, gamma, phase_deg,
                            hf_factor=2.45, hf_blend=0.75,
                            shoulder_floor=0.45, shoulder_gain=1.0,
                            dt=0.004, length=0.256):
    n = len(time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)

    A_lq = ricker_amp_spectrum(freqs, f0_lq)
    A_wide = generalized_ricker_amp_spectrum(freqs, f0=f0_lq, alpha=alpha_gt, power=power_gt)
    A_wide = A_wide ** gamma
    A_wide[0] = 0.0

    # 高频参考分量：拉开真正高频端。
    hf_f0 = max(float(f0_lq) * float(hf_factor), float(f0_lq) + 10.0)
    A_hf = ricker_amp_spectrum(freqs, hf_f0) * float(hf_blend)

    # v6 核心：峰后肩部增强。
    # 1) 对原宽频谱乘以 25~85Hz 强化的平滑增益；
    # 2) 再叠加一个 18~118Hz 的宽肩部下限，防止 GT 在 LQ 峰后立即下滑。
    A_base = smooth_max(A_wide, A_lq, p=8.0)
    A_boost = A_base * ricker_shoulder_gain_curve(freqs, shoulder_gain=shoulder_gain)
    A_floor = ricker_shoulder_floor_curve(freqs, shoulder_floor=shoulder_floor)

    A_gt = smooth_max(A_boost, A_hf, p=6.0)
    A_gt = smooth_max(A_gt, A_floor, p=6.0)
    A_gt *= high_frequency_taper(freqs, f_start=114.0, f_end=124.0)
    A_gt = A_gt / (np.max(A_gt) + 1e-12)

    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)
    w_lq = phase_rotate(w_lq0, phase_deg)
    w_gt = phase_rotate(w_gt0, phase_deg)
    w_lq, w_gt, _ = enforce_gt_wavelet_envelope(w_lq, w_gt, dt=dt)
    return w_lq, w_gt


def ormsby_pair_from_bands(band_lq, band_gt, phase_deg, dt=0.004, length=0.256):
    n = len(time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)
    A_lq = trapezoid_amp(freqs, *band_lq)
    A_gt_raw = trapezoid_amp(freqs, *band_gt)
    A_gt = smooth_max(A_gt_raw, A_lq, p=10.0)
    A_gt *= high_frequency_taper(freqs, f_start=108.0, f_end=124.0)
    A_gt[0] = 0.0
    A_gt = A_gt / (np.max(A_gt) + 1e-12)
    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)
    w_lq = phase_rotate(w_lq0, phase_deg)
    w_gt = phase_rotate(w_gt0, phase_deg)
    w_lq, w_gt, _ = enforce_gt_wavelet_envelope(w_lq, w_gt, dt=dt)
    return w_lq, w_gt


def klauder_pair_from_sweep(sweep_lq, sweep_gt, taper_lq, taper_gt, phase_deg, dt=0.004, length=0.256):
    n = len(time_axis(dt, length))
    nfft = 4096
    freqs = np.fft.rfftfreq(nfft, d=dt)
    A_lq = sweep_band_amp(freqs, sweep_lq[0], sweep_lq[1], taper=taper_lq)
    A_gt_raw = sweep_band_amp(freqs, sweep_gt[0], sweep_gt[1], taper=taper_gt)
    A_gt = smooth_max(A_gt_raw, A_lq, p=10.0)
    A_gt *= high_frequency_taper(freqs, f_start=100.0, f_end=124.0)
    A_gt[0] = 0.0
    A_gt = A_gt / (np.max(A_gt) + 1e-12)
    w_lq0 = centered_wavelet_from_amp(A_lq, n, nfft)
    w_gt0 = centered_wavelet_from_amp(A_gt, n, nfft)
    w_lq = phase_rotate(w_lq0, phase_deg)
    w_gt = phase_rotate(w_gt0, phase_deg)
    w_lq, w_gt, _ = enforce_gt_wavelet_envelope(w_lq, w_gt, dt=dt)
    return w_lq, w_gt


def make_phase_curve(rng, anchors):
    if rng.random() >= PHASE_PROB:
        return np.zeros(len(anchors), dtype=np.float64), 0.0
    base = float(rng.uniform(PHASE_RANGE[0], PHASE_RANGE[1]))
    if abs(base) < 3.0:
        base = 3.0 if base >= 0 else -3.0
    drift = float(rng.uniform(PHASE_DRIFT_RANGE[0], PHASE_DRIFT_RANGE[1]))
    curve = np.linspace(base - 0.5 * drift, base + 0.5 * drift, len(anchors))
    return curve.astype(np.float64), base


# =========================================================
# 3. time-varying 子波场工厂
# =========================================================
def make_timevarying_wavelet_model(rng, forced_family=None, dt=0.004, length=0.256):
    """
    返回：
      wavelet_func(depth_norm) -> w_lq, w_gt, local_meta
      meta_global
    """
    if forced_family is None:
        families = list(FAMILY_RATIO.keys())
        probs = np.array([FAMILY_RATIO[k] for k in families], dtype=np.float64)
        probs = probs / probs.sum()
        family = str(rng.choice(families, p=probs))
    else:
        family = str(forced_family)

    anchors = np.array([0.0, 0.33, 0.66, 1.0], dtype=np.float64)
    phase_curve, phase_base = make_phase_curve(rng, anchors)

    if family == "ricker":
        # 浅层主频高，深层主频低。GT 仍在每个深度处包络 LQ。
        f0_top = float(rng.uniform(*RICKER_TOP_F0_RANGE))
        f0_bottom = float(rng.uniform(*RICKER_BOTTOM_F0_BASE_RANGE))
        f0_curve = smooth_random_curve(rng, f0_top, f0_bottom, anchors, jitter=0.55, enforce_desc=True)

        # 只进一步降低底层 depth=1.0 的主频；顶部和中部锚点不直接改动。
        if BOTTOM_ONLY_STRONGER_TIME_VARIATION:
            f0_curve[-1] = min(float(f0_curve[-1]), float(rng.uniform(*RICKER_BOTTOM_F0_RANGE)))
            f0_curve = np.maximum.accumulate(f0_curve[::-1])[::-1]

        alpha_curve = smooth_random_curve(
            rng,
            rng.uniform(*RICKER_ALPHA_TOP_RANGE),
            rng.uniform(*RICKER_ALPHA_BOTTOM_RANGE),
            anchors, jitter=0.035
        )
        power_curve = smooth_random_curve(
            rng,
            rng.uniform(*RICKER_POWER_TOP_RANGE),
            rng.uniform(*RICKER_POWER_BOTTOM_RANGE),
            anchors, jitter=0.035
        )
        gamma_curve = smooth_random_curve(
            rng,
            rng.uniform(*RICKER_GAMMA_TOP_RANGE),
            rng.uniform(*RICKER_GAMMA_BOTTOM_RANGE),
            anchors, jitter=0.025
        )
        hf_factor_curve = smooth_random_curve(
            rng,
            rng.uniform(*RICKER_HF_FACTOR_TOP_RANGE),
            rng.uniform(*RICKER_HF_FACTOR_BOTTOM_RANGE),
            anchors, jitter=0.04, enforce_asc=True
        )
        hf_blend_curve = smooth_random_curve(
            rng,
            rng.uniform(*RICKER_HF_BLEND_TOP_RANGE),
            rng.uniform(*RICKER_HF_BLEND_BOTTOM_RANGE),
            anchors, jitter=0.03, enforce_asc=True
        )
        shoulder_floor_curve = smooth_random_curve(
            rng,
            rng.uniform(*RICKER_SHOULDER_FLOOR_TOP_RANGE),
            rng.uniform(*RICKER_SHOULDER_FLOOR_BOTTOM_RANGE),
            anchors, jitter=0.025, enforce_asc=True
        )
        shoulder_gain_curve = smooth_random_curve(
            rng,
            rng.uniform(*RICKER_SHOULDER_GAIN_TOP_RANGE),
            rng.uniform(*RICKER_SHOULDER_GAIN_BOTTOM_RANGE),
            anchors, jitter=0.05, enforce_asc=True
        )

        def wavelet_func(depth_norm):
            f0 = interp1(depth_norm, anchors, f0_curve)
            alpha = interp1(depth_norm, anchors, alpha_curve)
            power = interp1(depth_norm, anchors, power_curve)
            gamma = interp1(depth_norm, anchors, gamma_curve)
            hf_factor = interp1(depth_norm, anchors, hf_factor_curve)
            hf_blend = interp1(depth_norm, anchors, hf_blend_curve)
            shoulder_floor = interp1(depth_norm, anchors, shoulder_floor_curve)
            shoulder_gain = interp1(depth_norm, anchors, shoulder_gain_curve)
            phase = interp1(depth_norm, anchors, phase_curve)
            w_lq, w_gt = ricker_pair_from_params(
                f0, alpha, power, gamma, phase,
                hf_factor=hf_factor,
                hf_blend=hf_blend,
                shoulder_floor=shoulder_floor,
                shoulder_gain=shoulder_gain,
                dt=dt,
                length=length,
            )
            return w_lq, w_gt, {
                "depth_norm": sanitize_float(depth_norm),
                "f0_lq": sanitize_float(f0),
                "alpha_gt": sanitize_float(alpha),
                "power_gt": sanitize_float(power),
                "gamma": sanitize_float(gamma),
                "hf_factor": sanitize_float(hf_factor),
                "hf_blend": sanitize_float(hf_blend),
                "shoulder_floor": sanitize_float(shoulder_floor),
                "shoulder_gain": sanitize_float(shoulder_gain),
                "phase_deg": sanitize_float(phase),
            }

        meta = {
            "family": "ricker",
            "variation": "time",
            "stationary": False,
            "time_varying": True,
            "space_varying": False,
            "noise": False,
            "same_size": True,
            "phase_deg": sanitize_float(phase_base),
            "depth_anchors": [sanitize_float(x) for x in anchors],
            "f0_lq_curve": [sanitize_float(x) for x in f0_curve],
            "alpha_gt_curve": [sanitize_float(x) for x in alpha_curve],
            "power_gt_curve": [sanitize_float(x) for x in power_curve],
            "gamma_curve": [sanitize_float(x) for x in gamma_curve],
            "hf_factor_curve": [sanitize_float(x) for x in hf_factor_curve],
            "hf_blend_curve": [sanitize_float(x) for x in hf_blend_curve],
            "shoulder_floor_curve": [sanitize_float(x) for x in shoulder_floor_curve],
            "shoulder_gain_curve": [sanitize_float(x) for x in shoulder_gain_curve],
            "shoulder_knot_freqs": [sanitize_float(x) for x in RICKER_SHOULDER_KNOT_FREQS],
            "shoulder_knot_gains": [sanitize_float(x) for x in RICKER_SHOULDER_KNOT_GAINS],
            "phase_curve": [sanitize_float(x) for x in phase_curve],
            "tv_rule": "Ricker-derived time-varying (v6 shoulder): lower LQ f0 and explicit 25-85Hz GT shoulder so GT rises above LQ soon after LQ peak decay.",
        }
        return wavelet_func, meta

    if family == "ormsby":
        # 浅层频带更高更宽，深层高频上限下降；GT 始终比 LQ 更宽。
        lq_top = np.array([
            rng.uniform(8.0, 12.0),
            rng.uniform(14.0, 20.0),
            rng.uniform(32.0, 40.0),
            rng.uniform(46.0, 56.0),
        ], dtype=np.float64)
        lq_bottom = np.array([
            rng.uniform(4.0, 8.0),
            rng.uniform(9.0, 14.0),
            rng.uniform(20.0, 27.0),
            rng.uniform(31.0, 39.0),
        ], dtype=np.float64)
        gt_top = np.array([
            rng.uniform(2.0, 4.5),
            rng.uniform(6.0, 10.0),
            rng.uniform(50.0, 66.0),
            rng.uniform(72.0, 92.0),
        ], dtype=np.float64)
        gt_bottom = np.array([
            rng.uniform(2.0, 4.5),
            rng.uniform(5.0, 9.0),
            rng.uniform(34.0, 48.0),
            rng.uniform(50.0, 68.0),
        ], dtype=np.float64)
        band_lq_curve = np.stack([np.linspace(lq_top[k], lq_bottom[k], len(anchors)) for k in range(4)], axis=1)
        band_gt_curve = np.stack([np.linspace(gt_top[k], gt_bottom[k], len(anchors)) for k in range(4)], axis=1)
        band_lq_curve += rng.normal(0.0, [0.3, 0.4, 0.7, 0.8], size=band_lq_curve.shape)
        band_gt_curve += rng.normal(0.0, [0.2, 0.3, 1.0, 1.2], size=band_gt_curve.shape)

        # 只降低底层 depth=1.0 的 Ormsby 频带角点；顶部/中部锚点不直接改动。
        if BOTTOM_ONLY_STRONGER_TIME_VARIATION:
            lq_f1_b = float(rng.uniform(*ORMSBY_LQ_BOTTOM_F1_RANGE))
            lq_f2_b = max(lq_f1_b + 3.0, float(rng.uniform(*ORMSBY_LQ_BOTTOM_F2_RANGE)))
            lq_f3_b = max(lq_f2_b + 8.0, float(rng.uniform(*ORMSBY_LQ_BOTTOM_F3_RANGE)))
            lq_f4_b = max(lq_f3_b + 6.0, float(rng.uniform(*ORMSBY_LQ_BOTTOM_F4_RANGE)))
            band_lq_curve[-1] = np.array([lq_f1_b, lq_f2_b, lq_f3_b, lq_f4_b], dtype=np.float64)

            gt_f1_b = float(rng.uniform(*ORMSBY_GT_BOTTOM_F1_RANGE))
            gt_f2_b = max(gt_f1_b + 3.0, float(rng.uniform(*ORMSBY_GT_BOTTOM_F2_RANGE)))
            gt_f3_b = max(lq_f3_b + 8.0, float(rng.uniform(*ORMSBY_GT_BOTTOM_F3_RANGE)))
            gt_f4_b = max(gt_f3_b + 8.0, float(rng.uniform(*ORMSBY_GT_BOTTOM_F4_RANGE)))
            band_gt_curve[-1] = np.array([gt_f1_b, gt_f2_b, gt_f3_b, gt_f4_b], dtype=np.float64)

        def fix_band_lq(b):
            f1, f2, f3, f4 = [float(x) for x in b]
            f2 = max(f2, f1 + 4.0)
            f3 = max(f3, f2 + 8.0)
            f4 = max(f4, f3 + 6.0)
            return np.array([f1, f2, f3, f4], dtype=np.float64)

        def fix_band_gt(b, lq_b):
            f1, f2, f3, f4 = [float(x) for x in b]
            f1 = max(1.5, f1)
            f2 = max(f2, f1 + 3.0)
            f3 = max(f3, float(lq_b[2]) + 8.0)
            f4 = max(f4, f3 + 8.0)
            f4 = min(f4, 96.0)
            return np.array([f1, f2, f3, f4], dtype=np.float64)

        for i in range(len(anchors)):
            band_lq_curve[i] = fix_band_lq(band_lq_curve[i])
            band_gt_curve[i] = fix_band_gt(band_gt_curve[i], band_lq_curve[i])

        def wavelet_func(depth_norm):
            b_lq = fix_band_lq(interp_vec(depth_norm, anchors, band_lq_curve))
            b_gt = fix_band_gt(interp_vec(depth_norm, anchors, band_gt_curve), b_lq)
            phase = interp1(depth_norm, anchors, phase_curve)
            w_lq, w_gt = ormsby_pair_from_bands(b_lq, b_gt, phase, dt=dt, length=length)
            return w_lq, w_gt, {
                "depth_norm": sanitize_float(depth_norm),
                "band_lq": [sanitize_float(x) for x in b_lq],
                "band_gt": [sanitize_float(x) for x in b_gt],
                "phase_deg": sanitize_float(phase),
            }

        meta = {
            "family": "ormsby",
            "variation": "time",
            "stationary": False,
            "time_varying": True,
            "space_varying": False,
            "noise": False,
            "same_size": True,
            "phase_deg": sanitize_float(phase_base),
            "depth_anchors": [sanitize_float(x) for x in anchors],
            "band_lq_curve": [[sanitize_float(x) for x in row] for row in band_lq_curve],
            "band_gt_curve": [[sanitize_float(x) for x in row] for row in band_gt_curve],
            "phase_curve": [sanitize_float(x) for x in phase_curve],
            "tv_rule": "Time-varying Ormsby: high-frequency corner decreases with depth; GT band expands and envelopes LQ at each depth.",
        }
        return wavelet_func, meta

    if family == "klauder":
        lq_top = np.array([rng.uniform(13.0, 18.0), rng.uniform(36.0, 44.0)], dtype=np.float64)
        lq_bottom = np.array([rng.uniform(10.0, 16.0), rng.uniform(26.0, 34.0)], dtype=np.float64)
        gt_top = np.array([rng.uniform(3.0, 7.0), rng.uniform(56.0, 74.0)], dtype=np.float64)
        gt_bottom = np.array([rng.uniform(3.0, 7.0), rng.uniform(34.0, 50.0)], dtype=np.float64)

        sweep_lq_curve = np.stack([np.linspace(lq_top[k], lq_bottom[k], len(anchors)) for k in range(2)], axis=1)
        sweep_gt_curve = np.stack([np.linspace(gt_top[k], gt_bottom[k], len(anchors)) for k in range(2)], axis=1)
        sweep_lq_curve += rng.normal(0.0, [0.4, 0.8], size=sweep_lq_curve.shape)
        sweep_gt_curve += rng.normal(0.0, [0.3, 1.2], size=sweep_gt_curve.shape)

        # 只降低底层 depth=1.0 的 Klauder sweep 频带；顶部/中部锚点不直接改动。
        if BOTTOM_ONLY_STRONGER_TIME_VARIATION:
            lq_start_b = float(rng.uniform(*KLAUDER_LQ_BOTTOM_START_RANGE))
            lq_end_b = max(lq_start_b + 14.0, float(rng.uniform(*KLAUDER_LQ_BOTTOM_END_RANGE)))
            sweep_lq_curve[-1] = np.array([lq_start_b, lq_end_b], dtype=np.float64)

            gt_start_b = float(rng.uniform(*KLAUDER_GT_BOTTOM_START_RANGE))
            gt_end_b = max(lq_end_b + 12.0, float(rng.uniform(*KLAUDER_GT_BOTTOM_END_RANGE)))
            sweep_gt_curve[-1] = np.array([gt_start_b, gt_end_b], dtype=np.float64)

        taper_lq = float(rng.uniform(2.0, 3.2))
        taper_gt = float(rng.uniform(5.0, 8.0))

        def fix_sweeps(s_lq, s_gt):
            f1, f2 = [float(x) for x in s_lq]
            f2 = max(f2, f1 + 14.0)
            lq = np.array([f1, f2], dtype=np.float64)
            f1g, f2g = [float(x) for x in s_gt]
            f1g = max(2.0, f1g)
            f2g = max(f2g, f2 + 12.0)
            f2g = min(f2g, 82.0)
            gt = np.array([f1g, f2g], dtype=np.float64)
            return lq, gt

        for i in range(len(anchors)):
            sweep_lq_curve[i], sweep_gt_curve[i] = fix_sweeps(sweep_lq_curve[i], sweep_gt_curve[i])

        def wavelet_func(depth_norm):
            s_lq, s_gt = fix_sweeps(
                interp_vec(depth_norm, anchors, sweep_lq_curve),
                interp_vec(depth_norm, anchors, sweep_gt_curve),
            )
            phase = interp1(depth_norm, anchors, phase_curve)
            w_lq, w_gt = klauder_pair_from_sweep(s_lq, s_gt, taper_lq, taper_gt, phase, dt=dt, length=length)
            return w_lq, w_gt, {
                "depth_norm": sanitize_float(depth_norm),
                "sweep_lq": [sanitize_float(x) for x in s_lq],
                "sweep_gt": [sanitize_float(x) for x in s_gt],
                "taper_lq": sanitize_float(taper_lq),
                "taper_gt": sanitize_float(taper_gt),
                "phase_deg": sanitize_float(phase),
            }

        meta = {
            "family": "klauder",
            "variation": "time",
            "stationary": False,
            "time_varying": True,
            "space_varying": False,
            "noise": False,
            "same_size": True,
            "phase_deg": sanitize_float(phase_base),
            "depth_anchors": [sanitize_float(x) for x in anchors],
            "sweep_lq_curve": [[sanitize_float(x) for x in row] for row in sweep_lq_curve],
            "sweep_gt_curve": [[sanitize_float(x) for x in row] for row in sweep_gt_curve],
            "taper_lq": sanitize_float(taper_lq),
            "taper_gt": sanitize_float(taper_gt),
            "phase_curve": [sanitize_float(x) for x in phase_curve],
            "tv_rule": "Time-varying Klauder-like: sweep high end decreases with depth; GT sweep range expands and envelopes LQ at each depth.",
        }
        return wavelet_func, meta

    raise ValueError(f"Unknown family: {family}")


def make_family_plan(n, rng):
    n_r = int(round(n * FAMILY_RATIO.get("ricker", 0.4)))
    n_o = int(round(n * FAMILY_RATIO.get("ormsby", 0.4)))
    n_k = n - n_r - n_o
    plan = ["ricker"] * n_r + ["ormsby"] * n_o + ["klauder"] * n_k
    rng.shuffle(plan)
    return plan


# =========================================================
# 4. 卷积、归一化、QC
# =========================================================
def convolve_along_depth(img, wavelet):
    img = np.asarray(img, dtype=np.float32)
    wavelet = np.asarray(wavelet, dtype=np.float32)
    n2, n1 = img.shape
    nw = wavelet.size
    nfft = int(2 ** np.ceil(np.log2(n1 + nw - 1)))
    IMG = np.fft.rfft(img, n=nfft, axis=1)
    W = np.fft.rfft(wavelet, n=nfft)
    y = np.fft.irfft(IMG * W[None, :], n=nfft, axis=1)
    start = (nw - 1) // 2
    return y[:, start:start + n1].astype(np.float32)


def make_window_starts(n, win, step):
    if n <= win:
        return [0]
    starts = list(range(0, n - win + 1, step))
    if starts[-1] != n - win:
        starts.append(n - win)
    return sorted(set(starts))


def convolve_time_varying(img, wavelet_func, win=128, step=32):
    """
    时变非平稳卷积：
    - 沿深度方向分窗；
    - 每个窗口中心深度生成一对局部子波；
    - 使用该局部子波对整幅模型做 stationary convolution；
    - 只取该窗口区域，Hann overlap-add 融合。

    这样比只卷积局部窗口更稳定，因为保留了窗口外反射对子波响应的贡献。
    """
    img = np.asarray(img, dtype=np.float32)
    n2, n1 = img.shape
    starts = make_window_starts(n1, win, step)
    weight = 0.05 + 0.95 * np.hanning(win).astype(np.float32)  # 避免边界权重为 0

    out_lq = np.zeros_like(img, dtype=np.float32)
    out_gt = np.zeros_like(img, dtype=np.float32)
    wsum = np.zeros_like(img, dtype=np.float32)
    window_records = []

    for s in starts:
        e = s + win
        depth_norm = np.clip((s + 0.5 * win) / max(n1 - 1, 1), 0.0, 1.0)
        w_lq, w_gt, local_meta = wavelet_func(depth_norm)

        conv_lq = convolve_along_depth(img, w_lq)
        conv_gt = convolve_along_depth(img, w_gt)

        out_lq[:, s:e] += conv_lq[:, s:e] * weight[None, :]
        out_gt[:, s:e] += conv_gt[:, s:e] * weight[None, :]
        wsum[:, s:e] += weight[None, :]

        rec = dict(local_meta)
        rec.update({"window_start": int(s), "window_end": int(e)})
        window_records.append(rec)

    out_lq = out_lq / np.maximum(wsum, 1e-6)
    out_gt = out_gt / np.maximum(wsum, 1e-6)
    return out_lq.astype(np.float32), out_gt.astype(np.float32), window_records


def vertical_band_energy(arr, lo=0.0, hi=0.5):
    """arr internal layout: [trace, depth]."""
    arr = np.asarray(arr, dtype=np.float32)
    spec = np.abs(np.fft.rfft(arr, axis=1, norm="ortho"))
    freqs = np.fft.rfftfreq(arr.shape[1], d=1.0)
    mask = (freqs >= float(lo)) & (freqs <= float(hi))
    if not np.any(mask):
        return 0.0
    return float(spec[:, mask].mean())


def band_energy_stats(lq, gt, prefix=""):
    bands = {
        "low": (0.00, 0.08),
        "mid": (0.08, 0.22),
        "high": (0.22, 0.50),
        "transition_low": (0.22, 0.24),
        "transition_mid": (0.24, 0.28),
    }
    out = {}
    for name, (lo, hi) in bands.items():
        e_lq = vertical_band_energy(lq, lo, hi)
        e_gt = vertical_band_energy(gt, lo, hi)
        out[f"{prefix}vertical_{name}_energy_lq"] = sanitize_float(e_lq)
        out[f"{prefix}vertical_{name}_energy_gt"] = sanitize_float(e_gt)
        out[f"{prefix}vertical_{name}_energy_gt_lq_ratio"] = sanitize_float(safe_ratio(e_gt, e_lq))
    return out


def pair_stats(lq, gt, prefix=""):
    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)
    res = gt - lq
    lq_r = rms(lq)
    gt_r = rms(gt)
    res_r = rms(res)
    p = f"{prefix}_" if prefix else ""
    out = {
        f"{p}rms_lq": sanitize_float(lq_r),
        f"{p}rms_gt": sanitize_float(gt_r),
        f"{p}rms_lq_gt_ratio": sanitize_float(safe_ratio(lq_r, gt_r)),
        f"{p}rms_gt_lq_ratio": sanitize_float(safe_ratio(gt_r, lq_r)),
        f"{p}rms_residual": sanitize_float(res_r),
        f"{p}residual_ratio_to_gt": sanitize_float(safe_ratio(res_r, gt_r)),
        f"{p}maxabs_lq": sanitize_float(np.max(np.abs(lq))),
        f"{p}maxabs_gt": sanitize_float(np.max(np.abs(gt))),
        f"{p}clip_ratio_lq_0999": sanitize_float(np.mean(np.abs(lq) >= 0.999)),
        f"{p}clip_ratio_gt_0999": sanitize_float(np.mean(np.abs(gt) >= 0.999)),
    }
    out.update(band_energy_stats(lq, gt, prefix=p))
    return out


def scale_pair_for_save(lq, gt, scale_floor=1e-6):
    """
    Pair 处理：GT RMS 补偿 + shared maxabs no-clip + 保存方向转换。
    返回 internal 和 saved 两套数组，便于内部自检与外部训练保持一致。
    """
    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)
    info = {}
    info.update(pair_stats(lq, gt, prefix="pre"))

    gt_gain = 1.0
    if MATCH_GT_RMS_IF_WEAKER:
        lq_r = rms(lq)
        gt_r = rms(gt)
        target_gt_r = lq_r * float(GT_RMS_TARGET_RATIO)
        if gt_r < target_gt_r:
            gt_gain = float(np.clip(target_gt_r / (gt_r + 1e-12), 1.0, MAX_GT_RMS_GAIN))
            gt = (gt * gt_gain).astype(np.float32)
    info["gt_rms_gain"] = sanitize_float(gt_gain)
    info.update(pair_stats(lq, gt, prefix="after_gt_gain"))

    if SAVE_MODE == "raw":
        scale = 1.0
        lq_out = lq.astype(np.float32)
        gt_out = gt.astype(np.float32)
    elif SAVE_MODE == "shared_maxabs_no_clip":
        maxabs = float(max(np.max(np.abs(lq)), np.max(np.abs(gt))))
        scale = max(maxabs / float(SAVE_TARGET_MAXABS), float(scale_floor))
        lq_out = (lq / scale).astype(np.float32)
        gt_out = (gt / scale).astype(np.float32)
        # 正常情况下不会触发；仅作为数值保护。
        lq_out = np.clip(lq_out, -1.0, 1.0).astype(np.float32)
        gt_out = np.clip(gt_out, -1.0, 1.0).astype(np.float32)
    elif SAVE_MODE == "shared_percentile_clip":
        vals = np.concatenate([np.abs(lq).reshape(-1), np.abs(gt).reshape(-1)])
        scale = max(float(np.percentile(vals, NORMALIZE_PERCENTILE)), float(scale_floor))
        lq_out = np.clip(lq / scale, -1.0, 1.0).astype(np.float32)
        gt_out = np.clip(gt / scale, -1.0, 1.0).astype(np.float32)
    else:
        raise ValueError(f"Unknown SAVE_MODE: {SAVE_MODE}")

    info["save_mode"] = SAVE_MODE
    info["save_scale"] = sanitize_float(scale)
    info["internal_layout"] = INTERNAL_LAYOUT
    info["save_layout"] = SAVE_LAYOUT
    info.update(pair_stats(lq_out, gt_out, prefix="saved_internal"))

    lq_save = to_saved_layout(lq_out)
    gt_save = to_saved_layout(gt_out)
    info.update(pair_stats(lq_save.T if SAVE_LAYOUT == "depth_trace" else lq_save,
                           gt_save.T if SAVE_LAYOUT == "depth_trace" else gt_save,
                           prefix="saved_check_internal"))
    info["saved_layout_shape_lq"] = [int(x) for x in lq_save.shape]
    info["saved_layout_shape_gt"] = [int(x) for x in gt_save.shape]

    warnings = []
    if info.get("saved_internal_clip_ratio_lq_0999", 0.0) > WARN_CLIP_RATIO:
        warnings.append("LQ clip ratio after save-scale is high; check SAVE_MODE/scale.")
    if info.get("saved_internal_rms_lq_gt_ratio", 0.0) > WARN_LQ_GT_RMS_RATIO:
        warnings.append("LQ RMS is much larger than GT RMS.")
    if info.get("saved_internal_residual_ratio_to_gt", 0.0) > WARN_RESIDUAL_RATIO:
        warnings.append("Residual ratio is high; pair may be too difficult.")
    if info.get("saved_internal_vertical_high_energy_gt_lq_ratio", 0.0) < 1.05:
        warnings.append("GT high-frequency energy is not clearly greater than LQ.")
    info["warnings"] = warnings
    return lq_out, gt_out, lq_save, gt_save, info


def normalize_pair_shared(lq, gt, percentile=99.5, scale_floor=1e-6):
    """兼容旧调用；新主流程使用 scale_pair_for_save。"""
    lq_i, gt_i, _, _, info = scale_pair_for_save(lq, gt, scale_floor=scale_floor)
    return lq_i, gt_i, float(info["save_scale"])


def residual_ratio_value(scale_info):
    return float(scale_info.get(RESIDUAL_SELECTION_KEY, scale_info.get("saved_internal_residual_ratio_to_gt", 999.0)))


def get_family_residual_accept_max(family=None):
    family = None if family is None else str(family).lower()
    return float(RESIDUAL_RATIO_ACCEPT_MAX_BY_FAMILY.get(family, RESIDUAL_RATIO_ACCEPT_MAX))


def get_family_residual_fallback_max(family=None):
    family = None if family is None else str(family).lower()
    return float(RESIDUAL_RATIO_FALLBACK_MAX_BY_FAMILY.get(family, RESIDUAL_RATIO_FALLBACK_MAX))


def residual_ratio_in_target(scale_info, family=None):
    rr = residual_ratio_value(scale_info)
    accept_max = get_family_residual_accept_max(family)
    return (rr >= float(RESIDUAL_RATIO_ACCEPT_MIN)) and (rr <= float(accept_max))


def residual_ratio_in_fallback(scale_info, family=None):
    rr = residual_ratio_value(scale_info)
    fallback_max = get_family_residual_fallback_max(family)
    return (rr >= float(RESIDUAL_RATIO_ACCEPT_MIN)) and (rr <= float(fallback_max))


def _block_mean_downsample(arr, factor=4):
    arr = np.asarray(arr, dtype=np.float32)
    factor = max(1, int(factor))
    if factor <= 1:
        return arr
    n2, n1 = arr.shape
    n2c = (n2 // factor) * factor
    n1c = (n1 // factor) * factor
    arr = arr[:n2c, :n1c]
    return arr.reshape(n2c // factor, factor, n1c // factor, factor).mean(axis=(1, 3))


def _standardize_for_corr(arr):
    arr = np.asarray(arr, dtype=np.float64)
    arr = arr - np.nanmean(arr)
    std = float(np.nanstd(arr))
    if not np.isfinite(std) or std < 1e-12:
        return np.zeros_like(arr, dtype=np.float64)
    return arr / std


def _safe_corr(a, b):
    a = np.asarray(a, dtype=np.float64).reshape(-1)
    b = np.asarray(b, dtype=np.float64).reshape(-1)
    if a.size != b.size or a.size == 0:
        return -1.0
    a = a - np.mean(a)
    b = b - np.mean(b)
    den = float(np.linalg.norm(a) * np.linalg.norm(b))
    if den < 1e-12:
        return -1.0
    return float(np.dot(a, b) / den)


def _envelope_for_pair_check(arr):
    """Trace-wise Hilbert envelope + log compression for robust structure comparison. arr internal [trace, depth]."""
    arr = np.asarray(arr, dtype=np.float32)
    env = np.abs(hilbert(arr, axis=1)).astype(np.float32)
    env = np.log1p(env / (np.percentile(env, 95.0) + 1e-6))
    env = _block_mean_downsample(env, factor=PAIR_CHECK_DOWNSAMPLE)
    return _standardize_for_corr(env)


def diagnose_pair_self_alignment(lq, gt):
    info = {"ok": True, "status": "ok", "reason": "", "same_env_corr": None, "same_raw_corr": None,
            "best_orientation": "same", "best_orientation_corr": None}
    lq = np.asarray(lq, dtype=np.float32)
    gt = np.asarray(gt, dtype=np.float32)
    if lq.shape != (N2, N1) or gt.shape != (N2, N1):
        info.update(ok=False, status="bad_shape", reason=f"bad_shape lq={lq.shape}, gt={gt.shape}")
        return info
    if (not np.all(np.isfinite(lq))) or (not np.all(np.isfinite(gt))):
        info.update(ok=False, status="nonfinite", reason="non-finite value found")
        return info
    if float(np.std(lq)) < 1e-7 or float(np.std(gt)) < 1e-7:
        info.update(ok=False, status="near_constant", reason="near-constant lq or gt")
        return info

    lq_env = _envelope_for_pair_check(lq)
    gt_env = _envelope_for_pair_check(gt)
    same_env_corr = _safe_corr(lq_env, gt_env)
    lq_raw = _standardize_for_corr(_block_mean_downsample(lq, factor=PAIR_CHECK_DOWNSAMPLE))
    gt_raw = _standardize_for_corr(_block_mean_downsample(gt, factor=PAIR_CHECK_DOWNSAMPLE))
    same_raw_corr = _safe_corr(lq_raw, gt_raw)
    candidates = {
        "same": same_env_corr,
        "gt_transpose": _safe_corr(lq_env, gt_env.T),
        "gt_flip_x": _safe_corr(lq_env, gt_env[::-1, :]),
        "gt_flip_t": _safe_corr(lq_env, gt_env[:, ::-1]),
    }
    best_orientation = max(candidates, key=candidates.get)
    best_corr = float(candidates[best_orientation])
    info.update(same_env_corr=float(same_env_corr), same_raw_corr=float(same_raw_corr),
                best_orientation=best_orientation, best_orientation_corr=best_corr)

    fail_reasons = []
    if same_env_corr < PAIR_CHECK_MIN_ENV_CORR:
        fail_reasons.append(f"low_env_corr={same_env_corr:.4f}")
    if same_raw_corr < PAIR_CHECK_MIN_RAW_CORR and same_env_corr < (PAIR_CHECK_MIN_ENV_CORR + 0.08):
        fail_reasons.append(f"low_raw_corr={same_raw_corr:.4f}")
    if best_orientation != "same" and best_corr > same_env_corr + PAIR_CHECK_ORIENTATION_MARGIN:
        fail_reasons.append(f"orientation_suspicious: best={best_orientation}, best_corr={best_corr:.4f}, same={same_env_corr:.4f}")
    if fail_reasons:
        info.update(ok=False, status="failed", reason="; ".join(fail_reasons))
    return info


def collect_representative_wavelets(wavelet_func):
    w_lqs, w_gts, metas = [], [], []
    for d in REP_DEPTHS:
        w_lq, w_gt, lm = wavelet_func(d)
        w_lqs.append(w_lq)
        w_gts.append(w_gt)
        metas.append(lm)
    return np.stack(w_lqs), np.stack(w_gts), metas


def save_qc_figure_timevarying(lq, gt, rep_w_lq, rep_w_gt, rep_metas, meta, out_png, dt=0.004):
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)
    clip = np.percentile(np.abs(np.concatenate([lq.reshape(-1), gt.reshape(-1)])), 99.0)
    clip = max(float(clip), 1e-6)
    # lq / gt here are saved arrays: [depth, trace].
    x_trace = lq.shape[1] // 2
    t = time_axis(dt, WAVELET_LENGTH)

    fig = plt.figure(figsize=(20, 12), dpi=150)

    ax1 = plt.subplot(3, 3, 1)
    ax1.imshow(lq, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax1.set_title("LQ narrow-band, time-varying")

    ax2 = plt.subplot(3, 3, 2)
    ax2.imshow(gt, cmap="gray", aspect="auto", origin="upper", vmin=-clip, vmax=clip)
    ax2.set_title("GT broadband, time-varying")

    ax3 = plt.subplot(3, 3, 3)
    ax3.plot(lq[:, x_trace], label="lq")
    ax3.plot(gt[:, x_trace], label="gt")
    ax3.set_title(f"Trace comparison trace={x_trace}")
    ax3.legend(fontsize=8)

    ax4 = plt.subplot(3, 3, 4)
    for i, name in enumerate(REP_NAMES):
        ax4.plot(t[:rep_w_lq.shape[1]], rep_w_lq[i], linestyle="--", label=f"{name} lq")
        ax4.plot(t[:rep_w_gt.shape[1]], rep_w_gt[i], linestyle="-", label=f"{name} gt")
    ax4.set_title("Representative wavelets")
    ax4.legend(fontsize=7, ncol=2)

    ax5 = plt.subplot(3, 3, 5)
    for i, name in enumerate(REP_NAMES):
        f_lq, a_lq = amplitude_spectrum(rep_w_lq[i], dt=dt)
        f_gt, a_gt = amplitude_spectrum(rep_w_gt[i], dt=dt)
        ax5.plot(f_lq, a_lq, linestyle="--", label=f"{name} lq")
        ax5.plot(f_gt, a_gt, linestyle="-", label=f"{name} gt")
    ax5.set_xlim(0, 120)
    ax5.set_ylim(0, 1.08)
    ax5.set_title("Representative spectra")
    ax5.legend(fontsize=7, ncol=2)

    ax6 = plt.subplot(3, 3, 6)
    depths = [m["depth_norm"] for m in rep_metas]
    family = meta.get("family", "")
    if family == "ricker":
        ax6.plot(depths, [m["f0_lq"] for m in rep_metas], marker="o", label="f0_lq")
        ax6.plot(depths, [m["gamma"] for m in rep_metas], marker="o", label="gamma")
        if "shoulder_floor" in rep_metas[0]:
            ax6.plot(depths, [m["shoulder_floor"] for m in rep_metas], marker="o", label="shoulder_floor")
        ax6.set_ylabel("Hz / gain")
    elif family == "ormsby":
        ax6.plot(depths, [m["band_lq"][2] for m in rep_metas], marker="o", label="LQ f3")
        ax6.plot(depths, [m["band_gt"][2] for m in rep_metas], marker="o", label="GT f3")
        ax6.plot(depths, [m["band_gt"][3] for m in rep_metas], marker="o", label="GT f4")
        ax6.set_ylabel("Hz")
    elif family == "klauder":
        ax6.plot(depths, [m["sweep_lq"][1] for m in rep_metas], marker="o", label="LQ f_end")
        ax6.plot(depths, [m["sweep_gt"][1] for m in rep_metas], marker="o", label="GT f_end")
        ax6.set_ylabel("Hz")
    ax6.set_xlabel("depth_norm")
    ax6.set_title("Representative parameter trend")
    ax6.legend(fontsize=8)

    ax7 = plt.subplot(3, 3, 7)
    ax7.axis("off")
    local_txt = json.dumps(rep_metas, ensure_ascii=False, indent=2)
    ax7.text(0, 1, local_txt, va="top", ha="left", fontsize=7, family="monospace")
    ax7.set_title("top/mid/bottom local meta")

    ax8 = plt.subplot(3, 3, 8)
    ax8.axis("off")
    meta_show = dict(meta)
    for long_key in ["band_lq_curve", "band_gt_curve", "sweep_lq_curve", "sweep_gt_curve"]:
        if long_key in meta_show:
            meta_show[long_key] = "see json/npz"
    txt = json.dumps(meta_show, ensure_ascii=False, indent=2)
    ax8.text(0, 1, txt, va="top", ha="left", fontsize=7, family="monospace")
    ax8.set_title("global meta")

    ax9 = plt.subplot(3, 3, 9)
    ax9.axis("off")
    ax9.text(
        0, 1,
        "QC checklist:\n"
        "1) GT spectra envelope LQ at top/mid/bottom.\n"
        "2) Frequency high end decreases smoothly with depth.\n"
        "3) No abrupt time-window seams in LQ/GT sections.\n"
        "4) Phase/peak positions remain consistent between LQ and GT.",
        va="top", ha="left", fontsize=9,
    )

    plt.tight_layout()
    fig.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close(fig)


# =========================================================
# 5. 动态加载反射结构脚本
# =========================================================
def load_generator_class(script_path, module_name):
    script_path = Path(script_path)
    if not script_path.exists():
        raise FileNotFoundError(f"Source script not found: {script_path}")
    spec = importlib.util.spec_from_file_location(module_name, str(script_path))
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    if not hasattr(mod, "GeologicalSeismicData"):
        raise AttributeError(f"{script_path.name} does not contain class GeologicalSeismicData")
    return mod.GeologicalSeismicData


def generate_reflectivity(GeneratorClass, seed, n1=512, n2=512):
    gen = GeneratorClass(seed=seed)
    try:
        model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0)
    except TypeError:
        if hasattr(gen, "generate_plausible_parameters"):
            params = gen.generate_plausible_parameters(n1=n1, n2=n2)
            model = gen.seismic_and_slopes_2d(n1=n1, n2=n2, noise=0, params=params)
        else:
            raise
    model = np.asarray(model, dtype=np.float32)
    if model.shape != (n2, n1):
        raise ValueError(f"Unexpected model shape {model.shape}, expected {(n2, n1)}")
    return model


# =========================================================
# 6. 索引、复现信息
# =========================================================
def phase_group(phase_deg, eps=1e-6):
    return "zero_phase" if abs(float(phase_deg)) <= eps else "with_phase"


def write_summary_csv(rows):
    out_csv = OUT_DIR / "sample_index.csv"
    fields = [
        "id", "structure", "family", "variation", "phase_deg", "phase_group",
        "lq_path", "gt_path", "meta_path", "wavelet_field_path", "w_lq_path", "w_gt_path",
    ]
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fields})
    print(f"[SAVE] sample_index.csv: {out_csv}")

    counts = {
        "total": len(rows),
        "by_structure": dict(Counter(r["structure"] for r in rows)),
        "by_family": dict(Counter(r["family"] for r in rows)),
        "by_phase_group": dict(Counter(r["phase_group"] for r in rows)),
        "by_structure_family": dict(Counter(f"{r['structure']}_{r['family']}" for r in rows)),
    }
    out_json = OUT_DIR / "sample_count.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(counts, f, ensure_ascii=False, indent=2)
    print(f"[SAVE] sample_count.json: {out_json}")
    print(json.dumps(counts, ensure_ascii=False, indent=2))


def copy_sources_for_reproducibility():
    if not COPY_SOURCE_SCRIPTS:
        return
    src_dir = OUT_DIR / "source_scripts"
    src_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(__file__), src_dir / Path(__file__).name)
    for item in SOURCE_SCRIPTS:
        p = SCRIPT_DIR / item["file"]
        if p.exists():
            shutil.copy2(p, src_dir / p.name)


# =========================================================
# 7. 主程序
# =========================================================
def main():
    reset_output_dir()
    ensure_dirs()
    copy_sources_for_reproducibility()

    rng_global = np.random.default_rng(RANDOM_SEED)
    idx = START_INDEX
    rows = []
    qc_seen_structure_family = set()

    print(
        f"Start generating FIXED-V6 (Ricker shoulder) multi-structure TIME-VARYING BWE dataset: "
        f"{len(SOURCE_SCRIPTS)} structures × {NUM_PER_STRUCTURE} samples, "
        f"same-size {N2}x{N1}, save_layout={SAVE_LAYOUT}, no noise, win={TV_WIN}, step={TV_STEP}."
    )

    for s_i, item in enumerate(SOURCE_SCRIPTS):
        structure = item["name"]
        script_path = SCRIPT_DIR / item["file"]
        GeneratorClass = load_generator_class(script_path, module_name=f"gen_{structure}")
        family_plan = make_family_plan(NUM_PER_STRUCTURE, rng_global)
        print(f"\n[STRUCTURE] {structure} from {item['file']} | plan={dict(Counter(family_plan))}")

        for j in range(NUM_PER_STRUCTURE):
            base_seed = int(RANDOM_SEED * 100000 + s_i * 10000 + j)
            forced_family = family_plan[j]
            best_candidate = None
            best_score = float("inf")
            retry_limit = int(MAX_PAIR_RETRY if ENABLE_RESIDUAL_RATIO_FILTER or ENABLE_PAIR_SELF_CHECK else 1)
            last_diag = None

            for retry in range(retry_limit):
                sample_seed = int(base_seed + retry * 7919)
                wavelet_rng = np.random.default_rng(sample_seed + 777)

                # 1) 反射结构。retry 时也改变结构 seed，避免某些结构与某类时变子波组合过难。
                model = generate_reflectivity(GeneratorClass, seed=sample_seed, n1=N1, n2=N2)

                # 2) 时变子波场
                wavelet_func, meta_w = make_timevarying_wavelet_model(
                    wavelet_rng,
                    forced_family=forced_family,
                    dt=DT,
                    length=WAVELET_LENGTH,
                )

                # 3) 时变非平稳卷积，内部布局为 [trace, depth]
                lq, gt, window_records = convolve_time_varying(model, wavelet_func, win=TV_WIN, step=TV_STEP)

                # 4) pair 处理：GT RMS 补偿 + shared maxabs no-clip + 保存方向转换
                lq_internal, gt_internal, lq_save, gt_save, scale_info = scale_pair_for_save(lq, gt, scale_floor=1e-6)

                if ENABLE_PAIR_SELF_CHECK:
                    last_diag = diagnose_pair_self_alignment(lq_internal, gt_internal)
                else:
                    last_diag = {"ok": True, "status": "disabled", "reason": "pair self-check disabled"}

                rr = residual_ratio_value(scale_info)
                orientation_ok = bool(last_diag.get("ok", False))
                residual_target_ok = (not ENABLE_RESIDUAL_RATIO_FILTER) or residual_ratio_in_target(scale_info, forced_family)
                residual_fallback_ok = (not ENABLE_RESIDUAL_RATIO_FILTER) or residual_ratio_in_fallback(scale_info, forced_family)

                if orientation_ok:
                    # V4: 不再要求候选必须先进入 fallback 区间才可备选。
                    # 原 v3 在 Ormsby/Klauder 上常见 residual_ratio=0.70~0.85，若全都略超 fallback，
                    # 会直接中断。这里始终保存“方向正确”的最佳候选；target 候选优先，
                    # fallback 候选次之，超 fallback 的候选只作为最后兜底并写入 meta warning。
                    if residual_target_ok:
                        sc = 0.0 + abs(rr - get_family_residual_accept_max(forced_family))
                    elif residual_fallback_ok:
                        sc = 10.0 + abs(rr - get_family_residual_accept_max(forced_family))
                    else:
                        sc = 100.0 + max(0.0, rr - RESIDUAL_RATIO_FALLBACK_MAX)
                    if sc < best_score:
                        best_score = sc
                        best_candidate = (
                            sample_seed, retry, wavelet_func, meta_w, window_records,
                            lq_internal, gt_internal, lq_save, gt_save, scale_info, last_diag
                        )

                if orientation_ok and residual_target_ok:
                    break

                reason_parts = []
                if not orientation_ok:
                    reason_parts.append(f"pair={last_diag.get('reason')}")
                if ENABLE_RESIDUAL_RATIO_FILTER and not residual_target_ok:
                    reason_parts.append(
                        f"residual_ratio={rr:.3f} not in [{RESIDUAL_RATIO_ACCEPT_MIN:.2f}, {get_family_residual_accept_max(forced_family):.2f}]"
                    )
                print(
                    f"  [PAIR-RETRY] id={idx:04d}, structure={structure}, family={forced_family}, "
                    f"retry={retry + 1}/{retry_limit}, " + "; ".join(reason_parts)
                )
            else:
                if best_candidate is None:
                    raise RuntimeError(
                        f"No orientation-valid time-varying pair after {retry_limit} retries: "
                        f"idx={idx:04d}, structure={structure}, family={forced_family}, last_diag={last_diag}"
                    )

            # 若最后一次没有命中 target，但有 fallback，则使用 fallback 候选。
            if not (bool(last_diag.get("ok", False)) and residual_ratio_in_target(scale_info, forced_family)):
                if best_candidate is not None:
                    (
                        sample_seed, retry, wavelet_func, meta_w, window_records,
                        lq_internal, gt_internal, lq_save, gt_save, scale_info, last_diag
                    ) = best_candidate
                    scale_info["residual_filter_used_fallback"] = True
                    final_rr = residual_ratio_value(scale_info)
                    if final_rr <= get_family_residual_fallback_max(forced_family):
                        scale_info["residual_filter_note"] = (
                            f"No candidate reached target max {get_family_residual_accept_max(forced_family):.2f}; "
                            f"use best fallback rr={final_rr:.4f}."
                        )
                    else:
                        scale_info["residual_filter_note"] = (
                            f"No candidate reached target/fallback max; use best orientation-valid candidate "
                            f"rr={final_rr:.4f}. This sample should be checked by qc_bwe_dataset."
                        )
                        scale_info["residual_filter_exceeded_fallback"] = True
            scale_info["residual_filter_enabled"] = bool(ENABLE_RESIDUAL_RATIO_FILTER)
            scale_info["residual_filter_accept_min"] = sanitize_float(RESIDUAL_RATIO_ACCEPT_MIN)
            scale_info["residual_filter_accept_max"] = sanitize_float(get_family_residual_accept_max(forced_family))
            scale_info["residual_filter_fallback_max"] = sanitize_float(get_family_residual_fallback_max(forced_family))
            scale_info["residual_filter_final_rr"] = sanitize_float(residual_ratio_value(scale_info))
            scale_info.setdefault("residual_filter_used_fallback", False)

            # 5) 代表子波保存，用于 QC 和 split 兼容
            rep_w_lq, rep_w_gt, rep_metas = collect_representative_wavelets(wavelet_func)

            stem = f"{idx:04d}"
            fname = f"{stem}.dat"
            # 保存为 [depth, trace]，与训练张量 [B,C,H,W] 中 H=depth/time, W=trace/lateral 一致。
            lq_save.astype(np.float32).tofile(LQ_DIR / fname)
            gt_save.astype(np.float32).tofile(GT_DIR / fname)

            np.save(WAVELET_DIR / f"{stem}_w_lq.npy", rep_w_lq[1].astype(np.float32))
            np.save(WAVELET_DIR / f"{stem}_w_gt.npy", rep_w_gt[1].astype(np.float32))
            wavelet_field_path = WAVELET_DIR / f"{stem}_wavelet_field.npz"
            np.savez(
                wavelet_field_path,
                rep_depths=np.array(REP_DEPTHS, dtype=np.float32),
                rep_names=np.array(REP_NAMES),
                w_lq=rep_w_lq.astype(np.float32),
                w_gt=rep_w_gt.astype(np.float32),
                window_records=np.array(json.dumps(window_records, ensure_ascii=False)),
            )

            meta = dict(meta_w)
            meta.update({
                "id": stem,
                "structure": structure,
                "source_script": item["file"],
                "seed": sample_seed,
                "retry": int(retry),
                "n1": N1,
                "n2": N2,
                "dt": DT,
                "wavelet_length": WAVELET_LENGTH,
                "tv_win": TV_WIN,
                "tv_step": TV_STEP,
                "representative_depths": [sanitize_float(x) for x in REP_DEPTHS],
                "pair_scale_info": scale_info,
                "pair_self_check": last_diag,
                "shared_scale": sanitize_float(scale_info.get("save_scale", 1.0)),
                "save_layout": SAVE_LAYOUT,
                "internal_layout": INTERNAL_LAYOUT,
            })
            meta_path = META_DIR / f"{stem}.json"
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)

            need_qc = (
                (idx - START_INDEX) < QC_FIRST_N
                or ((idx - START_INDEX + 1) % QC_EVERY == 0)
                or ((structure, meta["family"]) not in qc_seen_structure_family)
            )
            if need_qc:
                save_qc_figure_timevarying(
                    lq_save,
                    gt_save,
                    rep_w_lq,
                    rep_w_gt,
                    rep_metas,
                    meta,
                    QC_DIR / f"{stem}_qc.png",
                    dt=DT,
                )
                qc_seen_structure_family.add((structure, meta["family"]))

            row = {
                "id": stem,
                "structure": structure,
                "family": meta["family"],
                "variation": "time",
                "phase_deg": meta["phase_deg"],
                "phase_group": phase_group(meta["phase_deg"]),
                "lq_path": str(LQ_DIR / fname),
                "gt_path": str(GT_DIR / fname),
                "meta_path": str(meta_path),
                "wavelet_field_path": str(wavelet_field_path),
                "w_lq_path": str(WAVELET_DIR / f"{stem}_w_lq.npy"),
                "w_gt_path": str(WAVELET_DIR / f"{stem}_w_gt.npy"),
            }
            rows.append(row)

            if (j + 1) % 10 == 0 or (j + 1) == NUM_PER_STRUCTURE:
                print(
                    f"  [{j + 1:04d}/{NUM_PER_STRUCTURE}] latest id={stem}, "
                    f"family={meta['family']}, phase={meta['phase_deg']:.2f}, "
                    f"rr={scale_info['residual_filter_final_rr']:.3f}, "
                    f"clip_lq={scale_info['saved_internal_clip_ratio_lq_0999']:.5f}, "
                    f"gt/lq_high={scale_info['saved_internal_vertical_high_energy_gt_lq_ratio']:.3f}"
                )
            idx += 1

    write_summary_csv(rows)
    print(f"\nAll done. Dataset saved to: {OUT_DIR}")


if __name__ == "__main__":
    main()
