
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter, map_coordinates, zoom

import numpy as np

def downsample_x2(img):
    # 轻微低通减少混叠（可调/可去）
    img_lp = gaussian_filter(img, sigma=0.5)
    return zoom(img_lp, zoom=(0.5, 0.5), order=1).astype(np.float32)

def add_offset_noise(img, rng, snr_db=15.0,
                     offset_exp=1.8, min_scale=0.4, max_scale=1.0,
                     bandlimit=True, fmin=0.02, fmax=0.25):
    """
    偏移剖面噪声（offset-dependent noise）
    img: (n2, n1)  # 你的图像：X2在第0维，深度在第1维
    snr_db: 控制噪声强弱（典型 8~25dB；越小噪声越强）
    offset_exp/min_scale/max_scale: 控制“远偏移更吵”的程度
    bandlimit: True 时把噪声带限成更像地震噪声的形态
    """
    n2, n1 = img.shape
    x = img.astype(np.float32)

    # 用全图 RMS 定一个总噪声水平（由 snr_db 控制）
    sig_rms = np.sqrt(np.mean(x**2) + 1e-12)
    noise_rms = sig_rms / (10.0 ** (snr_db / 20.0))

    # 以中心道为近偏移，向两侧偏移增大（0~1）
    i2 = np.arange(n2, dtype=np.float32)
    center = (n2 - 1) / 2.0
    off = np.abs(i2 - center) / (center + 1e-12)

    # 每条道噪声标准差权重：近偏移小，远偏移大
    w = min_scale + (max_scale - min_scale) * (off ** offset_exp)

    # 生成噪声并按道加权
    noise = rng.standard_normal((n2, n1)).astype(np.float32)
    noise *= (noise_rms * w)[:, None]

    # 可选：沿深度方向带限（让噪声更像地震噪声，不那么“像素白噪声”）
    if bandlimit:
        F = np.fft.rfft(noise, axis=1)
        freqs = np.fft.rfftfreq(n1, d=1.0)  # 归一化频率 0~0.5
        win = np.zeros_like(freqs, dtype=np.float32)

        tw = 0.02  # 过渡带宽
        f1, f2 = max(fmin - tw, 0.0), fmin
        f3, f4 = fmax, min(fmax + tw, 0.5)

        m = (freqs >= f1) & (freqs < f2)
        if np.any(m):
            t = (freqs[m] - f1) / (f2 - f1 + 1e-12)
            win[m] = 0.5 - 0.5 * np.cos(np.pi * t)
        win[(freqs >= f2) & (freqs <= f3)] = 1.0
        m = (freqs > f3) & (freqs <= f4)
        if np.any(m):
            t = (freqs[m] - f3) / (f4 - f3 + 1e-12)
            win[m] = 0.5 + 0.5 * np.cos(np.pi * t)

        F *= win[None, :]
        noise = np.fft.irfft(F, n=n1, axis=1).astype(np.float32)

    return x + noise
def apply_q_filter_vs_depth(image, dt=0.004, Q=80, strength=1.0, win=64, step=16):
    """
    随深度(i1)累积的Q滤波（近似）：浅层衰减弱，深层衰减强；高频衰减更快
    image: (n2, n1)  # X2在第0维，深度在第1维
    dt: 采样间隔（不知道就用0.004并用strength调效果）
    Q: 介质Q值（越小衰减越强）
    strength: 不确定物理尺度时的强度旋钮（0.5~3常用）
    win/step: 短窗处理，模拟随深度累积
    """
    n2, n1 = image.shape
    out = np.zeros_like(image, dtype=float)

    freqs = np.fft.rfftfreq(win, dt)
    w = np.hanning(win)

    for i2 in range(n2):
        x = image[i2, :].astype(float)

        acc = np.zeros(n1, dtype=float)
        wsum = np.zeros(n1, dtype=float)

        for s in range(0, n1 - win + 1, step):
            seg = x[s:s+win] * w
            mid = s + 0.5 * win
            t_mid = (mid * dt) * strength   # 深度越大（时间越大）衰减越强

            amp_decay = np.exp(-(np.pi * freqs * t_mid) / (Q + 1e-12))

            SEG = np.fft.rfft(seg)
            seg_q = np.fft.irfft(SEG * amp_decay, n=win)

            acc[s:s+win] += seg_q * w
            wsum[s:s+win] += (w * w)

        out[i2, :] = acc / (wsum + 1e-12)

    return out
def ricker_wavelet(f0=25.0, dt=0.004, length=0.128):
    """
    标准Ricker子波（零相位）
    f0: 主频(Hz)
    dt: 采样间隔(s)
    length: 子波总时长(s)，建议为 4~6 个主周期左右
    """
    t = np.arange(-length/2, length/2 + dt, dt)
    a = (np.pi * f0 * t)**2
    w = (1.0 - 2.0 * a) * np.exp(-a)
    # 归一化，方便不同参数下幅值可控
    w = w / (np.max(np.abs(w)) + 1e-12)
    return w


def convolve_along_depth(image, wavelet):
    """
    沿深度/时间轴（axis=1）对每条道做 1D 卷积
    image: (n2, n1)
    wavelet: (nw,)
    返回同尺寸 (n2, n1)
    """
    n2, n1 = image.shape
    out = np.zeros_like(image, dtype=np.float32)
    for i2 in range(n2):
        out[i2, :] = np.convolve(image[i2, :], wavelet, mode="same")
    return out

class GeologicalSeismicData:

    def __init__(self, seed=31):
        self.rng = np.random.RandomState(seed)

    def generate_plausible_parameters(self, n1, n2):
        """
        (新) 批量生成符合地质逻辑的参数。

        基本逻辑：
        1. 定义一个主要的盐丘构造。
        2. 定义一个主要的生长断层（可能与盐丘有关，也可能独立）。
        3. 定义一个主要的裂谷大断层（带拖曳效应）。
        4. 定义次要的尖灭和剪切。
        """
        params = {}

        # --- 1. 分层褶皱 ---
        params['folding'] = {
            'boundary_i1': n1 // self.rng.uniform(2.5, 4.5),  # 褶皱边界深度
            'lower_amp': self.rng.uniform(0.035, 0.07),  # 深层褶皱幅度
            'lower_freq_b': self.rng.uniform(4e-5, 6e-5),  # 深层褶皱频率
            'upper_amp': self.rng.uniform(0.03, 0.05),  # 浅层褶皱幅度
            'upper_freq_b': self.rng.uniform(4e-5, 6e-5)  # 浅层褶皱频率
        }

        # --- 2. 地层尖灭 ---
        # (保持在右侧，模拟盆地边缘)
        wedge_width = self.rng.uniform(50, 100)
        params['wedge'] = {
            'i1_start': self.rng.uniform(n1 * 0.7, n1 * 0.8),  # 尖灭深度
            'i1_end': self.rng.uniform(n1 * 0.85, n1 * 0.95),
            'x2_start': n2,  # 从右边缘开始
            'x2_end': n2 - wedge_width,  # 尖灭宽度
            'direction': 'right'
        }

        # --- 3. 盐丘 ---
        params['salt_dome'] = {
            'dome_center_x2': self.rng.uniform(n2 * 0.15, n2 * 0.3),  # 盐丘中心 (在左侧)
            'dome_height': self.rng.uniform(30, 80),
            'dome_width': self.rng.uniform(40, 60),
            'i1_start_lift': self.rng.uniform(140, 160),  # 隆起起始深度
            'i1_end_lift': self.rng.uniform(280, 320)  # 隆起结束深度
        }

        # --- 4. 断层 ---
        fault_start_depth = self.rng.uniform(10, 30)
        fault_end_depth = self.rng.uniform(180, 220)

        # 4a. 断层 1 (普通断层，在模型中间)
        params['fault1'] = {
            'x2_ref': self.rng.uniform(n2 * 0.45, n2 * 0.55),
            'dip_top': self.rng.uniform(-60, -40),
            'dip_bottom': self.rng.uniform(20, 40),
            'throw': self.rng.uniform(10, 20),
            'i1_start': fault_start_depth,
            'i1_end': fault_end_depth,
            'growth_factor': 1.0  # 无生长
        }

        # 4b. 断层 2 (生长断层, 靠近盐丘，模拟盐丘相关的塌陷)
        # 逻辑：位置在盐丘的右侧
        salt_right_edge = params['salt_dome']['dome_center_x2'] + params['salt_dome']['dome_width']
        params['fault2'] = {
            'x2_ref': salt_right_edge + self.rng.uniform(40, 80),
            'dip_top': self.rng.uniform(-60, -40),  # 倾向盐丘
            'dip_bottom': self.rng.uniform(10, 20),
            'throw': self.rng.uniform(10, 15),
            'i1_start': fault_start_depth,
            'i1_end': fault_end_depth,
            'growth_factor': self.rng.uniform(1.15, 1.30)  # 有生长
        }

        # 4c. 断层 3 (大型裂谷断层，带拖曳效应，在模型右侧)
        params['fault3'] = {
            'x2_ref': self.rng.uniform(n2 * 0.8, n2 * 0.9),
            'dip_top': self.rng.uniform(80, 90),  # 陡峭
            'dip_bottom': self.rng.uniform(30, 50),  # 变缓
            'throw': self.rng.uniform(25, 40),
            'i1_start': fault_start_depth,
            'i1_end': n1,  # 延伸到底部
            'growth_factor': 1.0  # 无生长
        }

        # 4d. 断层 3 的拖曳效应
        params['flexure3'] = {
            'flexure_width': self.rng.uniform(30, 50),
            'max_flexure_depth_shift': self.rng.uniform(20, 35)
        }

        # --- 5. 衰减带参数 (所有断层共用) ---
        params['zone'] = {
            'zone_width': self.rng.uniform(6, 10),
            'blur_sigma': self.rng.uniform(0.3, 0.7),
            'attenuation_factor': self.rng.uniform(0.3, 0.6)
        }

        # --- 6. 垂向剪切 ---
        params['shear'] = {
            'scale': self.rng.uniform(0.03, 0.08)
        }

        return params

    def seismic_and_slopes_2d(self, n1=256, n2=512, noise=0, params=None):

        # 1. 创建基础反射系数
        reflectivity = self._make_reflectivity_2d(n1, n2)

        # (修改) 如果没有提供参数，则使用一组固定的默认值（用于调试）
        if params is None:
            # (使用您上一版代码中的硬编码值作为默认值)
            params = self.generate_plausible_parameters(n1, n2)
            # (为了简化，我们直接调用生成器。在实际应用中，这里可以放一组固定的默认值)

        # 应用分层褶皱
        p_fold = params['folding']
        # 褶皱更明显：整体幅度放大 + 增加谐波 + 加一点三角波尖化
        # 说明：
        # - 主分量 amplitude 用 1.8 倍（upper/lower_amp）
        # - 二次谐波用 0.9 倍（让波形更“皱”）
        # - tri 用 0.55 倍（让褶皱核更尖更明显）
        # - 频率系数 b2：主频保持不变；谐波约 2.2 倍；tri 约 1.0 倍

        upper_params = {
            "components": [
                {"type": "sin", "b1": 2.20 * p_fold["upper_amp"], "a2": 0.0, "b2": 1.00 * p_fold["upper_freq_b"],
                 "phase": 0.0},
                {"type": "sin", "b1": 1.35 * p_fold["upper_amp"], "a2": 0.0, "b2": 2.40 * p_fold["upper_freq_b"],
                 "phase": 1.15},
                {"type": "tri", "b1": 0.90 * p_fold["upper_amp"], "a2": 0.0, "b2": 1.10 * p_fold["upper_freq_b"],
                 "phase": 0.55},

            ]
        }

        lower_params = {
            "components": [
                {"type": "sin", "b1": 2.80 * p_fold["lower_amp"], "a2": 0.0, "b2": 1.00 * p_fold["lower_freq_b"],
                 "phase": 0.0},
                {"type": "sin", "b1": 1.20 * p_fold["lower_amp"], "a2": 0.0, "b2": 2.20 * p_fold["lower_freq_b"],
                 "phase": 0.95},
                {"type": "tri", "b1": 0.30 * p_fold["lower_amp"], "a2": 0.0, "b2": 1.00 * p_fold["lower_freq_b"],
                 "phase": 0.25},

            ]
        }



        reflectivity = self._apply_sinusoidal_fold_2d_layered(
            reflectivity, n1, n2,
            boundary_i1=p_fold['boundary_i1'],
            upper_params=upper_params,
            lower_params=lower_params
        )

        # --- 2.5. 模拟地层尖灭 ---
        reflectivity = self._apply_stratigraphic_wedge_2d(
            reflectivity, n1, n2, **params['wedge']
        )

        #  模拟盐丘上拱
        reflectivity = self._apply_salt_dome_2d(
            reflectivity, n1, n2, **params['salt_dome']
        )

        zone_params = params['zone']

        # 4. 应用弯曲的铲状断层

        # --- 断层 1 ---
        fault1_params = params['fault1']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault1_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault1_params, **zone_params)

        # --- 断层 2 (生长断层) ---
        fault2_params = params['fault2']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault2_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault2_params, **zone_params)

        # --- 断层 3 (大断层) ---
        fault3_params = params['fault3']
        reflectivity = self._apply_curved_normal_fault_2d(reflectivity, n1, n2, **fault3_params)
        reflectivity = self._apply_fault_zone_attenuation_2d(reflectivity, n1, n2, **fault3_params, **zone_params)

        # --- 5.5. 应用断层拖曳 (断层3) ---
        # 组合 fault3 和 flexure3 的参数
        flexure_params = {**fault3_params, **params['flexure3']}
        reflectivity = self._apply_geometric_flexure_2d(
            reflectivity, n1, n2, **flexure_params
        )

        reflectivity = self._apply_vertical_shear_2d(
            reflectivity, n1, n2, **params['shear']
        )

        # 6. 归一化和添加噪声
        image = reflectivity
        image = image / np.std(image)  # 归一化

        if noise > 0:
            noise_array = self.rng.randn(*image.shape)
            noise_array = gaussian_filter(noise_array, sigma=2.0, order=1)
            noise_array = noise_array * noise * np.std(image) / np.std(noise_array)
            image = image + noise_array

        return image

    def _make_reflectivity_2d(self, n1, n2):
        r = 2.0 * self.rng.rand(n1) - 1.0
        r = np.sign(r) * np.abs(r) ** 5
        reflectivity = np.tile(r[:, np.newaxis], (1, n2)).T
        return reflectivity

    def _apply_vertical_shear_2d(self, data, n1, n2, scale=0.05):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([
            i2.astype(float),  # 横向坐标不变
            np.clip(i1 - scale * i2, 0, n1 - 1)  # 深度坐标剪切并裁剪
        ])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_stratigraphic_wedge_2d(self, data, n1, n2, i1_start, i1_end, x2_start, x2_end, direction='left'):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        x2_min = min(x2_start, x2_end)
        x2_max = max(x2_start, x2_end)
        x2_width = x2_max - x2_min
        if x2_width <= 0:
            return data
        x2_active = np.clip(i2, x2_min, x2_max)
        if direction == 'left':
            attenuation_factor = (x2_active - x2_min) / x2_width
        elif direction == 'right':
            attenuation_factor = 1.0 - (x2_active - x2_min) / x2_width
        else:
            return data
        wedge_mask = depth_mask & (i2 >= x2_min) & (i2 < x2_max)
        data[wedge_mask] *= attenuation_factor[wedge_mask]
        return data

    def _apply_sinusoidal_fold_2d_layered(self, data, n1, n2, boundary_i1, upper_params, lower_params):
        """
        支持：多个三角函数叠加（sin / tri）。
        upper_params / lower_params 结构示例：
        {
          "components": [
            {"type":"sin", "a1":0, "b1":0.010, "a2":0.0, "b2":8e-4, "phase":0.0},
            {"type":"sin", "a1":0, "b1":0.006, "a2":0.0, "b2":1.6e-3, "phase":1.2},
            {"type":"tri", "a1":0, "b1":0.004, "a2":0.0, "b2":9e-4, "phase":0.5},
          ]
        }
        说明：
        - (a1 + b1*i1) 控制幅度随深度变化
        - (a2 + b2*i2) * i2 控制“变频”（你原来就是这个形式）
        - phase 为相位（弧度）
        - tri 用连续三角波：tri(x)=2/pi*arcsin(sin(x))，范围 [-1,1]
        """
        i1_range, i2_range = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        shift = np.zeros_like(i1_range, dtype=float)

        def _sum_components(mask, params):
            if params is None:
                return 0.0
            comps = params.get("components", None)

            # 兼容旧写法：如果没给 components，就退化为单一 sin（你的旧参数 a1,b1,a2,b2）
            if comps is None:
                a1 = params.get("a1", 0.0)
                b1 = params.get("b1", 0.0)
                a2 = params.get("a2", 0.0)
                b2 = params.get("b2", 0.0)
                phase = params.get("phase", 0.0)
                amp = (a1 + b1 * i1_range[mask])
                arg = (a2 + b2 * i2_range[mask]) * i2_range[mask] + phase
                return amp * np.sin(arg)

            # 多分量叠加
            total = 0.0
            for c in comps:
                ctype = c.get("type", "sin").lower()
                a1 = c.get("a1", 0.0)
                b1 = c.get("b1", 0.0)
                a2 = c.get("a2", 0.0)
                b2 = c.get("b2", 0.0)
                phase = c.get("phase", 0.0)

                amp = (a1 + b1 * i1_range[mask])
                arg = (a2 + b2 * i2_range[mask]) * i2_range[mask] + phase

                if ctype == "sin":
                    total = total + amp * np.sin(arg)
                elif ctype == "cos":
                    total = total + amp * np.cos(arg)
                elif ctype == "tri":
                    # 连续三角波（尖顶更像铰合区），范围 [-1,1]
                    total = total + amp * (2.0 / np.pi) * np.arcsin(np.sin(arg))
                else:
                    # 未知类型，默认 sin
                    total = total + amp * np.sin(arg)
            return total

        mask_upper = (i1_range < boundary_i1)
        shift[mask_upper] = _sum_components(mask_upper, upper_params)

        mask_lower = (i1_range >= boundary_i1)
        shift[mask_lower] = _sum_components(mask_lower, lower_params)

        x1_new = i1_range - shift
        coords = np.zeros((2, n2, n1))
        coords[0, :, :] = i2_range
        coords[1, :, :] = np.clip(x1_new, 0, n1 - 1)
        return map_coordinates(data, coords.reshape(2, n2, n1), order=3, mode='nearest')

    def _apply_salt_dome_2d(self, data, n1, n2, dome_center_x2, dome_height, dome_width, i1_start_lift=0,
                            i1_end_lift=None):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        if i1_end_lift is None:
            i1_end_lift = n1
        n1_effective = i1_end_lift - i1_start_lift
        if n1_effective <= 0:
            return data
        i1_offset = np.maximum(0, i1 - i1_start_lift)
        i1_norm_raw = i1_offset / n1_effective
        i1_norm_clamped = np.clip(i1_norm_raw, 0, 1)
        uplift_scale = 4 * i1_norm_clamped * (1 - i1_norm_clamped)
        shift = dome_height * np.exp(-((i2 - dome_center_x2) ** 2) / (2 * dome_width ** 2)) * uplift_scale
        src_i1 = np.clip(i1 + shift, 0, n1 - 1)
        src_i2 = i2.astype(float)
        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_curved_normal_fault_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, throw, i1_start, i1_end,
                                      growth_factor=1.0):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        coords = np.array([i2.astype(float), i1.astype(float)])
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        if dip_top > 0:
            downthrown_mask = (i2 > fault_x2_trace[np.newaxis, :])
        else:
            downthrown_mask = (i2 < fault_x2_trace[np.newaxis, :])
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        fault_mask = downthrown_mask & depth_mask
        i1_offset_from_start = coords[1][fault_mask] - i1_start
        growth_displacement = i1_offset_from_start * (growth_factor - 1.0)
        total_displacement = throw + growth_displacement
        src_i1 = coords[1][fault_mask] - total_displacement
        coords[1][fault_mask] = np.clip(src_i1, 0, n1 - 1)
        return map_coordinates(data, coords, order=3, mode='nearest')

    def _apply_fault_zone_attenuation_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom,
                                         zone_width, blur_sigma, attenuation_factor, i1_start, i1_end, **kwargs):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        fault_x2_trace_grid = fault_x2_trace[np.newaxis, :]
        dist_to_fault = np.abs(i2 - fault_x2_trace_grid)
        zone_mask_proximity = (dist_to_fault <= zone_width / 2.0)
        depth_mask = (i1 >= i1_start) & (i1 < i1_end)
        zone_mask = zone_mask_proximity & depth_mask
        if np.any(zone_mask):
            blurred_data = gaussian_filter(data, sigma=blur_sigma)
            data[zone_mask] = blurred_data[zone_mask]
            data[zone_mask] *= attenuation_factor
        return data

    def _apply_geometric_flexure_2d(self, data, n1, n2, x2_ref, dip_top, dip_bottom, i1_start, i1_end,
                                    flexure_width, max_flexure_depth_shift, **kwargs):
        i1, i2 = np.meshgrid(np.arange(n1), np.arange(n2), indexing='xy')
        dip_profile = np.linspace(dip_top, dip_bottom, n1)
        dip_rad_profile = np.radians(dip_profile)
        cot_dip_profile = 1.0 / (np.tan(dip_rad_profile + 1e-6))
        fault_x2_trace = x2_ref + np.cumsum(cot_dip_profile)
        if dip_top > 0:
            is_downthrown = (i2 > fault_x2_trace[np.newaxis, :])
            dist_to_fault = i2 - fault_x2_trace[np.newaxis, :]
            shift_direction = -1
        else:
            is_downthrown = (i2 < fault_x2_trace[np.newaxis, :])
            dist_to_fault = fault_x2_trace[np.newaxis, :] - i2
            shift_direction = -1
        dist_clamped = np.clip(dist_to_fault, 0, flexure_width)
        horizontal_weight = (flexure_width - dist_clamped) / flexure_width
        i1_norm = np.clip((i1 - i1_start) / (i1_end - i1_start + 1e-6), 0, 1)
        depth_weight = i1_norm
        flexure_shift = (
                max_flexure_depth_shift * horizontal_weight * depth_weight * shift_direction
        )
        flexure_mask = is_downthrown & (dist_to_fault > 0) & (dist_to_fault < flexure_width) & (i1 >= i1_start) & (
                i1 < i1_end)
        src_i1 = i1.astype(float)
        src_i2 = i2.astype(float)
        src_i1[flexure_mask] = np.clip(src_i1[flexure_mask] + flexure_shift[flexure_mask], 0, n1 - 1)
        coords = np.array([src_i2, src_i1])
        return map_coordinates(data, coords, order=3, mode='nearest')


# --- 绘图函数 (修改：接受标题) ---
def plot_2d_result(image, title='Seismic Image (Geological Model - No Convolution)'):
    """(修改) 绘图函数，接受自定义标题"""
    fig, axes = plt.subplots(1, 1, figsize=(12, 7))
    axes.imshow(image.T, cmap='gray', aspect='auto', origin='upper')
    axes.set_title(title)
    axes.set_xlabel('X2')
    axes.set_ylabel('X1 (Depth)')
    plt.tight_layout()
    plt.show()

import os
# Example usage
if __name__ == "__main__":

    N_IMAGES_TO_GENERATE = 1000
    N1_SIZE = 512
    N2_SIZE = 512

    CLEAN_DIR = "dataset1001-30hz/clean"
    NOISY_DIR = "dataset1001-20hz/noisy"
    os.makedirs(CLEAN_DIR, exist_ok=True)
    os.makedirs(NOISY_DIR, exist_ok=True)

    print(f"Generating {N_IMAGES_TO_GENERATE} seismic models...")

    dt = 0.004

    # 两种子波（主频严格区分）
    w60 = ricker_wavelet(f0=30.0, dt=dt, length=0.128)  # clean
    w20 = ricker_wavelet(f0=20.0, dt=dt, length=0.128)  # noisy

    idx = 1001  # 文件编号

    for i in range(N_IMAGES_TO_GENERATE):

        generator = GeologicalSeismicData(seed=i)
        params = generator.generate_plausible_parameters(n1=N1_SIZE, n2=N2_SIZE)

        # 1️⃣ 生成 256×512 反射系数模型
        model = generator.seismic_and_slopes_2d(
            n1=N1_SIZE, n2=N2_SIZE, noise=0, params=params
        )

        # 1) 生成 512×512 反射系数模型
        model = generator.seismic_and_slopes_2d(
            n1=N1_SIZE, n2=N2_SIZE, noise=0, params=params
        )

        # 2) clean：30Hz 卷积，无噪，保持 512×512
        clean = convolve_along_depth(model, w60)
        clean -= np.mean(clean)
        clean /= (np.std(clean) + 1e-12)

        # 3) noisy512：20Hz 卷积 + 偏移噪声（先在512上做）
        base = convolve_along_depth(model, w20)
        base -= np.mean(base)
        base /= (np.std(base) + 1e-12)

        noisy512 = add_offset_noise(
            base,
            rng=np.random.default_rng(i * 1000 + idx),
            snr_db=8.0,
            offset_exp=1.8,
            min_scale=0.35,
            max_scale=1.00,
            bandlimit=True
        ).astype(np.float32)

        # 4) noisy256：下采样得到 256×256
        noisy256 = downsample_x2(noisy512)

        # 5) 保存：clean(512) / noisy(256) 同名配对
        fname = f"{idx:04d}.dat"
        clean.astype(np.float32).tofile(os.path.join(CLEAN_DIR, fname))
        noisy256.astype(np.float32).tofile(os.path.join(NOISY_DIR, fname))
        idx += 1

    print("All done.")
